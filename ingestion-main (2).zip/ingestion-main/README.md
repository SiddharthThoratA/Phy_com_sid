# ingestion

General ingestion via relevant APIs to GCS

## Getting started

This project requires Python to be installed. 

On OS X with Homebrew you can just run `brew install python`.
If you are using any recent, non-server Linux it should already be installed.
If you are using windows install WSL2 and a Linux container which will have python installed.

If you want to run this locally you should first install the python requirements in a virtual environment:

```console
$ python -m venv .venv
$ source .venv/bin/activate
$ pip install -r requirements.txt
```

Running it locally should then be as simple as switching to the src folder and running:

```console
$ uvicorn main:app
```

Note that any environment variables needed will either need to be temporarily changed out or added to the local environment.

## placeholder.py

This is where the main code of any service should live.

## Notes

This service gets deployed on a cluster node and needs to share resources. 
CPU or Memory spikes can be mitigated and spread throughout runtime via locks and semaphores.
