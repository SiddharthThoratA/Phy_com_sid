# Changelog

## [1.6.2](https://github.com/fluidtruck-data/ingestion/compare/v1.6.1...v1.6.2) (2025-06-04)


### :wrench: Chores

* **hubspot:** added logic to extract archived data for owners ([#103](https://github.com/fluidtruck-data/ingestion/issues/103)) ([d306121](https://github.com/fluidtruck-data/ingestion/commit/d306121653a88b06033e6ea468551fec4dac9774))

## [1.6.1](https://github.com/fluidtruck-data/ingestion/compare/v1.6.0...v1.6.1) (2025-05-27)


### :wrench: Chores

* **hubspot:** users-owners initial ingestion ([#101](https://github.com/fluidtruck-data/ingestion/issues/101)) ([782b1c0](https://github.com/fluidtruck-data/ingestion/commit/782b1c0357d47bdaaf93cdcf922066ccc6b75cca))
* removed logging from pipeline stage ([#99](https://github.com/fluidtruck-data/ingestion/issues/99)) ([754d440](https://github.com/fluidtruck-data/ingestion/commit/754d440f1467012a1621edb0f57ad4d7a6a526d2))

## [1.6.0](https://github.com/fluidtruck-data/ingestion/compare/v1.5.0...v1.6.0) (2025-05-23)


### :sparkles: Features

* **hubspot:** initial associations ingestion ([#93](https://github.com/fluidtruck-data/ingestion/issues/93)) ([bf6ac6c](https://github.com/fluidtruck-data/ingestion/commit/bf6ac6cd81bd8dc6deae7cc1e4577ce8a08735f1))
* **hubspot:** initial-hubspot-pipelines-and-pipelines-stage ([#92](https://github.com/fluidtruck-data/ingestion/issues/92)) ([a08c4dc](https://github.com/fluidtruck-data/ingestion/commit/a08c4dcefe64eff2ae4e0537af702390ae3d2ca9))


### :wrench: Chores

* reduce memory usage ([#97](https://github.com/fluidtruck-data/ingestion/issues/97)) ([c9f57f6](https://github.com/fluidtruck-data/ingestion/commit/c9f57f6c1cfda2237e86ac4dfb0dcd58ae4e1804))
* smaller files ([#98](https://github.com/fluidtruck-data/ingestion/issues/98)) ([deb79ea](https://github.com/fluidtruck-data/ingestion/commit/deb79ea805d39268c964ddfdc8cdc0dd20762983))

## [1.5.0](https://github.com/fluidtruck-data/ingestion/compare/v1.4.4...v1.5.0) (2025-05-22)


### :sparkles: Features

* fully integrate incremental data pull ([#94](https://github.com/fluidtruck-data/ingestion/issues/94)) ([d5b1a23](https://github.com/fluidtruck-data/ingestion/commit/d5b1a237a00b56d5ae032e6882b9ef4eec522bd1))
* **hubspot:** hubspot objects initial ([#87](https://github.com/fluidtruck-data/ingestion/issues/87)) ([4e2c897](https://github.com/fluidtruck-data/ingestion/commit/4e2c89754bbfb2b5c2438d896e9dc9e5e5bfefef))
* **hubspot:** initial associations ingestion ([#86](https://github.com/fluidtruck-data/ingestion/issues/86)) ([31251ca](https://github.com/fluidtruck-data/ingestion/commit/31251cac64c2ba71d8dd5e482f3be998de523058))


### :bug: Bug Fixes

* **Hubspot_associations_type:** name changed in config file ([#91](https://github.com/fluidtruck-data/ingestion/issues/91)) ([3c7b38d](https://github.com/fluidtruck-data/ingestion/commit/3c7b38d4c29d39516b6f0d6fb2ea635f83c0b578))


### :wrench: Chores

* add users objects and properties ([#95](https://github.com/fluidtruck-data/ingestion/issues/95)) ([fa69191](https://github.com/fluidtruck-data/ingestion/commit/fa6919161bc4c6800dc849f9fc0c38998d42d099))
* **hubspot:** remove files ([#89](https://github.com/fluidtruck-data/ingestion/issues/89)) ([3280ffd](https://github.com/fluidtruck-data/ingestion/commit/3280ffddcdf6c172bd1db841f28554828c455eed))

## [1.4.4](https://github.com/fluidtruck-data/ingestion/compare/v1.4.3...v1.4.4) (2025-04-02)


### :wrench: Chores

* **stripe:** push dispute lookback to 120 days ([#83](https://github.com/fluidtruck-data/ingestion/issues/83)) ([9855f57](https://github.com/fluidtruck-data/ingestion/commit/9855f5704d51b23a1a742228e33b32d9f4703237))

## [1.4.3](https://github.com/fluidtruck-data/ingestion/compare/v1.4.2...v1.4.3) (2025-04-02)


### :wrench: Chores

* pagination adjustment ([#81](https://github.com/fluidtruck-data/ingestion/issues/81)) ([e05d708](https://github.com/fluidtruck-data/ingestion/commit/e05d7084d43dc069a92d29ce7b5d0e02d351a38b))

## [1.4.2](https://github.com/fluidtruck-data/ingestion/compare/v1.4.1...v1.4.2) (2025-04-01)


### :wrench: Chores

* prevent crashing ([#79](https://github.com/fluidtruck-data/ingestion/issues/79)) ([d706cde](https://github.com/fluidtruck-data/ingestion/commit/d706cde3673258510344bc0b89cab31769265951))

## [1.4.1](https://github.com/fluidtruck-data/ingestion/compare/v1.4.0...v1.4.1) (2025-04-01)


### :wrench: Chores

* widen stripe lookback ([#77](https://github.com/fluidtruck-data/ingestion/issues/77)) ([fda0dc9](https://github.com/fluidtruck-data/ingestion/commit/fda0dc9df3402304545f6d07977b9739e8a6d359))

## [1.4.0](https://github.com/fluidtruck-data/ingestion/compare/v1.3.3...v1.4.0) (2025-04-01)


### :sparkles: Features

* completing stripe ingestion ([#76](https://github.com/fluidtruck-data/ingestion/issues/76)) ([d010986](https://github.com/fluidtruck-data/ingestion/commit/d010986f394ebc7e4c7259d2a83ca446a1340fbf))
* **zoho_crm:** initial implementation of zoho crm ingestion ([#71](https://github.com/fluidtruck-data/ingestion/issues/71)) ([50ec9cf](https://github.com/fluidtruck-data/ingestion/commit/50ec9cf70f4ad50304d627e4357e546e569ca6a5))


### :wrench: Chores

* allow for empty initial call ([#75](https://github.com/fluidtruck-data/ingestion/issues/75)) ([6191a57](https://github.com/fluidtruck-data/ingestion/commit/6191a57f146908e8d4c49c29d26f113b6114fb35))

## [1.3.3](https://github.com/fluidtruck-data/ingestion/compare/v1.3.2...v1.3.3) (2025-03-25)


### :wrench: Chores

* emails to kingbee-vans ([#72](https://github.com/fluidtruck-data/ingestion/issues/72)) ([4c934a8](https://github.com/fluidtruck-data/ingestion/commit/4c934a83fa79bb5ef4378c65199e18322454b6f1))

## [1.3.2](https://github.com/fluidtruck-data/ingestion/compare/v1.3.1...v1.3.2) (2025-01-14)


### :wrench: Chores

* set cpu and mem resources ([4879778](https://github.com/fluidtruck-data/ingestion/commit/4879778e54402055e43d00a96b8583ffb527a4ca))
* set cpu and mem resources ([54cbbf7](https://github.com/fluidtruck-data/ingestion/commit/54cbbf759099434419dc97a79a19fdd30eb0f137))

## [1.3.1](https://github.com/fluidtruck-data/ingestion/compare/v1.3.0...v1.3.1) (2024-12-06)


### :wrench: Chores

* ignore 403 response when calling threads ([#68](https://github.com/fluidtruck-data/ingestion/issues/68)) ([f46d94d](https://github.com/fluidtruck-data/ingestion/commit/f46d94daa8ee695aa3acefcbb10fc2cc95a83973))

## [1.3.0](https://github.com/fluidtruck-data/ingestion/compare/v1.2.9...v1.3.0) (2024-12-02)


### :sparkles: Features

* run 11PM Denver all tickets, check all threads ([#66](https://github.com/fluidtruck-data/ingestion/issues/66)) ([8a56e4d](https://github.com/fluidtruck-data/ingestion/commit/8a56e4dfea48e2150ab7f82f55a70cc4c59f6077))

## [1.2.9](https://github.com/fluidtruck-data/ingestion/compare/v1.2.8...v1.2.9) (2024-11-07)


### :wrench: Chores

* look for isDeleted marked tickets ([d9b8cfa](https://github.com/fluidtruck-data/ingestion/commit/d9b8cfae910301967c5550124eeff2497d7f9dde))
* remove logging ([b682120](https://github.com/fluidtruck-data/ingestion/commit/b682120e8b243ffdd5c902b41529f434b4442820))

## [1.2.8](https://github.com/fluidtruck-data/ingestion/compare/v1.2.7...v1.2.8) (2024-10-15)


### :wrench: Chores

* add stripe fetch ([#62](https://github.com/fluidtruck-data/ingestion/issues/62)) ([a49d337](https://github.com/fluidtruck-data/ingestion/commit/a49d3376af2d65faed7993f1dd77cd55885a17f2))
* adjust helm version to 2.2.3 ([#64](https://github.com/fluidtruck-data/ingestion/issues/64)) ([f6052e2](https://github.com/fluidtruck-data/ingestion/commit/f6052e2da4d2d644802f6803572aaf67a3aa2914))

## [1.2.7](https://github.com/fluidtruck-data/ingestion/compare/v1.2.6...v1.2.7) (2024-10-02)


### :wrench: Chores

* add / ([73a46f0](https://github.com/fluidtruck-data/ingestion/commit/73a46f06b97877e7ad7a5eb8f165f9dd632528fb))
* change dir ([#60](https://github.com/fluidtruck-data/ingestion/issues/60)) ([2a43f34](https://github.com/fluidtruck-data/ingestion/commit/2a43f346e3685f668ad41fb327af7822a808960a))
* remove newrelic ([#58](https://github.com/fluidtruck-data/ingestion/issues/58)) ([0825457](https://github.com/fluidtruck-data/ingestion/commit/08254571b2d3c273fd490883be151200055338a2))
* wrap uvicorn in logger ([#61](https://github.com/fluidtruck-data/ingestion/issues/61)) ([a978d1c](https://github.com/fluidtruck-data/ingestion/commit/a978d1cf49f6c6d4b20a1dea4017f2cf2517a47a))

## [1.2.6](https://github.com/fluidtruck-data/ingestion/compare/v1.2.5...v1.2.6) (2024-09-27)


### :hammer: Code Refactoring

* move fetches out ([#56](https://github.com/fluidtruck-data/ingestion/issues/56)) ([9076e34](https://github.com/fluidtruck-data/ingestion/commit/9076e34be4bc8b35a67a880f70bff69330600f29))


### :wrench: Chores

* change lookback ([#54](https://github.com/fluidtruck-data/ingestion/issues/54)) ([18c5a66](https://github.com/fluidtruck-data/ingestion/commit/18c5a666ef11fa16068b950a5ce652a5662bc716))
* **zoho_desk_deleted:** add way to identify removed tickets ([#57](https://github.com/fluidtruck-data/ingestion/issues/57)) ([0426162](https://github.com/fluidtruck-data/ingestion/commit/04261623683060063ee61f6add6df83276507ba2))

## [1.2.5](https://github.com/fluidtruck-data/ingestion/compare/v1.2.4...v1.2.5) (2024-08-14)


### :bug: Bug Fixes

* ensure stage is moved on dependent fetch ([#52](https://github.com/fluidtruck-data/ingestion/issues/52)) ([0973b96](https://github.com/fluidtruck-data/ingestion/commit/0973b96d4a57121d98d39d0491197b66ee1fa602))

## [1.2.4](https://github.com/fluidtruck-data/ingestion/compare/v1.2.3...v1.2.4) (2024-08-14)


### :wrench: Chores

* adding Customer IO fetch class. ([#49](https://github.com/fluidtruck-data/ingestion/issues/49)) ([b9f8745](https://github.com/fluidtruck-data/ingestion/commit/b9f874500ceeee1024df53adf96b81a441302726))
* remove unnecessary logging ([#51](https://github.com/fluidtruck-data/ingestion/issues/51)) ([bc4b6c9](https://github.com/fluidtruck-data/ingestion/commit/bc4b6c9210fe2e15f1966ea1eb1edab17e29f9dc))

## [1.2.3](https://github.com/fluidtruck-data/ingestion/compare/v1.2.2...v1.2.3) (2024-07-02)


### :wrench: Chores

* bypass dialpad backend error and truncate buffers on start ([#48](https://github.com/fluidtruck-data/ingestion/issues/48)) ([3d512e6](https://github.com/fluidtruck-data/ingestion/commit/3d512e69223c197b4b94b21b579ef783e8c8799e))


### :robot: CI/CD

* allow k8s restart ([#46](https://github.com/fluidtruck-data/ingestion/issues/46)) ([ace3f4a](https://github.com/fluidtruck-data/ingestion/commit/ace3f4afbab91a4f0d03911b2a6c3869e9282947))

## [1.2.2](https://github.com/fluidtruck-data/ingestion/compare/v1.2.1...v1.2.2) (2024-05-20)


### :bug: Bug Fixes

* ignore stage when archiving ([#44](https://github.com/fluidtruck-data/ingestion/issues/44)) ([df09990](https://github.com/fluidtruck-data/ingestion/commit/df0999087bed003b63701a2c279511676f2b3803))

## [1.2.1](https://github.com/fluidtruck-data/ingestion/compare/v1.2.0...v1.2.1) (2024-05-20)


### :bug: Bug Fixes

* archive and load stage new name bug ([#42](https://github.com/fluidtruck-data/ingestion/issues/42)) ([dc5f7f6](https://github.com/fluidtruck-data/ingestion/commit/dc5f7f699e86553e8d30d6dfd8c769c09e094179))
* dependent threads need to call archive method ([#43](https://github.com/fluidtruck-data/ingestion/issues/43)) ([ef3db6e](https://github.com/fluidtruck-data/ingestion/commit/ef3db6ea9327e7bc48ace6b367909cc4b8d00fef))


### :wrench: Chores

* add staging for GCS ([#41](https://github.com/fluidtruck-data/ingestion/issues/41)) ([715e79c](https://github.com/fluidtruck-data/ingestion/commit/715e79cdc04763c334459de68ad04267801d6932))
* adjust retry-emails for lower level ([#39](https://github.com/fluidtruck-data/ingestion/issues/39)) ([2552c79](https://github.com/fluidtruck-data/ingestion/commit/2552c79d497c34b4154ba58beaf74ecaf2114702))

## [1.2.0](https://github.com/fluidtruck-data/ingestion/compare/v1.1.9...v1.2.0) (2024-05-15)


### :sparkles: Features

* migrate to new framework ([#35](https://github.com/fluidtruck-data/ingestion/issues/35)) ([d2dcaba](https://github.com/fluidtruck-data/ingestion/commit/d2dcabac004c44ae27d19486ccac1a67ba3a9b0e))


### :wrench: Chores

* add Reach360 Fetchers and max retry email notifications ([#38](https://github.com/fluidtruck-data/ingestion/issues/38)) ([06b9ca8](https://github.com/fluidtruck-data/ingestion/commit/06b9ca8926c7dc664b04590434549b31ff4e5a54))


### :robot: CI/CD

* account for release-please repo migration ([#37](https://github.com/fluidtruck-data/ingestion/issues/37)) ([21e6a6c](https://github.com/fluidtruck-data/ingestion/commit/21e6a6c58017b1933e936dac177d4ca8f9356166))

## [1.1.9](https://github.com/fluidtruck-data/ingestion/compare/v1.1.8...v1.1.9) (2024-05-06)


### :bug: Bug Fixes

* pass logging to decorator ([#33](https://github.com/fluidtruck-data/ingestion/issues/33)) ([27e1412](https://github.com/fluidtruck-data/ingestion/commit/27e14129412c5e401fdefaa6219e2352d9a018f8))

## [1.1.8](https://github.com/fluidtruck-data/ingestion/compare/v1.1.7...v1.1.8) (2024-05-01)


### :bug: Bug Fixes

* retry decorator ([#31](https://github.com/fluidtruck-data/ingestion/issues/31)) ([ef5644f](https://github.com/fluidtruck-data/ingestion/commit/ef5644f7a220fa91313c7ac3c1232efd3cedf196))

## [1.1.7](https://github.com/fluidtruck-data/ingestion/compare/v1.1.6...v1.1.7) (2024-04-30)


### :bug: Bug Fixes

* remove zoho desk and add better retries ([#28](https://github.com/fluidtruck-data/ingestion/issues/28)) ([1f2889f](https://github.com/fluidtruck-data/ingestion/commit/1f2889f8e2f63a601da31259d91f53f70ead7022))
* remove zoho desk from background threads ([#30](https://github.com/fluidtruck-data/ingestion/issues/30)) ([ce77eda](https://github.com/fluidtruck-data/ingestion/commit/ce77eda36a836729f71f9041e511d94b74de7736))

## [1.1.6](https://github.com/fluidtruck-data/ingestion/compare/v1.1.5...v1.1.6) (2024-03-22)


### :wrench: Chores

* update logging for GCP and filter out extra ([#26](https://github.com/fluidtruck-data/ingestion/issues/26)) ([7e26a0f](https://github.com/fluidtruck-data/ingestion/commit/7e26a0fd7fccb6598d30c2e0d03fa225fd9463b6))

## [1.1.5](https://github.com/fluidtruck-data/ingestion/compare/v1.1.4...v1.1.5) (2024-03-20)


### :wrench: Chores

* add completion email ([#22](https://github.com/fluidtruck-data/ingestion/issues/22)) ([f6282e2](https://github.com/fluidtruck-data/ingestion/commit/f6282e297ea1ac3c7e2649d698ed8c1fc6ba2eef))
* add ENV subfolders ([#25](https://github.com/fluidtruck-data/ingestion/issues/25)) ([ee64740](https://github.com/fluidtruck-data/ingestion/commit/ee647408ddc39de0844d3da0ee2f9cb75f54d72f))


### :robot: CI/CD

* update release-please ([#24](https://github.com/fluidtruck-data/ingestion/issues/24)) ([04dedda](https://github.com/fluidtruck-data/ingestion/commit/04dedda8570c402003c482ae144060cfdde9b73d))

## [1.1.4](https://github.com/fluidtruck-data/ingestion/compare/v1.1.3...v1.1.4) (2024-03-04)


### :robot: CI/CD

* bump chart version ([#20](https://github.com/fluidtruck-data/ingestion/issues/20)) ([375d565](https://github.com/fluidtruck-data/ingestion/commit/375d565687e9b83aeffbc88bdd64bec84ace14d5))

## [1.1.3](https://github.com/fluidtruck-data/ingestion/compare/v1.1.2...v1.1.3) (2023-12-11)


### :wrench: Chores

* **deps:** bump google-github-actions/release-please-action from 3 to 4 ([#15](https://github.com/fluidtruck-data/ingestion/issues/15)) ([ed14996](https://github.com/fluidtruck-data/ingestion/commit/ed149969842e2aca1cdbeaf0364ea0d5ecbfc36e))
* logging to INFO ([#19](https://github.com/fluidtruck-data/ingestion/issues/19)) ([3d96b46](https://github.com/fluidtruck-data/ingestion/commit/3d96b46bd525c5709c39d87f242300f87d9da299))
* revert release-please breaking changes ([#16](https://github.com/fluidtruck-data/ingestion/issues/16)) ([44b96a1](https://github.com/fluidtruck-data/ingestion/commit/44b96a141a48b0165b12f3c1ffad1a3715032974))

## [1.1.2](https://github.com/fluidtruck-data/ingestion/compare/v1.1.1...v1.1.2) (2023-11-22)


### :wrench: Chores

* clear completed ([#13](https://github.com/fluidtruck-data/ingestion/issues/13)) ([f632fca](https://github.com/fluidtruck-data/ingestion/commit/f632fcaa35acbf251d10530c61e4ffe337b190b7))

## [1.1.1](https://github.com/fluidtruck-data/ingestion/compare/v1.1.0...v1.1.1) (2023-11-22)


### :bug: Bug Fixes

* add logging ([23e4647](https://github.com/fluidtruck-data/ingestion/commit/23e464739dadfdf388dc4db350656fe5f1e27e08))
* avro naming by environment ([a2530e5](https://github.com/fluidtruck-data/ingestion/commit/a2530e52833e89340188b68fb64ec06d93ec36e5))
* handle multiple threads in queue ([#11](https://github.com/fluidtruck-data/ingestion/issues/11)) ([4aa4d99](https://github.com/fluidtruck-data/ingestion/commit/4aa4d994fc7bcbb4094c327d49494fa2b1154738))


### :wrench: Chores

* update upload file ([8c94e68](https://github.com/fluidtruck-data/ingestion/commit/8c94e68ec8b3818cf0341e66553b167ea65994ca))

## [1.1.0](https://github.com/fluidtruck-data/ingestion/compare/v1.0.0...v1.1.0) (2023-11-17)


### :sparkles: Features

* queueing, token refresh, parsing fix ([#8](https://github.com/fluidtruck-data/ingestion/issues/8)) ([15e1ca5](https://github.com/fluidtruck-data/ingestion/commit/15e1ca58f826fee7e730a5201d4dd565b05d271c))


### :wrench: Chores

* add zoho desk env vars ([#4](https://github.com/fluidtruck-data/ingestion/issues/4)) ([2169fe1](https://github.com/fluidtruck-data/ingestion/commit/2169fe1d3e818fea1c01f629760959d887db0202))
* change bucket access ([#9](https://github.com/fluidtruck-data/ingestion/issues/9)) ([c637365](https://github.com/fluidtruck-data/ingestion/commit/c6373652c35a07e87172ab8b60849f9a538a8352))
* lock background to prod ([#10](https://github.com/fluidtruck-data/ingestion/issues/10)) ([516e810](https://github.com/fluidtruck-data/ingestion/commit/516e810e49087ca95282bfe49a5357379e391d71))
* update for local running ([#7](https://github.com/fluidtruck-data/ingestion/issues/7)) ([c36ea67](https://github.com/fluidtruck-data/ingestion/commit/c36ea67de38af739ee681834f1b1e451b15810cf))


### :robot: CI/CD

* add ruff ([#6](https://github.com/fluidtruck-data/ingestion/issues/6)) ([4176167](https://github.com/fluidtruck-data/ingestion/commit/41761676fa7f8ca9fd3291973e85dbd15f517a99))

## 1.0.0 (2023-11-03)


### :sparkles: Features

* initial transfer of existing code ([#2](https://github.com/fluidtruck-data/ingestion/issues/2)) ([454ecb1](https://github.com/fluidtruck-data/ingestion/commit/454ecb188c9f0ccd139d24ee3d5bccb2203f9521))


### :wrench: Chores

* fix requirements ([#3](https://github.com/fluidtruck-data/ingestion/issues/3)) ([797cecf](https://github.com/fluidtruck-data/ingestion/commit/797cecfa4d816ab6b4c534c5db6723ae5ec9c2bc))
* scaffolded with backstage :tada: ([0cfa8fe](https://github.com/fluidtruck-data/ingestion/commit/0cfa8fe2e2920fccaa76e34f14613c659fbf25b4))

## 1.0.0 (2023-11-03)


### :sparkles: Features

* initial transfer of existing code ([#2](https://github.com/fluidtruck-data/ingestion/issues/2)) ([454ecb1](https://github.com/fluidtruck-data/ingestion/commit/454ecb188c9f0ccd139d24ee3d5bccb2203f9521))


### :wrench: Chores

* scaffolded with backstage :tada: ([0cfa8fe](https://github.com/fluidtruck-data/ingestion/commit/0cfa8fe2e2920fccaa76e34f14613c659fbf25b4))
