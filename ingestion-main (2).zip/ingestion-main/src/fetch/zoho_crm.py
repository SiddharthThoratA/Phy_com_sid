import logging
import time
from datetime import datetime, timedelta

from config import can_call_rate_limiter
from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator


class ZohoCrmFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()

        if not response.text.strip():
            logging.info(f"Empty response received from {endpoint}")
            return {}

        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        page = 1
        filter_by = None
        self.api_instance.avro_writer.clear_buffer()

        # Apply filter to all modules except users
        apply_filter = self.api_instance.call_endpoint != "users"

        if apply_filter:
            yesterday_start = (datetime.utcnow() - timedelta(days=1)).strftime(
                "%Y-%m-%dT00:00:00Z"
            )
            current_time = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
            filter_by = f"Modified_Time:between:{yesterday_start},{current_time}"
            base_url, module_name = self.api_instance.endpoint.rsplit("/", 1)
            module_name = module_name.capitalize()
            logging.info(f"Module Name is : {module_name}")

            self.api_instance.endpoint = f"{base_url}/{module_name}/search"

        while True:
            params = {"page": page, "per_page": 200}
            if apply_filter:
                params["criteria"] = filter_by

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)
            endpoint = self.api_instance.endpoint
            data = self._call_api(endpoint, params)
            if self.api_instance.call_endpoint == "users":
                items = data.get("users", None)
            else:
                items = data.get("data", None)

            if items:
                self.api_instance.avro_writer.add_records(items)
                if len(items) < params["per_page"]:
                    self.api_instance.avro_writer.flush_buffer()
                    break
            elif not items and page == 1:
                logging.info(
                    f"No data found for {self.api_instance.call_endpoint} on initial call."
                )
                break
            elif data and not items:
                self.api_instance.avro_writer.add_records([data])
            else:
                self.api_instance.avro_writer.flush_buffer()
                break
            page += 1
