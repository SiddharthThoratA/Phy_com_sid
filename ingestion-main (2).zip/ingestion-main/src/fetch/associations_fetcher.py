import logging
import time
from config import can_call_rate_limiter, HUBSPOT_OBJECT_INGESTION_MAPPING
from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator


class HubspotAssociationsFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)

        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )

        object_key = self.api_instance.call_endpoint
        object_id = HUBSPOT_OBJECT_INGESTION_MAPPING.get(object_key, object_key)

        has_more = True
        after = None
        page_count = 0

        self.api_instance.avro_writer.clear_buffer()
        endpoint = f"{self.api_instance.endpoint}/crm/v3/objects/{object_id}"
        logging.info(f"Calling endpoint: {endpoint}")

        while has_more:
            params = {
                "limit": 100,
                "archived": "false",
                "associations": [
                    "0-1",
                    "0-2",
                    "0-3",
                    "0-5",
                    "0-7",
                    "0-8",
                    "0-14",
                    "0-48",
                    "0-49",
                    "0-47",
                    "0-46",
                    "0-27",
                    "0-116",
                    "0-19",
                    "0-136",
                    "engagements",
                    "p7609565_vehicle_contracts",
                    "p7609565_tolls",
                    "p7609565_vehicles",
                    "p7609565_inspections",
                    "p7609565_shipping",
                    "p7609565_kbr_inventory",
                    "p7609565_times",
                ],
            }

            if after:
                params["after"] = after

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)

            data = self._call_api(endpoint, params=params)
            items = data.get("results", None)

            flattened_data = []

            for item in items:
                from_id = item.get("id")
                associations = item.get("associations", {})
                for to_object, assoc_data in associations.items():
                    flattened_data.append(
                        {
                            "from_object_id": from_id,
                            "from_object": f"{self.api_instance.call_endpoint}",
                            "to_object": to_object,
                            "association_data": assoc_data.get("results", []),
                        }
                    )

            # Write batch of 100 records into avro file
            if flattened_data:
                self.api_instance.avro_writer.add_records(flattened_data)

            # Set `after` only if there's a next page
            paging = data.get("paging")
            if paging and paging.get("next") and paging["next"].get("after"):
                after = paging["next"]["after"]
                page_count += 1
            else:
                has_more = False
                after = None

        logging.info("Finalizing uploads... archiving staged files.")
        self.api_instance.avro_writer.flush_buffer()
