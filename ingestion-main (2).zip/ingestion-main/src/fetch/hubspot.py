import json
import logging
import time
from datetime import datetime, timezone

from google.cloud import bigquery

from avro.avro_writer import AvroWriter
from config import HUBSPOT_OBJECT_INGESTION_MAPPING, can_call_rate_limiter
from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator


class HubspotFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)
        self._obj_details_writer = AvroWriter(api_instance.api_name, "object_details")
        self._prop_details_writer = AvroWriter(
            api_instance.api_name, "property_details"
        )
        self._archived_records_writer = AvroWriter(
            api_instance.api_name, "archived_records"
        )

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict = None) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)

        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _post_api(self, endpoint: str, params: dict = None) -> dict:
        while not can_call_rate_limiter("hubspot_search"):
            time.sleep(1)
        response = self.api_instance.session.post(endpoint, json=params)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _get_max_last_updated(table) -> int | None:
        """
        Get the maximum last updated timestamp from the BigQuery table
        """
        client = bigquery.Client()
        query = f"SELECT MAX(_last_updated) AS max_last_updated FROM `deft-bonsai-304315.hubspot.{table}`"
        query_job = client.query(query)
        result = query_job.result()
        row = next(result, None)
        return int(row.max_last_updated) if row else None

    def _fetch_object_properties(self):
        """
        Fetch all properties for the object type
        """
        logging.info(
            f"Fetching properties for {self.api_instance.call_endpoint} from Hubspot API"
        )
        if self.api_instance.call_endpoint in HUBSPOT_OBJECT_INGESTION_MAPPING:
            properties_endpoint = f"https://api.hubapi.com/crm/v3/schemas/{HUBSPOT_OBJECT_INGESTION_MAPPING[self.api_instance.call_endpoint]}"
        else:
            properties_endpoint = f"https://api.hubapi.com/crm/v3/schemas/{self.api_instance.call_endpoint}"
        updated_headers = self.api_instance.auth.get_headers()
        self.api_instance.session.headers.update(updated_headers)
        result = self._call_api(properties_endpoint)
        return result

    @staticmethod
    def _timestamp_to_unix_ms(timestamp: str | int) -> int:
        """Convert ISO 8601 'Z' string or numeric timestamp into Unix ms."""
        if isinstance(timestamp, str):
            ts = timestamp.strip()
            ts = ts.replace("Z", "+00:00").replace(" UTC", "+00:00")

            dt = datetime.fromisoformat(ts)

            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)

            return int(dt.timestamp() * 1_000)
        return int(timestamp)

    def _is_after_cutoff(
        self, item: dict[str, any], cutoff_ms: int, is_prop_with_history: bool = False
    ) -> bool:
        """Return True if lastmodifieddate or createdate > cutoff_ms."""
        if is_prop_with_history:
            ts_str = item.get("timestamp")
        else:
            props = item.get("properties", {})
            ts_str = props.get("hs_lastmodifieddate") or props.get("createdate")
        if ts_str is None:
            return False
        return self._timestamp_to_unix_ms(ts_str) > cutoff_ms

    def _filter_history(self, properties_with_history, cutoff_ms):
        """Filter property history to only include records after the cutoff date"""
        results = []

        for prop_name, history_values in properties_with_history.items():
            if not history_values:
                continue

            filtered_values = [
                entry
                for entry in history_values
                if self._is_after_cutoff(entry, cutoff_ms, is_prop_with_history=True)
            ]

            for entry in filtered_values:
                obj = dict(entry)
                obj["property_name"] = prop_name
                results.append(obj)

        return results if results else None

    def _get_batch_data_with_history(self, object_type, ids, property_names, cutoff_ms):
        """
        Batch request to get properties and property history for multiple IDs

        Args:
            object_type: The HubSpot object type (contacts, companies, etc.)
            ids: List of object IDs to fetch
            property_names: List of property names to fetch
            cutoff_ms: Timestamp cutoff for filtering history (in milliseconds)

        Returns:
            List of records with id, properties, and properties_with_history
        """
        records = []
        if self.api_instance.call_endpoint in HUBSPOT_OBJECT_INGESTION_MAPPING:
            batch_endpoint = f"https://api.hubapi.com/crm/v3/objects/{HUBSPOT_OBJECT_INGESTION_MAPPING[self.api_instance.call_endpoint]}/batch/read"
        else:
            batch_endpoint = (
                f"https://api.hubapi.com/crm/v3/objects/{object_type}/batch/read"
            )

        if self.api_instance.call_endpoint == "contacts":
            last_mod = "lastmodifieddate"
        else:
            last_mod = "hs_lastmodifieddate"
        payload = {
            "inputs": [{"id": str(obj_id)} for obj_id in ids],
            "properties": property_names,
            "propertiesWithHistory": property_names,
        }

        updated_headers = self.api_instance.auth.get_headers()
        self.api_instance.session.headers.update(updated_headers)

        response = self._post_api(batch_endpoint, payload)
        latest_ts = cutoff_ms

        for item in response.get("results", []):
            obj_id = str(item.get("id"))
            item_copy = item.copy()
            item_copy.pop("id", None)

            props = None
            props_hist = None

            if "properties" in item_copy:
                props = {
                    k: v for k, v in item_copy["properties"].items() if v is not None
                }

            if "propertiesWithHistory" in item_copy:
                props_hist = self._filter_history(
                    item_copy["propertiesWithHistory"], cutoff_ms
                )

            records.append(
                {
                    "id": obj_id,
                    "properties": json.dumps(props),
                    "properties_with_history": json.dumps(props_hist)
                    if props_hist
                    else None,
                }
            )
            ts = item.get("properties", {}).get(last_mod)
            if not ts:
                ts = item.get("properties", {}).get("createdate")
            if ts:
                ts_ms = self._timestamp_to_unix_ms(ts)
                if ts_ms > latest_ts:
                    latest_ts = ts_ms

        return records, latest_ts

    def _fetch_with_search_pagination(
        self, endpoint, request_json, property_names, cutoff_ms
    ):
        """
        Handle API pagination for the search endpoint

        Args:
            endpoint: API endpoint for the search
            request_json: Base request payload
            property_names: List of property names to fetch
            cutoff_ms: Timestamp cutoff for filtering history
            max_pages: Safety limit for pagination (default: 100)

        Returns:
            Total count of records processed
        """
        has_more = True
        page_count = 0
        total_processed = 0
        latest_ts = cutoff_ms

        while has_more:
            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)

            if page_count % 100 == 0:
                logging.info(
                    f"Calling {self.api_instance.call_endpoint} search endpoint (page {page_count+1}), total processed: {total_processed}"
                )
            response = self._post_api(endpoint, request_json)

            items = response.get("results", [])

            if items != []:
                ids = [item["id"] for item in items]

                combined_data, latest_ts = self._get_batch_data_with_history(
                    object_type=self.api_instance.call_endpoint,
                    ids=ids,
                    property_names=property_names,
                    cutoff_ms=cutoff_ms,
                )

                if combined_data:
                    self.api_instance.avro_writer.add_records(combined_data)
                    total_processed += len(combined_data)

                paging = response.get("paging")
                if paging and paging.get("next"):
                    request_json["after"] = paging["next"]["after"]
                    page_count += 1
                else:
                    has_more = False
            else:
                has_more = False

            if not items or len(items) < request_json["limit"]:
                break
            if total_processed == 10000:
                break

        return total_processed, latest_ts

    def _fetch_archived_records(self):
        """
        Fetch archived records using the standard objects endpoint with archived=true
        Uses a two-step process to avoid URL length limitations:
        1. Get IDs of archived records
        2. Batch fetch properties for those IDs

        If there starts to be a heavy increased usage of archiving this will need to
        follow the same pattern of the non-archived records
        """
        logging.info(f"Fetching archived {self.api_instance.call_endpoint} records...")

        if self.api_instance.call_endpoint in HUBSPOT_OBJECT_INGESTION_MAPPING:
            objects_endpoint = f"https://api.hubapi.com/crm/v3/objects/{HUBSPOT_OBJECT_INGESTION_MAPPING[self.api_instance.call_endpoint]}"
        else:
            objects_endpoint = f"https://api.hubapi.com/crm/v3/objects/{self.api_instance.call_endpoint}"

        has_more = True
        page_count = 0
        total_processed = 0
        after = None
        max_pages = 100
        batch_size = 50

        while has_more and page_count < max_pages:
            params = {
                "limit": batch_size,
                "archived": "true",
            }

            if after:
                params["after"] = after

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)

            logging.info(
                f"Calling objects endpoint for archived records - {self.api_instance.call_endpoint} (page {page_count+1})"
            )
            response = self._call_api(objects_endpoint, params)

            items = response.get("results", [])
            logging.info(
                f"Received {len(items)} archived records - {self.api_instance.call_endpoint}."
            )

            records = []

            for item in items:
                obj_id = str(item.get("id"))
                item_copy = item.copy()
                item_copy.pop("id", None)

                records.append(
                    {
                        "call_endpoint": objects_endpoint.split("/")[-1],
                        "id": obj_id,
                        "hs_last_modified_date": item_copy.get("properties", {}).get(
                            "hs_lastmodifieddate", None
                        ),
                    }
                )
            if records != []:
                self._archived_records_writer.clear_buffer()
                self._archived_records_writer.add_records(records)
                fixed_records_path = (
                    self._archived_records_writer._upload_folder
                    + f"{self.api_instance.call_endpoint}_archived_records.avro"
                )
                self._archived_records_writer._write_to_file(fixed_records_path)

            total_processed += len(records)
            return total_processed

    def _run_pass(
        self,
        filter_field: str | None,
        search_endpoint: str,
        property_names: list[str],
        start_time: int,
        extra_filter: dict | None = None,
    ) -> int:
        records_total = 0
        cutoff_ms = start_time
        while True:
            logging.info(f"Fetching with {filter_field=} and {start_time=}")

            filter_group = {
                "filters": [
                    {
                        "propertyName": filter_field,
                        "operator": "GTE",
                        "value": str(start_time),
                    }
                ]
            }
            if extra_filter:
                filter_group["filters"].append(extra_filter)

            request_json = {
                "filterGroups": [filter_group],
                "properties": ["id", filter_field],
                "sorts": [{"propertyName": filter_field, "direction": "ASCENDING"}],
                "limit": 50,
            }

            records_in_window, latest_ts = self._fetch_with_search_pagination(
                endpoint=search_endpoint,
                request_json=request_json,
                property_names=property_names,
                cutoff_ms=cutoff_ms,
            )

            records_total += records_in_window
            logging.info(
                f"Processed {records_in_window} {self.api_instance.call_endpoint} records in current window"
            )

            if records_in_window < 10000:
                break
            start_time = latest_ts

        return records_total

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        """
        Main method to fetch data from HubSpot, including properties and history
        Handles the 10K search record limit by using timestamp-based windowing
        """
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        self.api_instance.avro_writer.clear_buffer()

        object_properties = self._fetch_object_properties()

        properties = object_properties.get("properties", [])
        prop_recs = []
        if properties:
            for p in properties:
                rec = p.copy()
                rec["objectTypeId"] = object_properties.get("objectTypeId", None)
                prop_recs.append(rec)

            if prop_recs:
                self._prop_details_writer.clear_buffer()
                self._prop_details_writer.add_records(prop_recs)
                fixed_prop_path = (
                    self._prop_details_writer._upload_folder
                    + f"{self.api_instance.call_endpoint}_property_details.avro"
                )
                self._prop_details_writer._write_to_file(fixed_prop_path)

        # NOTE: all associations types are also here
        object_properties.pop("properties")
        self._obj_details_writer.add_records([object_properties])
        fixed_obj_path = (
            self._obj_details_writer._upload_folder
            + f"{self.api_instance.call_endpoint}_object_details.avro"
        )
        self._obj_details_writer._write_to_file(fixed_obj_path)

        excluded_field_types = {"calculation_equation", "calculation_read_time"}
        filtered_properties = [
            item
            for item in properties
            if "fieldType" in item and item["fieldType"] not in excluded_field_types
        ]
        property_names = [
            item["name"] for item in filtered_properties if "name" in item
        ]
        if self.api_instance.call_endpoint == "users":
            return

        # NOTE: if a new object is being added consider hardcoding an older start time for the initial local run.
        start_time = self._get_max_last_updated(self.api_instance.call_endpoint)

        if self.api_instance.call_endpoint in HUBSPOT_OBJECT_INGESTION_MAPPING:
            search_endpoint = f"{self.api_instance.endpoint}crm/v3/objects/{HUBSPOT_OBJECT_INGESTION_MAPPING[self.api_instance.call_endpoint]}/search"
        else:
            search_endpoint = f"{self.api_instance.endpoint}crm/v3/objects/{self.api_instance.call_endpoint}/search"

        if self.api_instance.call_endpoint == "contacts":
            last_mod = "lastmodifieddate"
        else:
            last_mod = "hs_lastmodifieddate"

        archived_records = self._fetch_archived_records()
        logging.info(
            f"Processed {archived_records} - {self.api_instance.call_endpoint} archived records"
        )

        logging.info(
            f"Processing non-archived - {self.api_instance.call_endpoint} records modified/added after: {start_time}"
        )

        total_records = 0

        total_records += self._run_pass(
            filter_field=last_mod,
            start_time=start_time,
            search_endpoint=search_endpoint,
            property_names=property_names,
        )

        total_records += self._run_pass(
            filter_field="hs_createdate",
            start_time=start_time,
            search_endpoint=search_endpoint,
            property_names=property_names,
            extra_filter={
                "propertyName": last_mod,
                "operator": "NOT_HAS_PROPERTY",
            },
        )

        logging.info(
            f"Total {self.api_instance.call_endpoint} records processed: {total_records}"
        )
        if total_records > 0:
            self.api_instance.avro_writer.flush_buffer()
