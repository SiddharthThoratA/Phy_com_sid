import logging
import time
from config import can_call_rate_limiter
from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator

class HubspotUsersFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)

        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )

        has_more = True
        after = None

        self.api_instance.avro_writer.clear_buffer()
        endpoint = f"{self.api_instance.endpoint}"

        logging.info(f"Calling endpoint: {endpoint}")

        while has_more:
            params = {"limit": 100}
            if after:
                params["after"] = after

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)

            data = self._call_api(endpoint, params=params)
            items = data.get("results", None)

            self.api_instance.avro_writer.add_records(items)

            if not items or len(items) < params["limit"]:
                self.api_instance.avro_writer.flush_buffer()
                break

            paging = data.get("paging")
            if paging and paging.get("next") and paging["next"].get("after"):
                after = paging["next"]["after"]
            else:
                has_more = False

        logging.info("Finalizing uploads... archiving staged files.")
        self.api_instance.avro_writer.flush_buffer()


class HubspotOwnersFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)

        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )

        self.api_instance.avro_writer.clear_buffer()
        endpoint = f"{self.api_instance.endpoint}"
        logging.info(f"Calling endpoint: {endpoint}")

        # Loop for both active and archived owners
        for archived in [False, True]:
            has_more = True
            after = None
            logging.info(f"Fetching archived - {archived} owners")

            while has_more:
                params = {"limit": 100,"archived": archived}
                if after:
                    params["after"] = after

                updated_headers = self.api_instance.auth.get_headers()
                self.api_instance.session.headers.update(updated_headers)

                data = self._call_api(endpoint, params=params)
                items = data.get("results", None)

                self.api_instance.avro_writer.add_records(items)

                paging = data.get("paging")
                if paging and paging.get("next") and paging["next"].get("after"):
                    after = paging["next"]["after"]
                else:
                    has_more = False

        logging.info("Finalizing uploads... archiving staged files.")
        self.api_instance.avro_writer.flush_buffer()
