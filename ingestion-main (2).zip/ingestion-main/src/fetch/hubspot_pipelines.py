import logging
import time
import json
from config import can_call_rate_limiter, HUBSPOT_PIPELINE_OBJECTS
from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator


class HubspotPipelinesFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)

        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    def _fetch_all_pipelines(self, object_type):
        """
        Fetch all pipelines for the given object type, handling pagination.
        """
        pipelines = []

        endpoint = f"{self.api_instance.endpoint}/crm/v3/pipelines/{object_type}"

        while True:
            params = {"limit": 100}

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)

            data = self._call_api(endpoint, params=params)
            items = data.get("results", [])

            pipelines.extend(items)

            paging = data.get("paging")
            if paging and paging.get("next"):
                after = paging["next"]["after"]
                params["after"] = after
            else:
                break

        return [(p["id"], p["label"]) for p in pipelines]

    def _fetch_pipeline_audit(self, object_type, pipeline_id):
        """
        Fetch audit logs for a specific pipeline and remove 'stages' from rawObject.
        """
        audit_logs = []
        endpoint = f"{self.api_instance.endpoint}/crm/v3/pipelines/{object_type}/{pipeline_id}/audit"

        while True:
            params = {"limit": 100}

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)

            try:
                logging.info(f"Fetching audit log from: {endpoint}")
                data = self._call_api(endpoint, params=params)
            except Exception as e:
                if "404" in str(e):
                    logging.warning(f"No audit log found for pipeline {pipeline_id}")
                    return []
                raise

            for log in data.get("results", []):
                raw_object_str = log.get("rawObject")
                if raw_object_str:
                    try:
                        raw_obj = json.loads(raw_object_str)
                        raw_obj.pop("stages", None)  # Remove 'stages' if present
                        log["rawObject"] = raw_obj
                    except json.JSONDecodeError:
                        logging.warning(
                            f"Could not parse rawObject for pipeline {pipeline_id}"
                        )
                audit_logs.append(log)

            paging = data.get("paging")
            if paging and paging.get("next"):
                after = paging["next"]["after"]
                params["after"] = after
            else:
                break

        return audit_logs

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching pipeline data and audit logs for: {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        """
            Loop through all object types, fetch pipelines and audit logs,
            and write everything to the same Avro file.
        """
        self.api_instance.avro_writer.clear_buffer()
        object_types = HUBSPOT_PIPELINE_OBJECTS

        for object_type in object_types:
            logging.info(f"Processing object type: {object_type}")

            pipelines = self._fetch_all_pipelines(object_type)

            for pipeline_id, pipeline_label in pipelines:
                logging.info(
                    f"Fetching audit for pipeline: {pipeline_label} (ID: {pipeline_id})"
                )
                try:
                    audit_logs = self._fetch_pipeline_audit(object_type, pipeline_id)

                    for log in audit_logs:
                        record = {"object_type": object_type, **log}
                        self.api_instance.avro_writer.add_records([record])

                except Exception as e:
                    logging.error(f"Error fetching audit for {pipeline_id}: {str(e)}")

        logging.info("Finalizing uploads... archiving staged Avro files.")
        self.api_instance.avro_writer.flush_buffer()


class HubspotPipelinesStageFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)

        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    def _fetch_all_pipelines(self, object_type: str):
        """
        Fetch all pipelines for the given object type, handling pagination.
        """
        pipelines = []

        endpoint = f"{self.api_instance.endpoint}/crm/v3/pipelines/{object_type}"

        while True:
            params = {"limit": 100}

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)

            data = self._call_api(endpoint, params=params)
            items = data.get("results", [])

            pipelines.extend(items)

            paging = data.get("paging")
            if paging and paging.get("next"):
                after = paging["next"]["after"]
                params["after"] = after
            else:
                break

        return [(p["id"], p["label"]) for p in pipelines]

    def _fetch_stage_ids(self, object_type: str, pipeline_id: str):
        endpoint = f"{self.api_instance.endpoint}/crm/v3/pipelines/{object_type}/{pipeline_id}/stages"
        params = {"limit": 100}

        updated_headers = self.api_instance.auth.get_headers()
        self.api_instance.session.headers.update(updated_headers)

        try:
            data = self._call_api(endpoint, params=params)
            return data.get("results", [])
        except Exception as e:
            if "404" in str(e):
                logging.warning(
                    f"Stage or pipeline not found for pipeline ID {pipeline_id}."
                )
                return []
            raise

    def _fetch_stage_audit(self, object_type, pipeline_id, stage_id):
        endpoint = f"{self.api_instance.endpoint}/crm/v3/pipelines/{object_type}/{pipeline_id}/stages/{stage_id}/audit"
        params = {"limit": 100}

        updated_headers = self.api_instance.auth.get_headers()
        self.api_instance.session.headers.update(updated_headers)

        all_logs = []

        while True:
            try:
                data = self._call_api(endpoint, params=params)
            except Exception as e:
                if "404" in str(e):
                    logging.warning(
                        f"Stage audit not found for stage ID {stage_id} in pipeline {pipeline_id}."
                    )
                    return []
                raise

            all_logs.extend(data.get("results", []))

            paging = data.get("paging")
            if paging and paging.get("next"):
                after = paging["next"]["after"]
                params["after"] = after
            else:
                break

        return all_logs

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        """
            Loop through all object types, fetch pipelines stage and audit logs,
            and write everything to the same Avro file.
        """
        self.api_instance.avro_writer.clear_buffer()
        object_types = HUBSPOT_PIPELINE_OBJECTS

        for object_type in object_types:
            logging.info(f"Processing object type: {object_type}")

            pipeline_ids = self._fetch_all_pipelines(object_type)

            for pipeline_id, _ in pipeline_ids:
                stages = self._fetch_stage_ids(object_type, pipeline_id)
                for stage in stages:
                    stage_id = stage.get("id")

                    audit_data = self._fetch_stage_audit(
                        object_type, pipeline_id, stage_id
                    )
                    for log in audit_data:
                        raw_object_str = log.get("rawObject")
                        if raw_object_str:
                            try:
                                raw_obj = json.loads(raw_object_str)
                                log["rawObject"] = raw_obj
                            except json.JSONDecodeError:
                                logging.warning(
                                    f"Could not parse rawObject for pipeline {pipeline_id}"
                                )
                        record = {
                            "object_type": object_type,
                            **log,  # append the rest of the log fields
                        }

                        self.api_instance.avro_writer.add_records([record])

        logging.info("Finalizing uploads... archiving staged files.")
        self.api_instance.avro_writer.flush_buffer()
