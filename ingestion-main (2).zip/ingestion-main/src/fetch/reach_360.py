import logging
import time

from avro.avro_writer import AvroWriter
from config import can_call_rate_limiter
from fetch.fetch_factory import FetchBase, FetchFactory
from utils.retry_decorator import retry_decorator


class Reach360Fetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params=None) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        columns_to_keep = None
        dependency_key_data = []
        nextUrl = self.api_instance.endpoint
        self.api_instance.avro_writer.clear_buffer()

        if self.api_instance.dependent_details:
            dependency_keys = set()
            for dependent in self.api_instance.dependent_details:
                dependency_keys.add(dependent["dependency_key"])
            columns_to_keep = list(dependency_keys)
            logging.info(
                f"{self.api_instance.api_name}-{self.api_instance.call_endpoint}: Columns to keep: {columns_to_keep}"
            )

        while True:
            data = self._call_api(endpoint=nextUrl)
            if self.api_instance.call_endpoint == "report/activity":
                json_level = "sessions"
            else:
                json_level = self.api_instance.call_endpoint

            items = data.get(json_level, [])
            if columns_to_keep and items:
                dependency_key_data.extend(
                    [
                        {k: v for k, v in item.items() if k in columns_to_keep}
                        for item in items
                    ]
                )
            if items:
                self.api_instance.avro_writer.add_records(items)
            nextUrl = data.get("nextUrl")
            if not nextUrl:
                self.api_instance.avro_writer.flush_buffer()
                break
        for dependent in self.api_instance.dependent_details:
            dependent_fetch = FetchFactory.get_dependent_fetch_class(
                self.api_instance, dependent["dependency_fetch_class"]
            )
            key_data = [
                {k: v for k, v in item.items() if k in dependent["dependency_key"]}
                for item in dependency_key_data
            ]
            dependent_fetch.fetch_data(key_data, dependent)


class DependentReach360Fetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)
        self.cursor = None

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params=None) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self, key_data, dependent):
        logging.info(
            f"Fetching dependent data from {self.api_instance.api_name}-{dependent['name']}"
        )
        avro_writer = AvroWriter(
            self.api_instance.api_name, f"reports_{dependent['name']}"
        )
        self.api_instance.avro_writer.clear_buffer()

        for key in key_data:
            nextUrl = dependent["endpoint"].format(
                dependency_key=key[dependent["dependency_key"]]
            )
            while True:
                data = self._call_api(endpoint=nextUrl)
                json_level = dependent["name"]
                items = data.get(json_level, [])
                if items:
                    for item in items:
                        item.update(
                            {f"{dependent['base']}_{k}": v for k, v in key.items()}
                        )
                    avro_writer.add_records(items)
                nextUrl = data.get("nextUrl", None)
                if not nextUrl:
                    break
        avro_writer.flush_buffer()
        avro_writer.archive_and_load_stage()
