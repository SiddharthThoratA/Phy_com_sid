import csv
import logging
import time

from config import can_call_rate_limiter
from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator


class DialpadAsyncFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params=None) -> dict:
        while not can_call_rate_limiter("dialpad"):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _get_csv_text(self, endpoint: str) -> str:
        while not can_call_rate_limiter("dialpad"):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint)
        response.raise_for_status()
        return response.text

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        endpoint = self.api_instance.endpoint
        params = self.api_instance.fetch_details["params"]
        params["stat_type"] = self.api_instance.call_endpoint
        self.api_instance.avro_writer.clear_buffer()
        while not can_call_rate_limiter("dialpad"):
            time.sleep(1)
        response = self.api_instance.session.post(endpoint, json=params)
        response.raise_for_status()
        endpoint = endpoint + "/" + str(response.json()["request_id"])
        while True:
            time.sleep(10)
            data = self._call_api(endpoint)
            if data["status"] == "complete":
                endpoint = data["download_url"]
                csv_text = self._get_csv_text(endpoint=endpoint)
                csv_reader = csv.DictReader(csv_text.splitlines(), delimiter=",")
                items = []
                for row in csv_reader:
                    items.append(row)
                self.api_instance.avro_writer.add_records(items)
                break
        self.api_instance.avro_writer.flush_buffer()
