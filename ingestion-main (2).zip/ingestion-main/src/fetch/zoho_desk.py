import logging
import time
from datetime import datetime

import pytz
from google.cloud import bigquery

from auth.auth import SimpleAuth
from avro.avro_writer import AvroWriter
from config import can_call_rate_limiter
from fetch.fetch_factory import FetchBase, FetchFactory
from utils.retry_decorator import retry_decorator


def is_between_time(start, end):
    denver_tz = pytz.timezone("America/Denver")
    current_time = datetime.now(denver_tz).time()
    return start <= current_time <= end


class ZohoDeskFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        start = 1
        columns_to_keep = None
        dependency_key_data = []
        self.api_instance.avro_writer.clear_buffer()
        skip_threads = is_between_time(
            datetime.strptime("23:00", "%H:%M").time(),
            datetime.strptime("23:59", "%H:%M").time(),
        )

        if self.api_instance.dependent_details and not skip_threads:
            dependency_keys = set()
            for dependent in self.api_instance.dependent_details:
                dependency_keys.add(dependent["dependency_key"])
            columns_to_keep = list(dependency_keys)
            logging.info(
                f"{self.api_instance.api_name}-{self.api_instance.call_endpoint}: Columns to keep: {columns_to_keep}"
            )

        while True:
            params = {
                "from": str(start),
                "limit": "100",
            }
            if self.api_instance.call_endpoint == "tickets" and not skip_threads:
                params["receivedInDays"] = "30"

            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)
            endpoint = self.api_instance.endpoint
            data = self._call_api(endpoint, params)
            items = data.get("data", [])
            if columns_to_keep and items and not skip_threads:
                dependency_key_data.extend(
                    [
                        {k: v for k, v in item.items() if k in columns_to_keep}
                        for item in items
                    ]
                )

            if items:
                self.api_instance.avro_writer.add_records(items)
                if len(items) < int(params["limit"]):
                    self.api_instance.avro_writer.flush_buffer()
                    break
            elif data and not items:
                self.api_instance.avro_writer.add_records([data])
            else:
                self.api_instance.avro_writer.flush_buffer()
                break
            start += len(items)
        if not skip_threads:
            client = bigquery.Client(project="deft-bonsai-304315")
            query = "SELECT ticket_id FROM conf.v_k8s_ingestion__zoho_desk_thread_count_mismatch"
            result = client.query(query)
            mismatched_threads_ticket_ids = [row["ticket_id"] for row in result]
            pulled_ticket_ids = [row["id"] for row in dependency_key_data]
            combined_tickets = set(mismatched_threads_ticket_ids + pulled_ticket_ids)
            dependency_key_data = [{"id": ticket_id} for ticket_id in combined_tickets]
            for dependent in self.api_instance.dependent_details:
                dependent_fetch = FetchFactory.get_dependent_fetch_class(
                    self.api_instance, dependent["dependency_fetch_class"]
                )
                key_data = [
                    {k: v for k, v in item.items() if k in dependent["dependency_key"]}
                    for item in dependency_key_data
                ]
                dependent_fetch.fetch_data(key_data, dependent)


class DependentZohoDeskFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)
        self.cursor = None

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict | None:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint, params=params)
        if response.status_code == 403:
            logging.info(f"403 response for {endpoint}")
            return None
        if response.status_code == 404:
            logging.info(f"404 response for {endpoint}")
            return None
        response.raise_for_status()
        return response.json()

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self, key_data, dependent):
        logging.info(
            f"Fetching dependent data from {self.api_instance.api_name}-{dependent['name']}"
        )
        avro_writer = AvroWriter(self.api_instance.api_name, dependent["name"])
        self.api_instance.avro_writer.clear_buffer()
        for key in key_data:
            start = 1
            while True:
                params = {
                    "from": str(start),
                    "limit": "100",
                }
                if start % 1000 == 0:
                    logging.info(
                        f"{self.api_instance.api_name}-{dependent['name']} position: {start}"
                    )
                if self.api_instance.auth is not SimpleAuth:
                    updated_headers = self.api_instance.auth.get_headers()
                    self.api_instance.session.headers.update(updated_headers)
                endpoint = dependent["endpoint"].format(
                    dependency_key=key[dependent["dependency_key"]]
                )

                data = self._call_api(endpoint=endpoint, params=params)
                if not data:
                    break

                items = data.get("data", [])
                if items:
                    for item in items:
                        item.update(
                            {f"{dependent['base']}_{k}": v for k, v in key.items()}
                        )
                    avro_writer.add_records(items)
                    if len(items) < int(params["limit"]):
                        break
                if not items:
                    break
                start += len(items)
        avro_writer.flush_buffer()
        avro_writer.archive_and_load_stage()


class ZohoDeskDeletedFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str) -> str:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)
        response = self.api_instance.session.get(endpoint)
        if response.status_code == 404:
            return "deleted"
        if response.status_code == 403:
            return "archived"
        if response.status_code == 200 and response.json().get("isDeleted"):
            return "deleted"
        response.raise_for_status()
        return "pass"

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _get_old_open_tickets(self, client):
        query = "SELECT ticket_id FROM conf.v_k8s_ingestion__zoho_desk_old_open_tickets"
        results = client.query(query)
        return [row["ticket_id"] for row in results]

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _insert_into_deleted_table(self, id: int, client):
        query = f"CALL conf.insert_zoho_desk_deleted_ticket({id})"
        client.query(query)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _insert_into_archived_table(self, id: int, client):
        query = f"CALL conf.insert_zoho_desk_archived_ticket({id})"
        client.query(query)

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        from google.cloud import bigquery

        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        client = bigquery.Client(project="deft-bonsai-304315")

        old_open_tickets = self._get_old_open_tickets(client)
        processed_tickets = 0
        for id in old_open_tickets:
            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)
            endpoint = self.api_instance.endpoint + f"/{id}"
            status = self._call_api(endpoint)
            if status == "deleted":
                self._insert_into_deleted_table(id, client)
                logging.info(f"Ticket with ID: {id} has been marked as deleted")
            elif status == "archived":
                self._insert_into_archived_table(id, client)
                logging.info(f"Ticket with ID: {id} has been marked as archived")
            processed_tickets += 1
            if processed_tickets % 100 == 0:
                logging.info(f"Processed {processed_tickets} tickets")
