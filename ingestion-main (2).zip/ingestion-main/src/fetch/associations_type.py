import logging
import time
from config import can_call_rate_limiter,HUBSPOT_ASSOCIATION_TYPEID_MAPPING,HUBSPOT_DEFAULT_OBJECTS
from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator

class AssociationTypeFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    @retry_decorator(
        max_retries=3, delay=10, delay_type="exponential", email_on_max_retries=False
    )
    def _call_api(self, endpoint: str, params: dict) -> dict:
        while not can_call_rate_limiter(self.api_instance.api_name):
            time.sleep(1)
        
        response = self.api_instance.session.get(endpoint, params=params)
        response.raise_for_status()
        return response.json()

    def _get_hubspot_all_objects(self,custom_objects: dict)-> dict:
        all_objects_mapping = HUBSPOT_DEFAULT_OBJECTS.copy()
        all_objects_mapping.update(custom_objects)
        return all_objects_mapping
    
    def _hubspot_fallback_call(self, from_type_id: str, to_type_id: str) -> dict:
        fallback_type_id = HUBSPOT_ASSOCIATION_TYPEID_MAPPING.get((from_type_id, to_type_id))
        if fallback_type_id:
            logging.warning(f"[Fallback] No results for {from_type_id} → {to_type_id}. Using fallback typeId: {fallback_type_id}")
            return {
                "results": [{
                    "category": "HUBSPOT_DEFINED",
                    "typeId": fallback_type_id,
                    "label": None,
                    "from_object_type": from_type_id,
                    "to_object_type": to_type_id
                }]
            }
        else:
            return {"results": []}
    
    def _fetch_associations(self, from_type_id: str, to_type_id: str):
        url = f"{self.api_instance.endpoint}/crm/v4/associations/{from_type_id}/{to_type_id}/labels"
        try:
            data = self._call_api(url, params=None)
            if data and data.get("results"):
                return data
            else:
                return self._hubspot_fallback_call(from_type_id, to_type_id)
        except Exception as e:
            logging.error(f"[Exception] Error fetching associations {from_type_id} → {to_type_id}: {e}")
            return None

    def _fetch_all_associations(self,custom_objects: dict):
        objects_type_map = self._get_hubspot_all_objects(custom_objects)
        object_names = list(objects_type_map.keys())
        results = {}

        for from_obj in object_names:
            from_id = objects_type_map[from_obj]
            results[from_obj] = {}

            for to_obj in object_names:
                to_id = objects_type_map[to_obj]
                assoc = self._fetch_associations(from_id, to_id)
                results[from_obj][to_obj] = assoc

        return results
    
    def _generate_relationship_name(self,from_obj: str, to_obj:str, label: str)-> str:
        if label:
            return f"{from_obj}_to_{to_obj}_{label}".lower().replace(" ", "_")
        else:
            return f"{from_obj}_to_{to_obj}".lower()
    
    def _flatten_association_data(self, hubspot_response: dict) -> list[dict]:
        flattened_data = []
        for from_object_type, to_objects in hubspot_response.items():
            for to_object_type, data in to_objects.items():
                if not data or "results" not in data or not data["results"]:
                    continue

                for relation in data["results"]:
                    flattened_data.append({
                        "category": relation.get("category"),
                        "id": relation.get("typeId"),
                        "name": self._generate_relationship_name(from_object_type, to_object_type, relation.get("label")),
                        "label": relation.get("label"),
                        "from_object_type": from_object_type,
                        "to_object_type": to_object_type,
                    })

        return flattened_data

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        custom_object_type_map = {}
        has_more = True
      
        self.api_instance.avro_writer.clear_buffer()
        endpoint = f'{self.api_instance.endpoint}/crm/v3/schemas'
        
        while has_more:
            params = {
            "limit": 100
            }
           
            updated_headers = self.api_instance.auth.get_headers()
            self.api_instance.session.headers.update(updated_headers)
     
            logging.info(f"Calling endpoint: {endpoint}")
            
            data = self._call_api(endpoint, params=params)
            items = data.get("results", None)
            
            for obj in items:
                custom_object_type_map[obj["name"]] = obj["objectTypeId"]

            paging = data.get('paging')
            if paging and paging.get('next'):
                params['after'] = paging['next']['after']
            else:
                has_more = False

            associations_result = self._fetch_all_associations(custom_object_type_map)
            flattened_data = self._flatten_association_data(associations_result)

            self.api_instance.avro_writer.add_records(flattened_data)

            if not items or len(items) < params["limit"]:
                self.api_instance.avro_writer.flush_buffer()
                break

        logging.info("Finalizing uploads... archiving staged files.")
        self.api_instance.avro_writer.flush_buffer()
            