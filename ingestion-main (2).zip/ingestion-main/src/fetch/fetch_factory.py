from abc import ABC, abstractmethod


class FetchBase(ABC):
    def __init__(self, api_instance):
        self.api_instance = api_instance

    @abstractmethod
    def _call_api(self, endpoint: str, params: dict | None) -> dict:
        """Call the API and return the response."""
        pass

    @abstractmethod
    def fetch_data(self, dependency_key_data=None):
        """Fetch data from the API."""


class FetchFactory:
    fetch_class_map = {}
    dependent_fetch_class_map = {}

    @staticmethod
    def get_fetch_class(api_instance, fetch_class_name, **kwargs):
        if not FetchFactory.fetch_class_map:
            FetchFactory._populate_fetch_class_map()
        fetch_class = FetchFactory.fetch_class_map.get(fetch_class_name)
        if not fetch_class:
            raise ValueError(f"Unsupported fetch class type: {fetch_class_name}")
        return fetch_class(api_instance, **kwargs)

    @staticmethod
    def get_dependent_fetch_class(api_instance, dependent_fetch_class_name, **kwargs):
        if not FetchFactory.dependent_fetch_class_map:
            FetchFactory._populate_dependent_fetch_class_map()
        dependent_fetch_class = FetchFactory.dependent_fetch_class_map.get(
            dependent_fetch_class_name
        )
        if not dependent_fetch_class:
            raise ValueError(
                f"Unsupported dependent fetch class type: {dependent_fetch_class_name}"
            )
        return dependent_fetch_class(api_instance, **kwargs)

    @staticmethod
    def _populate_fetch_class_map():
        from fetch.customer_io import CustomerIoFetch
        from fetch.dialpad import DialpadAsyncFetch
        from fetch.fetch import CursorFetch
        from fetch.hubspot import HubspotFetch
        from fetch.reach_360 import Reach360Fetch
        from fetch.stripe import StripeConnectedAccountBalanceFetch
        from fetch.zoho_crm import ZohoCrmFetch
        from fetch.associations_type import AssociationTypeFetch
        from fetch.zoho_desk import ZohoDeskDeletedFetch, ZohoDeskFetch
        from fetch.hubspot_pipelines import HubspotPipelinesFetch,HubspotPipelinesStageFetch
        from fetch.associations_fetcher import HubspotAssociationsFetch
        from fetch.hubspot_users_owners import HubspotUsersFetch,HubspotOwnersFetch

        FetchFactory.fetch_class_map = {
            "CursorFetch": CursorFetch,
            "ZohoDeskFetch": ZohoDeskFetch,
            "ZohoDeskDeletedFetch": ZohoDeskDeletedFetch,
            "DialpadAsyncFetch": DialpadAsyncFetch,
            "Reach360Fetch": Reach360Fetch,
            "CustomerIoFetch": CustomerIoFetch,
            "StripeConnectedAccountBalanceFetch": StripeConnectedAccountBalanceFetch,
            "ZohoCrmFetch":ZohoCrmFetch,
            "AssociationTypeFetch": AssociationTypeFetch,
            "HubspotFetch": HubspotFetch,
            "HubspotPipelinesFetch": HubspotPipelinesFetch,
            "HubspotPipelinesStageFetch" : HubspotPipelinesStageFetch,
            "HubspotAssociationsFetch": HubspotAssociationsFetch,
            "HubspotUsersFetch" : HubspotUsersFetch,
            "HubspotOwnersFetch" : HubspotOwnersFetch
        }

    @staticmethod
    def _populate_dependent_fetch_class_map():
        from fetch.customer_io import DependentCustomerIoFetch
        from fetch.fetch import DependentCursorFetch
        from fetch.reach_360 import DependentReach360Fetch
        from fetch.zoho_desk import DependentZohoDeskFetch

        FetchFactory.dependent_fetch_class_map = {
            "DependentBasicFetch": DependentCursorFetch,
            "DependentZohoDeskFetch": DependentZohoDeskFetch,
            "DependentReach360Fetch": DependentReach360Fetch,
            "DependentCustomerIoFetch": DependentCustomerIoFetch,
        }
