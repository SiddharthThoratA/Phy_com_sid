import logging
import time
from collections.abc import MutableMapping

import stripe

from fetch.fetch_factory import FetchBase
from utils.retry_decorator import retry_decorator


class StripeConnectedAccountBalanceFetch(FetchBase):
    def __init__(self, api_instance):
        super().__init__(api_instance)

    def _call_api(self):
        pass

    def _normalize_data(self, balance_dict: dict, prefix: str) -> dict:
        def _flatten(d: MutableMapping, parent_key: str = "", sep: str = "_") -> dict:
            items = []
            for k, v in d.items():
                new_key = f"{parent_key}{sep}{k}" if parent_key else k
                if isinstance(v, MutableMapping):
                    items.extend(_flatten(v, new_key).items())
                else:
                    items.append((new_key, v))
            return dict(items)

        flattened_data = _flatten(balance_dict, sep="__")
        prefixed_data = {
            f"{prefix}__{key}": value for key, value in flattened_data.items()
        }

        return prefixed_data

    @retry_decorator(
        max_retries=3, delay=60, delay_type="linear", email_on_max_retries=True
    )
    def fetch_data(self):
        logging.info(
            f"Fetching data from {self.api_instance.api_name}-{self.api_instance.call_endpoint}"
        )
        self.api_instance.avro_writer.clear_buffer()
        self.api_instance.auth.get_headers()
        logging.getLogger("stripe").setLevel(logging.WARNING)
        if self.api_instance.call_endpoint == "connected_account_balances":
            accounts = stripe.Account.list(limit=100)
            connected_account_ids = [
                account.id for account in accounts.auto_paging_iter()
            ]
            logging.info(f"Found {len(connected_account_ids)} connected accounts")

            i = 0
            items = []
            for account in connected_account_ids:
                try:
                    balance = stripe.Balance.retrieve(stripe_account=account)
                    available_data = self._normalize_data(
                        balance.available[0], prefix="available"
                    )
                    pending_data = self._normalize_data(
                        balance.pending[0], prefix="pending"
                    )
                    unix_millis = int(time.time() * 1000)
                    merged_data = available_data | pending_data
                    merged_data["date"] = unix_millis
                    merged_data["account_id"] = account
                    if merged_data:
                        items.append(merged_data)
                        i += 1
                    if i % 100 == 0:
                        self.api_instance.avro_writer.add_records(items)
                        items = []
                except stripe.StripeError as e:
                    logging.error(f"Stripe error for account {account}: {e}")
                except Exception as e:
                    logging.error(
                        f"An unexpected error occurred for account {account}: {e}"
                    )
            if items:
                self.api_instance.avro_writer.add_records(items)
            self.api_instance.avro_writer.flush_buffer()
        else:
            try:
                resource = getattr(stripe, self.api_instance.call_endpoint, None)
                if resource is None:
                    raise ValueError(
                        f"Unknown Stripe resource: {self.api_instance.call_endpoint}"
                    )

                sixty_days_ago = int(time.time()) - 60 * 60 * 24 * 60
                one_twenty_days_ago = int(time.time()) - 60 * 60 * 24 * 120
                created = {
                    "gt": sixty_days_ago
                    if self.api_instance.call_endpoint != "Dispute"
                    else one_twenty_days_ago,
                    "lt": int(time.time()),
                }
                items_iter = resource.list(
                    limit=100, created=created
                ).auto_paging_iter()
                record_buffer = []
                chunk_size = 100

                for item in items_iter:
                    record_buffer.append(item.to_dict())
                    if len(record_buffer) >= chunk_size:
                        self.api_instance.avro_writer.add_records(record_buffer)
                        record_buffer.clear()

                if record_buffer != []:
                    self.api_instance.avro_writer.add_records(record_buffer)

                self.api_instance.avro_writer.flush_buffer()
            except Exception as e:
                logging.error(
                    f"Failed to fetch data from {self.api_instance.call_endpoint}: {e}"
                )
