import logging
from datetime import datetime
from decimal import ROUND_DOWN, Decimal

import pytz

null_list = ["", "null", "None", None]

datetime_formats = [
    "%Y-%m-%d %H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S.%fZ",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S.%f",
    "%Y-%m-%dT%H:%M:%S.%fZ",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%dT%H:%M:%SZ",
    "ISO8601",
]

date_formats = ["%Y-%m-%d", "%m/%d/%Y", "%m-%d-%Y"]


def coerce_json_to_avro(avro_schema, data, timezone="utc"):
    if isinstance(avro_schema, dict) and avro_schema.get("type", None) == "record":
        coerced_data = {}
        for field in avro_schema.get("fields", None):
            try:
                field_name = field.get("name", None)
                field_type = field.get("type", None)
                if data is None or field_name not in data:
                    coerced_data[field_name] = None
                    if (
                        isinstance(field_type, dict)
                        and field_type.get("type", None) == "array"
                    ):
                        coerced_data[field_name] = []
                    elif (
                        isinstance(field_type, dict)
                        and field_type.get("type", None) == "record"
                    ):
                        coerced_data[field_name] = {}
                    else:
                        coerced_data[field_name] = None
                else:
                    coerced_data[field_name] = coerce_json_to_avro(
                        field_type, data[field_name]
                    )
            except KeyError:
                logging.error(
                    f"Field {field} is missing a required key. "
                    "Please check the schema and try again."
                )
        return coerced_data
    elif isinstance(avro_schema, dict) and avro_schema.get("type", None) == "array":
        coerced_data = []
        for item in data:
            coerced_data.append(coerce_json_to_avro(avro_schema.get("items"), item))
        return coerced_data
    elif isinstance(avro_schema, dict) and avro_schema.get("logicalType", None):
        if (
            isinstance(avro_schema.get("type", None), list)
            and "null" in avro_schema["type"]
        ):
            if data in null_list:
                return None
            else:
                return coerce_json_to_avro(avro_schema["type"].remove("null"), data)
        if avro_schema["logicalType"] == "decimal":
            return Decimal(str(data)).quantize(Decimal("1e-9"), rounding=ROUND_DOWN)
        elif avro_schema["logicalType"] == "date":
            for date_format in date_formats:
                try:
                    return datetime.strptime(data, date_format)
                except ValueError:
                    continue
            logging.error("Unable to parse date.")
        elif avro_schema["logicalType"] == "timestamp-micros":
            for datetime_format in datetime_formats:
                try:
                    if datetime_format == "ISO8601":
                        if "T" in data:
                            data = data.replace("T", " ")
                        return datetime.fromisoformat(data)
                    else:
                        raw_datetime = datetime.strptime(data, datetime_format)
                    if timezone != "utc":
                        pytz_timezone = pytz.timezone(timezone)
                        return pytz_timezone.localize(raw_datetime)
                    pytz_timezone = pytz.timezone("utc")
                    return pytz_timezone.localize(raw_datetime)
                except ValueError:
                    continue
            error_message = f"Unable to parse datetime for {data}"
            logging.error(error_message)
        elif avro_schema["logicalType"] == "timestamp-millis":
            for datetime_format in datetime_formats:
                try:
                    if datetime_format == "ISO8601":
                        if "T" in data:
                            data = data.replace("T", " ")
                        return datetime.fromisoformat(data)
                    else:
                        raw_datetime = datetime.strptime(data, datetime_format)
                    if timezone != "utc":
                        pytz_timezone = pytz.timezone(timezone)
                        return pytz_timezone.localize(raw_datetime)
                    pytz_timezone = pytz.timezone("utc")
                    return pytz_timezone.localize(raw_datetime)
                except ValueError:
                    continue
            error_message = f"Unable to parse datetime for {data}"
            logging.error(error_message)
        else:
            logging.error(
                f"Logical type {avro_schema['logicalType']} is not supported."
            )
            raise NotImplementedError(
                f"Logical type {avro_schema['logicalType']} is not supported."
            )
    else:
        try:
            if isinstance(avro_schema, list) and "null" in avro_schema:
                if data in null_list:
                    return None
                else:
                    avro_schema.remove("null")
            if isinstance(avro_schema, list):
                for item in avro_schema:
                    try:
                        return coerce_json_to_avro(item, data)
                    except Exception:
                        continue
            match avro_schema:
                case "bytes":
                    return bytes(data)
                case "boolean":
                    if isinstance(data, str):
                        data = data.lower()
                        if data == "true":
                            return True
                        elif data == "false":
                            return False
                    return bool(data)
                case "int":
                    return int(data)
                case "long":
                    return int(data)
                case "float":
                    return float(data)
                case "double":
                    return float(data)
                case "string":
                    return str(data)
        except Exception as e:
            logging.error(f"Error coercing data {data} to type {avro_schema}: {e}")
            raise
