import copy
import io
import json
import logging
import time
from datetime import datetime

from fastavro import parse_schema as fastavro_parse_schema
from fastavro import writer as fastavro_writer
from google.cloud import storage

from avro.avro_schema_gen import generate_avro_schema
from avro.avro_schema_parse import coerce_json_to_avro
from config import ARCHIVE_BUCKET, BUCKET, ENV, can_call_rate_limiter
from utils.retry_decorator import retry_decorator


class AvroWriter:
    """Class for writing Avro records to a buffer and uploading to GCS."""

    def __init__(self, api_name: str, call_endpoint: str):
        self._records = io.BytesIO()
        self._gcs_client = storage.Client()
        self.call_endpoint = call_endpoint
        self.api_name = api_name
        self._buffer_size = 0
        self.bucket_name = BUCKET
        self.archive_bucket_name = ARCHIVE_BUCKET
        self._upload_folder, self._staging_folder = self._get_upload_folders()
        self._schema = None

    def _get_upload_folders(self):
        """Return the upload folder based on the environment."""
        if ENV == "prod":
            upload = f"bi-services/api-ingestion/{self.api_name}/{self.call_endpoint}/"
            staging = upload + "stage/"
            return upload, staging
        else:
            upload = (
                f"bi-services/api-ingestion/{ENV}/{self.api_name}/{self.call_endpoint}/"
            )
            staging = upload + "stage/"
            return upload, staging

    def _get_schema(self, record=None):
        """Retrieve or generate Avro schema from GCS."""
        schema_path = (
            self._upload_folder + f"{self.api_name}_{self.call_endpoint}_schema.avsc"
        )

        bucket = self._gcs_client.bucket(self.bucket_name)
        blob = bucket.blob(schema_path)

        if blob.exists():
            schema_json = json.loads(blob.download_as_text())
        else:
            if not record:
                logging.error(
                    f"{self.api_name}-{self.call_endpoint}: need a record to generate a schema"
                )
            schema_json = generate_avro_schema(
                data=record, name=self.call_endpoint, namespace=self.api_name
            )
            while not can_call_rate_limiter("GCS"):
                time.sleep(1)
            blob.upload_from_string(json.dumps(schema_json))
        return fastavro_parse_schema(schema_json)

    def _archive_old(self):
        """Archive current files to the archive bucket if ENV is prod."""
        bucket = self._gcs_client.bucket(self.bucket_name)
        blobs = bucket.list_blobs(prefix=self._upload_folder)
        if not blobs or ENV != "prod":
            return
        for blob in blobs:
            if blob.name.endswith(".avsc") or "/stage/" in blob.name:
                continue
            file_name = blob.name.split("/")[-1]
            archive_name = (
                self._upload_folder + str(datetime.now().timestamp()) + "/" + file_name
            )
            while not can_call_rate_limiter("GCS"):
                time.sleep(1)
            new_blob = bucket.copy_blob(
                blob, self._gcs_client.bucket(self.archive_bucket_name), archive_name
            )
            logging.info(f"Archived {file_name} to {new_blob.name}")
            blob.delete()

    def add_records(self, records):
        """Coerce and serialize a record directly into the buffer, checking buffer size."""
        if self._schema is None:
            self._schema = self._get_schema(record=records[0])

        coerced_records = []
        for record in records:
            schema = copy.deepcopy(self._schema)
            coerced_record = coerce_json_to_avro(avro_schema=schema, data=record)
            coerced_records.append(coerced_record)

        current_pos = self._records.tell()
        fastavro_writer(self._records, self._schema, coerced_records)
        added_size = self._records.tell() - current_pos

        self._buffer_size += added_size

        if self._buffer_size >= 1 * 1024 * 1024:
            self.flush_buffer()

    def flush_buffer(self):
        """Flush the buffer to a file and upload to GCS."""
        if self._buffer_size > 0:
            file_name = (
                self._staging_folder
                + f"{self.api_name}_{self.call_endpoint}_{int(datetime.now().timestamp())}.avro"
            )
            self._write_to_file(file_name=file_name)
            self._records.seek(0)
            self._records.truncate(0)
            self._buffer_size = 0

    def clear_buffer(self):
        """Clear the buffer without writing to a file."""
        if self._buffer_size > 0 or self._records.tell() > 0:
            self._records.seek(0)
            self._records.truncate(0)
            self._buffer_size = 0

    @retry_decorator(max_retries=3, delay=10, delay_type="exponential")
    def _write_to_file(self, file_name: str):
        """Write the buffer's content to a file and upload to GCS."""
        bucket = self._gcs_client.bucket(self.bucket_name)
        blob = bucket.blob(file_name)
        self._records.seek(0)
        while not can_call_rate_limiter("GCS"):
            time.sleep(1)
        blob.upload_from_file(self._records)
        logging.info(f"Uploaded {file_name} to {self.bucket_name}")

    def archive_and_load_stage(self):
        """Archive the current files and load the staged files to the BQ ingest location."""
        self._archive_old()
        bucket = self._gcs_client.bucket(self.bucket_name)
        blobs = bucket.list_blobs(prefix=self._staging_folder)
        for blob in blobs:
            if blob.name.endswith(".avsc"):
                continue
            new_name = blob.name.replace(self._staging_folder, self._upload_folder)
            while not can_call_rate_limiter("GCS"):
                time.sleep(1)
            new_blob = bucket.copy_blob(blob, bucket, new_name)
            logging.info(f"Copied {blob.name} to {new_blob.name}")
            blob.delete()
        logging.info(f"Archived and loaded {self.api_name}-{self.call_endpoint}")
