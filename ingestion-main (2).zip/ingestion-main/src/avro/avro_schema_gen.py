import builtins
import logging
from datetime import datetime


def is_date(string):
    try:
        datetime.fromisoformat(string)
        return True
    except ValueError:
        return False


def infer_string_type(value: str) -> list:
    if is_date(value):
        return ["null", {"type": "long", "logicalType": "timestamp-micros"}]
    if value.lower() in ["true", "false"]:
        return ["null", "boolean"]
    try:
        int(value)
        return ["null", "long"]
    except ValueError:
        try:
            float(value)
            return ["null", "double"]
        except ValueError:
            return ["null", "string"]


def infer_avro_type(value, key) -> list | str | dict:
    match type(value):
        case builtins.list:
            return {"type": "array", "items": infer_avro_type(value[0], key)}
        case builtins.dict:
            return generate_avro_schema(value, key, key + ".nested")
        case builtins.bool:
            return ["null", "boolean"]
        case builtins.str:
            return infer_string_type(value)
        case builtins.int:
            return ["null", "long"]
        case builtins.float:
            return ["null", "double"]
        case None:
            logging.info("null value found, ensure this is consistent")
            return ["null", "string"]
        case _:
            raise ValueError("Unknown type for value: {}".format(value))


def generate_avro_schema(data, name="default", namespace="default"):
    schema = {
        "type": "record",
        "name": name,
        "namespace": namespace,
        "fields": [],
    }
    logging.info(
        f"Generating Avro schema for data: {data} with name: {name} and namespace: {namespace}"
    )
    logging.info(data)
    key = None
    try:
        for key, value in data.items():
            if value is None:
                schema["fields"].append({"name": key, "type": ["string", "null"]})
            elif isinstance(value, list) and not value:
                schema["fields"].append(
                    {"name": key, "type": {"type": "array", "items": "string"}}
                )
            else:
                schema["fields"].append(
                    {"name": key, "type": infer_avro_type(value, key)}
                )
    except Exception:
        if key is not None:
            logging.error(
                f"Error generating avro schema for data: {data} on key: {key}"
            )
        else:
            logging.error(f"Error generating avro schema for data: {data}")

    return schema
