import json
import logging

import sendgrid
from google.cloud import storage

from config import SENDGRID_API_KEY


def get_json_from_gcs(bucket_name: str, file_path: str) -> dict:
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(file_path)
    config_data = blob.download_as_text()
    return json.loads(config_data)


def send_email(
    subject: str,
    content: str,
    email: str,
) -> None:
    sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)
    message = sendgrid.Mail(
        from_email="data-monitoring@kingbee-vans.com",
        to_emails=email,
        subject=subject,
        html_content=content,
    )
    try:
        response = sg.send(message)
        logging.info(f"Email sent to {email} with status code {response.status_code}")
    except Exception as e:
        logging.error(f"Error sending email to {email}: {e}")
