import os

from rate_limiters.create_rate_limiters import create_rate_limiters

BUCKET = "bi-services"
ARCHIVE_BUCKET = "bi-services-archive"
SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY")
RATE_LIMITER_LIST = [
    ("zoho_desk", 1000, 60),
    ("zoho_desk_deleted", 1000, 60),
    ("dialpad", 20, 1),
    ("GCS", 1, 1),
    ("reach360", 1000, 60),
    ("customer_io", 10, 1),
    ("stripe", 1000, 1),
    ("zoho_crm", 1000, 60),
    ("hubspot_associations_type", 5, 1),
    ("hubspot_associations",5,1),
    ("hubspot", 240, 10),
    ("hubspot_search", 5, 1),
    ("hubspot_pipelines",10,1),
    ("hubspot_pipelines_stage",10,1),
    ("hubspot_users",10,1),
    ("hubspot_owners",10,1)
]

STAGE_SUBSCRIPTION_ID = "api_ingestion_stage-sub"
PROD_SUBSCRIPTION_ID = "api_ingestion-sub"

HUBSPOT_OBJECT_INGESTION_MAPPING = {
    "vehicle_contracts": "p7609565_vehicle_contracts",
    "tolls": "p7609565_tolls",
    "vehicles": "p7609565_vehicles",
    "inspections": "p7609565_inspections",
    "shipping": "p7609565_shipping",
    "kbr_inventory": "p7609565_kbr_inventory",
    "times": "p7609565_times",
    "quickbook_s_invoices": "p7609565_quickbook_s_invoices",
}

# Mapping hubspot fallback type_id in case the API doesn't return association metadata
HUBSPOT_ASSOCIATION_TYPEID_MAPPING = {
    ("0-5", "0-5"): 452,
    ("0-5", "0-49"): 223,
    ("0-14", "0-8"): 67,
    ("0-53", "0-5"): 986,
    ("0-53", "0-8"): 409,
}

# Default HubSpot objects with their typeId
HUBSPOT_DEFAULT_OBJECTS = {
    "contacts": "0-1",
    "companies": "0-2",
    "deals": "0-3",
    "tickets": "0-5",
    "products": "0-7",
    "line_items": "0-8",
    "quotes": "0-14",
    "calls": "0-48",
    "emails": "0-49",
    "meetings": "0-47",
    "notes": "0-46",
    "tasks": "0-27",
    "postal_mail": "0-116",
    "feedback_submissions": "0-19",
    "communications": "0-18",
    "invoices": "0-53",
    "leads": "0-136",
}

HUBSPOT_PIPELINE_OBJECTS = ["deals","contacts", "companies","tickets", "tasks", "leads",
                    "p7609565_vehicle_contracts","p7609565_tolls","p7609565_vehicles",
                    "p7609565_inspections","p7609565_shipping","p7609565_kbr_inventory",
                    "p7609565_times","p7609565_quickbook_s_invoices"]

def get_env() -> str:
    return os.getenv("ENV", "local")


ENV = get_env()

rate_limiters = create_rate_limiters(RATE_LIMITER_LIST)


def can_call_rate_limiter(api_name: str) -> bool:
    """Check if a call to the specific api can be made."""
    return rate_limiters[api_name].can_call()
