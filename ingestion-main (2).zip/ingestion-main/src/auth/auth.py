import logging
import os
import time
from abc import ABC, abstractmethod
from threading import Lock

import requests

from utils.retry_decorator import retry_decorator


class AuthBase(ABC):
    @abstractmethod
    def get_headers(self):
        """Return authentication headers suitable for requests."""
        pass

class ZohoDeskAuth(AuthBase):
    def __init__(self, client_secret, client_id, refresh_token, org_id):
        self._token_url = "https://accounts.zoho.com/oauth/v2/token"
        self.client_id = os.getenv(client_id, None)
        self.client_secret = os.getenv(client_secret, None)
        self.refresh_token = os.getenv(refresh_token, None)
        self.org_id = os.getenv(org_id, None)
        self._access_token = None
        self._token_expiry = time.time()
        self._lock = Lock()
        self._get_access_token()

    @retry_decorator(max_retries=3, delay=10, delay_type="exponential")
    def _get_access_token(self):
        """Refresh or obtain a token."""
        logging.info("Refreshing Zoho Desk token")
        response = requests.post(
            self._token_url,
            data={
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "refresh_token": self.refresh_token,
                "grant_type": "refresh_token",
            },
        )
        token_response = response.json()
        self._access_token = token_response["access_token"]
        self._token_expiry = time.time() + token_response["expires_in"] - 120

    def get_headers(self):
        with self._lock:
            if time.time() >= self._token_expiry:
                self._get_access_token()
        headers = {
            "orgId": self.org_id,
            "Authorization": f"Zoho-oauthtoken {self._access_token}",
        }
        return headers


class SimpleAuth(AuthBase):
    def __init__(self, api_key_name: str):
        self.api_key_name = api_key_name
        self.api_key = os.getenv(api_key_name)

    def get_headers(self):
        return {"Authorization": f"Bearer {self.api_key}"}


class StripeAuth(AuthBase):
    def __init__(self, api_key_name: str):
        self.api_key_name = api_key_name
        self.api_key = os.getenv(api_key_name)

    def get_headers(self):
        import stripe

        stripe.api_key = self.api_key
        logging.info("Stripe API key set")
        return


class AuthFactory:
    auth_class_map = {
        "ZohoDeskAuth": ZohoDeskAuth,
        "SimpleAuth": SimpleAuth,
        "StripeAuth": StripeAuth,
    }

    @staticmethod
    def get_auth_class(auth_class_name,**kwargs):
        auth_class = AuthFactory.auth_class_map.get(auth_class_name)
        if auth_class is None:
            raise ValueError(f"Unsupported authentication type: {auth_class_name}")
        return auth_class(**kwargs)
