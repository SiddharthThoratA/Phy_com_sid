import threading
import time
from collections import deque


class RateLimiter:
    def __init__(self, limit: int, seconds: int = 60):
        self.limit = limit
        self._timestamps = deque()
        self.seconds = seconds
        self._lock = threading.Lock()

    def can_call(self) -> bool:
        """Check if a call to the specific api can be made."""
        with self._lock:
            now = time.time()
            while self._timestamps and self._timestamps[0] < now - self.seconds:
                self._timestamps.popleft()
            if len(self._timestamps) < self.limit:
                self._timestamps.append(now)
                return True
            else:
                return False


def create_rate_limiters(rate_limiter_list: list[tuple[str, int, int]]) -> dict:
    rate_limiters = {}
    for rate_limiter in rate_limiter_list:
        rate_limiters[rate_limiter[0]] = RateLimiter(
            int(rate_limiter[1]), int(rate_limiter[2])
        )
    return rate_limiters
