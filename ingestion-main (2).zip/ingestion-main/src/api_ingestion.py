import logging
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from zoneinfo import ZoneInfo

import requests

from auth.auth import AuthFactory
from avro.avro_writer import AvroWriter
from config import BUCKET, ENV
from fetch.fetch_factory import FetchFactory
from utils.utils import get_json_from_gcs, send_email


class BaseAPI:
    def __init__(self, api_preset: dict, call_endpoint: str):
        self.api_name = api_preset["api"]
        self.auth_details = api_preset["api_details"].get("auth_details", {})
        self.auth = AuthFactory.get_auth_class(
            auth_class_name=api_preset["api_details"]["auth_class"], **self.auth_details
        )
        if api_preset["api_details"].get("endpoint", None):
            self.endpoint = api_preset["api_details"]["endpoint"].format(
                endpoint=call_endpoint
            )
        self.call_endpoint = call_endpoint
        if self.api_name != "stripe":
            self.session = requests.Session()
            self.session.headers.update(self.auth.get_headers())
        self.avro_writer = AvroWriter(
            api_name=self.api_name, call_endpoint=call_endpoint
        )
        self.fetch_details = api_preset["api_details"].get("fetch_details", {})
        self.fetcher = FetchFactory.get_fetch_class(
            api_instance=self, fetch_class_name=api_preset["api_details"]["fetch_class"]
        )
        self.base_dependents = api_preset["api_details"].get("has_dependents", None)
        self.dependent_details = []
        if self.base_dependents:
            self._check_dependents(call_endpoint=call_endpoint)

    def _check_dependents(self, call_endpoint: str) -> None:
        """Check if there are any dependent endpoints."""
        for dependent in self.base_dependents:
            if dependent["base"] == call_endpoint:
                self.dependent_details.append(dependent)
                logging.info(f"Dependent details: {dependent}")

    def fetch_data(self):
        """Fetch api data, convert to avro and upload to GCS."""
        logging.info("fetching data")
        self.fetcher.fetch_data()
        self.avro_writer.archive_and_load_stage()
        return


def send_completion_email(
    email: str,
    ingestion_jobs: list[list[str]],
    job_type: str | None,
    start_time: datetime,
) -> None:
    apis, jobs = zip(*ingestion_jobs)
    bullet_points = "".join([f"<li>{api} - {job}</li>" for api, job in zip(apis, jobs)])
    duration = datetime.now(ZoneInfo("UTC")) - start_time
    html_content = f"<p>The following jobs have been completed at {datetime.now(ZoneInfo('UTC'))} UTC in {duration}:</p><ul>{bullet_points}</ul>"
    if job_type == "full" or job_type == "midnight":
        subject = "Full Ingestion Job Completed"
    else:
        subject = "Ingestion Airflow Triggered Job Completed"
    send_email(subject=subject, content=html_content, email=email)


def api_ingestion(ingestion_jobs: list[list[str]], job_type: str | None = None) -> None:
    start = datetime.now(ZoneInfo("UTC"))
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = []
        for job in ingestion_jobs:
            api_name, endpoint = job
            preset_file_name = (
                f"bi-services/api-ingestion/{api_name}/{api_name}_presets.json"
            )
            try:
                api_preset = get_json_from_gcs(
                    bucket_name=BUCKET, file_path=preset_file_name
                )
            except Exception as e:
                logging.error(f"Error fetching preset for {api_name}: {e}")
                continue
            api_instance = BaseAPI(api_preset=api_preset, call_endpoint=endpoint)
            future = executor.submit(api_instance.fetch_data)
            futures.append(future)
        for future in futures:
            future.result()
        if ENV == "prod":
            email = "data-monitoring@kingbee-vans.com"
        else:
            email = "data-engineering@kingbee-vans.com"
        send_completion_email(
            email=email,
            ingestion_jobs=ingestion_jobs,
            job_type=job_type,
            start_time=start,
        )
