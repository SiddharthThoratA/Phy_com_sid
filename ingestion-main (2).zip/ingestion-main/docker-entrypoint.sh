#!/bin/sh
set -e

if [ -f /vault/secrets/.env.shared ]; then
  echo {"level":"info","message":"Loading /vault/secrets/.env.shared"}
  source /vault/secrets/.env.shared
fi

if [ -f /vault/secrets/.env ]; then
  echo {"level":"info","message":"Loading /vault/secrets/.env"}
  source /vault/secrets/.env
fi

export DB_URL="${INGESTION_DB_URL}"
export DB_URL_READ="${INGESTION_DB_URL_READ}"

exec "$@"
