import datetime
import json
import mimetypes
import os

import requests

from config.logger import logger


class HubSpotHelper:
    def __init__(self, pat_token):
        self.base_url = "https://api.hubapi.com"
        self.headers = {
            "Authorization": f"Bearer {pat_token}",
            "Content-Type": "application/json",
        }

    def search_object_get_id(
        self, object_type: str, property_name: str, property_value
    ) -> str | None:
        endpoint = f"/crm/v3/objects/{object_type}/search"
        url = self.base_url + endpoint

        payload = {
            "filterGroups": [
                {
                    "filters": [
                        {
                            "propertyName": property_name,
                            "operator": "EQ",
                            "value": property_value,
                        }
                    ]
                }
            ],
            "limit": 5,
        }

        response = requests.post(url, json=payload, headers=self.headers)
        response.raise_for_status()

        results = response.json().get("results", [])
        if len(results) > 1:
            logger.error("Multiple objects found for search criteria")
            raise ValueError("Multiple objects found for search criteria")
        return results[0]["id"] if results else None

    def update_object(self, object_type, object_id, properties):
        endpoint = f"/crm/v3/objects/{object_type}/{object_id}"
        url = self.base_url + endpoint

        payload = {"properties": properties}

        response = requests.patch(url, json=payload, headers=self.headers)
        response.raise_for_status()
        return response.status_code == 200

    def create_property(
        self, object_type, property_name, property_label, data_type="string"
    ):
        endpoint = f"/crm/v3/properties/{object_type}"
        url = self.base_url + endpoint

        payload = {
            "name": property_name,
            "label": property_label,
            "type": data_type,
            "fieldType": "text",
            "groupName": "custom_properties",
            "hasUniqueValue": False,
        }

        response = requests.post(url, json=payload, headers=self.headers)
        response.raise_for_status()
        return response.status_code == 201

    def upload_file(
        self,
        file_source,
        folder_id=None,
        folder_path=None,
        file_name=None,
        overwrite=False,
        access="PRIVATE",
        mime_type=None,
    ):
        """
        Uploads a file to HubSpot's file manager from either a path or file-like object
        - file_source: Can be either:
            - String path to local file
            - File-like object (BytesIO, etc.)
        - file_name: Required if using file-like object without filename attribute
        - mime_type: Optional override for MIME type detection
        """
        is_file_path = isinstance(file_source, str)
        if is_file_path:
            if not file_name:
                file_name = os.path.basename(file_source)
        else:
            if not file_name:
                file_name = getattr(file_source, "name", None)
                if file_name:
                    file_name = os.path.basename(file_name)
                else:
                    logger.error(
                        "file_name required when using file-like object without name attribute"
                    )
                    raise ValueError(
                        "file_name required when using file-like object without name attribute"
                    )

        if not mime_type:
            if is_file_path:
                mime_type, _ = mimetypes.guess_type(file_source)
            else:
                mime_type, _ = mimetypes.guess_type(file_name)

        mime_type = mime_type or "application/octet-stream"

        if is_file_path:
            with open(file_source, "rb") as f:
                file_data = f.read()
        else:
            try:
                file_source.seek(0)
                file_data = file_source.read()
            except AttributeError:
                logger.error(
                    "file_source must be path string or file-like object with read() method"
                )
                raise ValueError(
                    "file_source must be path string or file-like object with read() method"
                )

        form_payload = {}

        if not folder_id and not folder_path:
            logger.error("folder_id or folder_path required")
            raise ValueError("folder_id or folder_path required")
        elif folder_id:
            form_payload["folderId"] = (None, str(folder_id))
        elif folder_path:
            form_payload["folderPath"] = (None, folder_path)

        form_payload.update(
            {
                "fileName": (None, file_name),
                "options": (
                    None,
                    json.dumps({"access": access, "overwrite": overwrite}),
                ),
                "file": (file_name, file_data, mime_type),
            }
        )

        endpoint = "/files/v3/files"
        url = self.base_url + endpoint

        headers = self.headers.copy()
        headers.pop("Content-Type", None)

        response = requests.post(url, files=form_payload, headers=headers)
        response.raise_for_status()

        return response.json()

    def find_folder_id(self, folder_path) -> str:
        """Resolve a folder path to its ID"""
        endpoint = "/filemanager/api/v3/folders"
        url = self.base_url + endpoint

        params = {"path": folder_path}
        response = requests.get(url, headers=self.headers, params=params)
        response.raise_for_status()

        data = response.json()
        return data["id"]

    def create_association(
        self,
        association_dict_array: list[dict] | None,
        from_object_type: str,
        from_object_id: str,
        to_object_type: str,
        to_object_id: str,
    ) -> dict:
        """
        handles creating associations between objects in bulk
        - association_dict_array: all associations in an array of dicts like:
            [
                {
                    "assocationCategory": string,
                    "associationTypeId": string
                }
            ]
        - from_object_type: the object type of the "from" object
        - to_object_type: the object type of the "to" object
        - from_object_id: the id of the "from" object
        - to_object_id: the id of the "to" object
        """

        if not association_dict_array:
            endpoint = f"/crm/v4/objects/{from_object_type}/{from_object_id}/associations/default/{to_object_type}/{to_object_id}"
            url = self.base_url + endpoint
            response = requests.put(url, headers=self.headers)
        else:
            endpoint = f"/crm/v4/objects/{from_object_type}/{from_object_id}/associations/{to_object_type}/{to_object_id}"
            url = self.base_url + endpoint
            response = requests.put(
                url, headers=self.headers, json=association_dict_array
            )
        response.raise_for_status()

        return response.json()

    def create_note(
        self,
        note_body: str,
        association_dict_array: list[dict],
        hs_attachment_ids: str | None = None,
    ) -> dict:
        """
        creates a note and associates it with a specific object
        - note_body: content of the note (required)
        - association_dict_array: all associations in an array of dicts
            the dicts should follow this general structure
            {
                "to": { "id": string}
                "types": [
                    {
                        "assocationCategory": string,
                        "associationTypeId": string
                    }
                ]
            }
        - timestamp: optional datetime in iso format (defaults to now)
        - additional_props: any other note properties (hs_note_title, etc)
        """
        endpoint = "/crm/v3/objects/notes"
        url = self.base_url + endpoint

        payload = {
            "properties": {
                "hs_note_body": note_body,
                "hs_timestamp": int(datetime.datetime.now().timestamp() * 1000),
            },
            "associations": association_dict_array,
        }
        if hs_attachment_ids:
            payload["properties"]["hs_attachment_ids"] = hs_attachment_ids

        response = requests.post(url, json=payload, headers=self.headers)
        response.raise_for_status()

        return response.json()

    def create_object(
        self,
        properties: dict,
        object_type: str,
        association_dict_array: list[dict] = [],
    ) -> dict:
        """
        creates an object and associates it with a specific object
        - properties: dict which maps hubspot key -> value
        - association_dict_array: all associations in an array of dicts
            the dicts should follow this general structure
            {
                "to": { "id": string}
                "types": [
                    {
                        "assocationCategory": string,
                        "associationTypeId": string
                    }
                ]
            }
        object_type: the type of object to create, should be the type id in hubspot
        """
        endpoint = "/crm/v3/objects/" + object_type
        url = self.base_url + endpoint
        param = {"objectType": object_type}

        payload = {
            "properties": properties,
        }
        if association_dict_array != []:
            payload["associations"] = association_dict_array

        response = requests.post(url, params=param, json=payload, headers=self.headers)
        response.raise_for_status()

        return response.json()

    def create_association_type(
        self,
        name: str,
        from_object_type: str,
        to_object_type: str,
        label: str,
        inverse_label: str | None = None,
    ) -> dict:
        """
        creates a new association type
        - name: the name of the association
        - from_object_type: the type of object the association is coming from
        - to_object_type: the type of object the association is going to
        - label: the label of the association
        """
        endpoint = f"/crm/v4/associations/{from_object_type}/{to_object_type}/labels"
        url = self.base_url + endpoint
        payload = {
            "name": name,
            "label": label,
        }
        if inverse_label:
            payload["inverseLabel"] = inverse_label
        response = requests.post(url, json=payload, headers=self.headers)
        response.raise_for_status()
        return response.json()

    def list_associations(
        self,
        object_id: str,
        from_object_type: str,
        to_object_type: str,
        find_unique_label: bool = False,
        label_to_find: str | None = None,
    ) -> dict:
        """
        lists all associations for a given object
        - object_id: the id of the object to list associations for
        - from_object_type: the type of object the associations are coming from
        - to_object_type: the type of object the associations are going to
        - find_unique_label: if true, will only return the association with the label
            this label MUST be unique
        - label_to_find: the label to find if find_unique_label is true
        """
        if find_unique_label and not label_to_find:
            raise ValueError("label_to_find is required when find_unique_label is true")

        endpoint = f"/crm/v4/objects/{from_object_type}/{object_id}/associations/{to_object_type}"
        url = self.base_url + endpoint

        all_results = []
        after = None

        while True:
            params = {"limit": 500}
            if after:
                params["after"] = after

            response = requests.get(url, params=params, headers=self.headers)
            response.raise_for_status()
            response = response.json()

            if find_unique_label:
                for result in response.get("results", []):
                    for assoc_type in result.get("associationTypes", []):
                        if assoc_type.get("label") == label_to_find:
                            return {
                                "results": [result],
                                "paging": response.get("paging", {}),
                            }
                after = response.get("paging", {}).get("next", {}).get("after")
                if not after:
                    return {"results": [], "paging": {}}
            else:
                all_results.extend(response.get("results", []))
                after = response.get("paging", {}).get("next", {}).get("after")
                if not after:
                    return {"results": all_results, "paging": {}}
