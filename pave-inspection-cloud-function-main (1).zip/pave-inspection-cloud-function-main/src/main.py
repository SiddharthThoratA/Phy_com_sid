import json
import os
import traceback
from datetime import datetime

import functions_framework
from flask import Request, jsonify
from google.cloud import tasks_v2

from config.config import GCS_BUCKET, HUBSPOT_ACCESS_TOKEN
from config.logger import logger
from hubspot.hubspot_helper import HubSpotHelper
from mappings.mappings import (
    API_PIPELINE_MAPPING,
    APP_INSPECTION_PIPELINES,
    INSPECTION_ASSOCIATION_MAPPINGS,
    NOTE_ASSOCIATION_MAPPINGS,
    OBJECT_ID_MAPPING,
)
from utils.helpers import (
    create_hubspot_files_and_note_html,
    get_nested_value,
    process_inspection,
    send_email,
    upload_to_gcs,
)
from utils.neptune import (
    mark_inspection_complete_neptune,
    mark_inspection_status_change_neptune,
)


def import_pipeline_ids(source_name: str):
    pipeline = API_PIPELINE_MAPPING.get("Inspections")
    pipeline_stage = API_PIPELINE_MAPPING.get(source_name)
    if not pipeline or not pipeline_stage:
        raise ValueError("Invalid pipeline mappings")
    return pipeline, pipeline_stage


def import_object_ids():
    inspection_object_id = OBJECT_ID_MAPPING.get("inspection")
    vehicle_object_id = OBJECT_ID_MAPPING.get("vehicle")
    vehicle_contract_object_id = OBJECT_ID_MAPPING.get("vehicle_contract")
    note_object_id = OBJECT_ID_MAPPING.get("note")
    if (
        not inspection_object_id
        or not vehicle_object_id
        or not vehicle_contract_object_id
        or not note_object_id
    ):
        raise ValueError("Invalid object id mappings")
    return (
        inspection_object_id,
        vehicle_object_id,
        vehicle_contract_object_id,
        note_object_id,
    )


@functions_framework.http
def inspection_webhook(request: Request):
    """Handle inspection webhook json payload"""
    start_time = datetime.now()
    logger.info(f"received inspection webhook from Pave, start time: {start_time}")
    data = request.get_json()
    client = tasks_v2.CloudTasksClient()

    project = os.environ.get("GOOGLE_CLOUD_PROJECT")
    location = os.environ.get("CLOUD_TASKS_LOCATION", "us-central1")
    queue = os.environ.get("CLOUD_TASKS_QUEUE", "inspection-queue")

    parent = client.queue_path(project, location, queue)

    processor_url = os.environ.get("PROCESSOR_FUNCTION_URL")
    service_account_email = os.environ.get("CLOUD_TASKS_SERVICE_ACCOUNT_EMAIL")
    payload = {"data": data, "start_time": start_time.isoformat()}
    payload_bytes = json.dumps(payload).encode()
    task = {
        "http_request": {
            "http_method": tasks_v2.HttpMethod.POST,
            "url": processor_url,
            "headers": {"Content-type": "application/json"},
            "body": payload_bytes,
            "oidc_token": {
                "service_account_email": service_account_email,
                "audience": processor_url,
            },
        }
    }

    response = client.create_task(request={"parent": parent, "task": task})
    logger.info(f"Task created: {response.name}")
    logger.info("Acknowledging receipt of inspection JSON")
    return jsonify({"status": "ok", "message": "Inspection JSON received"}), 202


@functions_framework.http
def inspection_processing_function(request: Request):
    """Process inspection data (called by Cloud Tasks)"""
    try:
        payload = request.get_json()
        data = payload.get("data")
        start_time_str = payload.get("start_time")
        start_time = datetime.fromisoformat(start_time_str)

        inspection_processing(data, start_time)

        return jsonify({"status": "success", "message": "Processing completed"}), 200
    except Exception as e:
        logger.error(f"Error processing task: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


@functions_framework.http
def inspection_status_change(request: Request):
    """Process status change data and update the BE/Neptune"""
    logger.info("Received inspection status change event")
    try:
        payload = request.get_json()
        logger.info(f"Payload: {payload}")
        if payload.get("event", None) == "SESSION:STATUS_CHANGE":
            status = payload.get("status", None)
            form_submitted = None
        elif payload.get("event", None) == "SESSION:FORM_SUBMITTED":
            status = None
            form_submitted = True
        else:
            logger.info("Not a status change event, skipping")
            return (
                jsonify({"status": "skipped", "message": "Not a status change event"}),
                200,
            )
        session_key = payload.get("session_key", None)
        if session_key and (status or form_submitted):
            logger.info("Marking inspection status change in Neptune")
            mark_inspection_status_change_neptune(
                session_key=session_key, status=status, form_submitted=form_submitted
            )

        return jsonify({"status": "success", "message": "Processing completed"}), 200
    except Exception as e:
        logger.error(f"Error processing task: {str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


def inspection_processing(data, start_time):
    logger.info("Processing inspection data")
    session_key = get_nested_value(data, "session.session_key")
    source_name = get_nested_value(data, "session.source.properties.api_name")

    if source_name in APP_INSPECTION_PIPELINES:
        logger.info("App inspection, updating Neptune/BE before any validation")
        mark_inspection_complete_neptune(session_key, source_name)

    user_email = get_nested_value(data, "session.user_account.email")

    if not user_email or (
        not user_email.endswith("@kingbee-vans.com")
        and not user_email.endswith("@fluidtruck.com")
        and not user_email == "kingbee@pave.ai"
    ):
        logger.error(f"Unauthorized user: {user_email}")
        if not session_key:
            email_message = "Missing session key and unauthenticated, investigate POST"
        else:
            email_message = (
                f"Unauthorized user: {user_email} with session key: {session_key}"
            )
        send_email(
            "PAVE API Unauthorized User - Investigate",
            email_message,
            "data-engineering@kingbee-vans.com",
        )
        return

    if "vehicle" not in data or "vin" not in data["vehicle"]:
        logger.error("Missing VIN information, aborting")
        send_email(
            "PAVE API Missing Vehicle Information",
            f"Missing VIN information in inspection data for session_key: {session_key} from email: {user_email}",
            [
                "data-engineering@kingbee-vans.com",
                "andrew.jensen@kingbee-vans.com",
                "genesis.z@kingbee-vans.com",
            ],
        )
        return

    try:
        if not source_name:
            logger.error("Missing source API name, cannot determine pipeline")
            return

        pipeline, pipeline_stage = import_pipeline_ids(source_name)
        (
            inspection_object_id,
            vehicle_object_id,
            vehicle_contract_object_id,
            note_object_id,
        ) = import_object_ids()
        note_association_mappings = NOTE_ASSOCIATION_MAPPINGS
        inspection_association_mappings = INSPECTION_ASSOCIATION_MAPPINGS

        vin = data["vehicle"]["vin"]
        date_str = datetime.now().isoformat()[:10]
        gcs_path = f"inspections/{vin}/{date_str}/{session_key}/pave_raw.json"
        upload_to_gcs(GCS_BUCKET, gcs_path, json.dumps(data))

        flat_data = process_inspection(data)

        (
            updated_flat_data,
            hs_note_body,
            hs_attachment_ids,
        ) = create_hubspot_files_and_note_html(flat_data, gcs_path, session_key)
        updated_flat_data["hs_pipeline_stage"] = pipeline_stage
        updated_flat_data["hs_pipeline"] = pipeline

        gcs_path_final = (
            f"inspections/{vin}/{date_str}/{session_key}/pave_processed.json"
        )
        upload_to_gcs(GCS_BUCKET, gcs_path_final, json.dumps(updated_flat_data))

        hubspot = HubSpotHelper(pat_token=HUBSPOT_ACCESS_TOKEN)
        object_upload_data = {
            k: v for k, v in updated_flat_data.items() if not k.startswith("_")
        }
        inspection_creation_response = hubspot.create_object(
            object_type=inspection_object_id,
            properties=object_upload_data,
            association_dict_array=[],
        )
        inspection_id = inspection_creation_response.get("id")
        if not inspection_id:
            logger.error("Error creating inspection inside of HubSpot")
            return
        vehicle_id = hubspot.search_object_get_id(vehicle_object_id, "vin", vin)
        APP_DEV_INSPECTION_PIPELINES = [
            "FT - Customer Return - FULL - Eng Dev",
            "FT - Customer Receiving - FULL - Eng Dev",
        ]
        if not vehicle_id and source_name not in APP_DEV_INSPECTION_PIPELINES:
            logger.info(f"Vehicle with VIN: '{vin}' does not exist inside of HubSpot")
            send_email(
                f"PAVE Inspection: Vehicle with VIN: '{vin}' does not exist inside of HubSpot",
                f"Vehicle with VIN: '{vin}' from PAVE API '{source_name}' with session key '{session_key}' from email '{user_email}' does not exist inside of HubSpot.",
                [
                    "data-engineering@kingbee-vans.com",
                    "andrew.jensen@kingbee-vans.com",
                    "genesis.z@kingbee-vans.com",
                    "corri.minchey@kingbee-vans.com",
                ],
            )
        note_association_array = []
        note_creation_response = hubspot.create_note(
            note_body=hs_note_body,
            association_dict_array=note_association_array,
            hs_attachment_ids=";".join(hs_attachment_ids),
        )
        note_id = note_creation_response.get("id")
        if not note_id:
            logger.error(
                "Error creating note inside of HubSpot. Note creation response: {note_creation_response}"
            )
            return
        _ = hubspot.create_association(
            association_dict_array=note_association_mappings["inspection_to_note"],
            from_object_type=inspection_object_id,
            from_object_id=inspection_id,
            to_object_type=note_object_id,
            to_object_id=note_id,
        )

        if not vehicle_id:
            logger.info(
                "Vehicle not inside of hubspot, skipping all vehicle associations"
            )
        else:
            _ = hubspot.create_association(
                association_dict_array=note_association_mappings["vehicle_to_note"],
                from_object_type=vehicle_object_id,
                from_object_id=vehicle_id,
                to_object_type=note_object_id,
                to_object_id=note_id,
            )
            _ = hubspot.create_association(
                association_dict_array=inspection_association_mappings[
                    "inspection_to_vehicle"
                ],
                from_object_type=inspection_object_id,
                from_object_id=inspection_id,
                to_object_type=vehicle_object_id,
                to_object_id=vehicle_id,
            )

        # as we started to take in the app inspections too, will need to branch here
        # hubspot sourced have the vehicle contract
        # app inspections will have already done a post to neptune/BE
        vehicle_contract_id = None
        if source_name in APP_INSPECTION_PIPELINES:
            logger.info("App inspection, updated Neptune/BE already before validation")
        elif vehicle_id:
            vehicle_contract_response = hubspot.list_associations(
                object_id=vehicle_id,
                from_object_type=vehicle_object_id,
                to_object_type=vehicle_contract_object_id,
                find_unique_label=True,
                label_to_find="Active",
            )

            if vehicle_contract_response.get("results") != []:
                contract_list = vehicle_contract_response.get("results")
                if contract_list and len(contract_list) > 1:
                    logger.error("Multiple active vehicle contracts found")
                    logger.info(f"Contract list: {contract_list}")
                    return
                try:
                    if contract_list:
                        vehicle_contract_id = contract_list[0].get("toObjectId")
                        _ = hubspot.create_association(
                            association_dict_array=inspection_association_mappings[
                                "inspection_to_vehicle_contract"
                            ],
                            from_object_type=inspection_object_id,
                            from_object_id=inspection_id,
                            to_object_type=vehicle_contract_object_id,
                            to_object_id=vehicle_contract_id,
                        )
                        _ = hubspot.create_association(
                            association_dict_array=note_association_mappings[
                                "vehicle_contract_to_note"
                            ],
                            from_object_type=vehicle_contract_object_id,
                            from_object_id=vehicle_contract_id,
                            to_object_type=note_object_id,
                            to_object_id=note_id,
                        )
                except Exception as e:
                    logger.error(
                        f"Error creating association to vehicle contract: {str(e)}"
                    )

        logger.info(f"Inspection: {inspection_id} created successfully")
        logger.info(f"Note: {note_id} created successfully")
        if vehicle_id:
            logger.info(f"Vehicle: {vehicle_id} found successfully")
        if vehicle_contract_id:
            logger.info(f"Vehicle contract: {vehicle_contract_id} found successfully")
        end_time = datetime.now()
        logger.info(f"Processing time (s): {(end_time - start_time).seconds}")
        return

    except Exception as e:
        logger.error(f"Error processing inspection: {str(e)}")
        content = "<p>Function inspection_processing failed.</p>"
        content += f"<p>Error: {e}</p>"
        content += (
            "<pre>"
            + "".join(traceback.format_exception(type(e), e, e.__traceback__))
            + "</pre>"
        )
        try:
            vin = data["vehicle"]["vin"]
        except Exception as e:
            vin = "Unknown"
        subject = f"Error Notification: Inspection Processing Failed for VIN: {vin}"

        send_email(subject, content, "data-engineering@kingbee-vans.com")

        return
