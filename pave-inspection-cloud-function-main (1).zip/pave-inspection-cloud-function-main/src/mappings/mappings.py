OBJECT_ID_MAPPING = {
    "inspection": "2-37060732",
    "vehicle": "2-12357379",
    "vehicle_contract": "2-18326878",
    "note": "0-46",
}


INSPECTION_ASSOCIATION_MAPPINGS = {
    "inspection_to_vehicle": [
        {
            "associationCategory": "USER_DEFINED",
            "associationTypeId": "323",
        },
    ],
    "inspection_to_vehicle_contract": [
        {
            "associationCategory": "USER_DEFINED",
            "associationTypeId": "319",
        },
    ],
}
NOTE_ASSOCIATION_MAPPINGS = {
    "inspection_to_note": [
        {
            "associationCategory": "USER_DEFINED",
            "associationTypeId": "303",
        },
    ],
    "vehicle_to_note": [
        {
            "associationCategory": "USER_DEFINED",
            "associationTypeId": "25",
        },
    ],
    "vehicle_contract_to_note": [
        {
            "associationCategory": "USER_DEFINED",
            "associationTypeId": "113",
        },
    ],
}


API_PIPELINE_MAPPING = {
    "Inspections": "653223429",  # id for the pipeline itself
    "Customer Return QC - FULL": "960351913",  # "Customer Returning - Need to be Reviewed",
    "Customer Receiving QC - FULL": "960351914",  # "Customer Receiving - Need to be Reviewed",
    "Kingbee QC - CAPT ONLY": "960375602",  # "Kingbee QC",
    "Receiving - CAPT ONLY": "960375601",  # "Kingbee Receiving",
    "Return QC - CAPT ONLY": "960375603",  # "Kingbee Return QC",
    "Apex Upfit QC - CAPT ONLY": "960375604",  # "Apex Upfit QC",
    "Apex Wrap QC - CAPT ONLY": "960375605",  # "Apex Wrap QC",
    "3rd Party Vin Verification - CAPT ONLY": "960375599",  # "3rd Party Vin Verification",
    "Hive Partner Onboarding - FULL": "1033665404",  # Hive Partner Onboarding
    # FT App based inspection items
    "FT - Customer Return - FULL": "1035433309",  # prod "FT - Customer Return - FULL"
    "FT - Customer Receiving - FULL": "1035433310",  # prod "FT - Customer Receiving - FULL"
    "FT - Customer Return - FULL - Eng Dev": "1035433311",  # stage "FT - Customer Return - FULL - Eng Dev"
    "FT - Customer Receiving - FULL - Eng Dev": "1035433312",  # stage "FT - Customer Receiving - FULL - Eng Dev"
}

APP_INSPECTION_PIPELINES = [
    "FT - Customer Return - FULL",
    "FT - Customer Receiving - FULL",
    "FT - Customer Return - FULL - Eng Dev",
    "FT - Customer Receiving - FULL - Eng Dev",
]


FIELD_MAPPINGS = {
    "inspection_name": {
        "path": "",
        "processor": "generate_inspection_name",
        "args": {"inspection_object_id": OBJECT_ID_MAPPING.get("inspection")},
    },
    "vin": "vehicle.vin",
    "additional_comments": "forms.data.additional_requirements.additional_comments",
    "address_of_inspection": "location.address",
    "any_other_shelving_or_equipment_pic_url_1": "forms.attachments.additional_requirements.take_a_photo_of_any_other_interior_shelvingequipment_if_installed.0.url",
    "any_other_shelving_or_equipment_pic_url_2": "forms.attachments.additional_requirements.take_a_photo_of_any_other_interior_shelvingequipment_if_installed.1.url",
    "any_other_shelving_or_equipment_pic_url_3": "forms.attachments.additional_requirements.take_a_photo_of_any_other_interior_shelvingequipment_if_installed.2.url",
    "any_visible_damage_pic_url_1": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.0.url",
    "any_visible_damage_pic_url_2": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.1.url",
    "any_visible_damage_pic_url_3": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.2.url",
    "any_visible_damage_pic_url_4": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.3.url",
    "any_visible_damage_pic_url_5": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.4.url",
    "any_visible_damage_pic_url_6": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.5.url",
    "any_visible_damage_pic_url_7": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.6.url",
    "any_visible_damage_pic_url_8": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.7.url",
    "any_visible_damage_pic_url_9": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.8.url",
    "any_visible_damage_pic_url_10": "forms.attachments.additional_requirements.does_the_vehicle_have_visible_damage.9.url",
    "cargo_area_from_the_rear_doors_pic_url__cloned_": "forms.attachments.additional_requirements.take_a_photo_of_the_cargo_area_from_the_rear_doors.0.url",
    "cargo_area_from_the_side_door_pic_url": "forms.attachments.additional_requirements.take_a_photo_of_the_cargo_area_from_the_side_door.0.url",
    "condition_report_url": "condition_report",
    "cr_rating": "inspection.grading.standard_A",
    "date_of_last_oil_change": "forms.data.additional_requirements.date_of_last_oil_change_if_applicable",
    "describe_any_visible_damage": "forms.data.additional_requirements.please_describe_any_visible_damage_if_applicable",
    "did_any_tires_get_replaced_while_in_your_possession": "forms.data.additional_requirements.did_any_tires_get_replaced_while_in_your_possession",
    "did_the_tires_get_rotated_while_in_your_possession": "forms.data.additional_requirements.did_the_tires_get_rotated_while_in_your_possession",
    "did_the_vehicle_get_an_oil_change_while_in_your_possession": "forms.data.additional_requirements.did_the_vehicle_get_an_oil_change_while_in_your_possession",
    "do_any_tires_need_to_be_replaced": "forms.data.additional_requirements.do_any_tires_need_to_be_replaced",
    "do_any_tires_need_to_be_rotated": "forms.data.additional_requirements.do_any_tires_need_to_be_rotated",
    "do_any_tires_need_to_be_rotated_or_replaced": "forms.data.additional_requirements.do_any_tires_need_to_be_rotated_or_replaced",
    "do_the_door_handles_work_properly": "forms.data.additional_requirements.do_the_door_handles_work_properly",
    "do_the_locks_work_properly": "forms.data.additional_requirements.do_the_locks_work_properly",
    "do_the_windows_work_properly": "forms.data.additional_requirements.do_the_windows_work_properly",
    "does_the_license_plate_match_the_registration": "forms.data.additional_requirements.does_the_license_plate_match_the_registration",
    "does_the_registration_vin_match_the_vehicle_vin_and_the_key_vin": "forms.data.additional_requirements.does_the_registration_vin_match_the_vehicle_vin_and_the_key_vin",
    "does_the_vehicle_have_any_cracks_or_chips_in_the_windshield": "forms.data.additional_requirements.does_the_windshield_have_any_cracks_or_chips",
    "does_the_vehicle_have_any_visible_damage": "forms.data.additional_requirements.does_the_vehicle_have_visible_damage",
    "does_the_vehicle_have_any_warning_lights_on": "forms.data.additional_requirements.does_the_vehicle_have_any_warning_lights_on",
    "does_the_vehicle_have_the_correct_package": "forms.data.additional_requirements.does_the_vehicle_have_the_correct_package",
    "does_the_vehicle_have_the_correct_signage": "forms.data.additional_requirements.does_the_vehicle_have_the_correct_signage",
    "does_the_vehicle_need_an_oil_change": "forms.data.additional_requirements.does_the_vehicle_need_an_oil_change",
    "does_the_vehicle_pass_kingbee_qc": "forms.data.additional_requirements.does_the_vehicle_pass_kingbee_qc",
    "does_the_vehicle_pass_kingbee_receiving_standards_and_is_ready_to_rent": "forms.data.additional_requirements.does_the_vehicle_pass_kingbee_receiving_standards_and_is_ready_to_rent",
    "does_the_vehicle_start": "forms.data.additional_requirements.does_the_vehicle_start",
    "does_the_vehicle_vin_match_the_key_vin": "forms.data.additional_requirements.does_the_vehicle_vin_match_key_vin",
    "driver_side_cargo_shelving_pic_url": "forms.attachments.additional_requirements.take_a_photo_of_the_driver_side_cargo_shelving_if_installed.0.url",
    "floor_between_the_driver_and_passenger_seats_pic_url": "forms.attachments.additional_requirements.take_a_photo_of_the_floor_between_the_driver_and_passenger_seats.0.url",
    # "hubspot_owner_assigneddate": NOT FOUND CURRENTLY,
    # "hubspot_owner_id": NOT FOUND CURRENTLY,
    # "hubspot_team_id": NOT FOUND CURRENTLY,
    "if_yes__which_tires_need_to_be_rotated_or_replaced": "forms.data.additional_requirements.if_yes_which_tires_need_to_be_rotated_or_replaced",
    "inspected_by": {
        "path": "session.options.contact",
        "processor": "concat_values",
        "args": {"values": ["first_name", "last_name"], "separator": " "},
    },
    "inspection_end_date": "session.inspect_ended_at",
    "inspection_started_at": "session.inspect_started_at",
    "inspection_type": "session.source.properties.api_name",
    "license_plate__": "forms.data.additional_requirements.enter_license_plate",
    "vin_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "VIN"},
    },
    "n2__interior_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Interior"},
    },
    "n2__cluster_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Cluster"},
    },
    "n4__driver_side_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Left"},
    },
    "n5__front_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Front"},
    },
    "n5__tires_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Tires"},
    },
    "n7__passenger_side_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Right"},
    },
    "n8__rear_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Rear"},
    },
    "n9__windshield_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Windshield"},
    },
    "n10__front_left_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Front_Left"},
    },
    "n11__front_right_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Front_Right"},
    },
    "n12__rear_left_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Rear_Left"},
    },
    "n12__rear_right_pic_url": {
        "path": "photos",
        "processor": "find_photo_by_label",
        "args": {"label": "Rear_Right"},
    },
    "notes_regarding_any_windshield_damage__if_applicable_": "forms.data.additional_requirements.please_enter_any_notes_regarding_any_windshield_damage_if_applicable",
    "notes_regarding_warning_lights__if_applicable_": "forms.data.additional_requirements.please_enter_any_notes_regarding_warning_lights_if_applicable",
    "odometer_reading_at_last_oil_change": {
        "path": "forms.data.additional_requirements.odometer_reading_at_last_oil_change_if_applicable",
        "processor": "parse_int",
        "args": {},
    },
    "odometer": "vehicle.odom_reading",
    "partition_pic_url": "forms.attachments.additional_requirements.take_a_photo_of_the_partition_if_installed.0.url",
    "passenger_side_cargo_shelving_pic_url": "forms.attachments.additional_requirements.take_a_photo_of_the_passenger_side_cargo_shelving_if_installed.0.url",
    "pave_session_key": "session.session_key",
    "phone__": "session.options.sms.to",
    "registration_pic_url": "forms.attachments.additional_requirements.is_the_registration_in_the_vehicle.0.url",
    "reservation_id": {
        "path": "session.options.reference.reservation_id",
        "processor": "parse_int",
        "args": {},
    },
    # "take_a_photo_of_the_vin_pic_url": {  DUPLICATE OF vin_pic_url
    #     "path": "photos",
    #     "processor": "find_photo_by_label",
    #     "args": {"label": "VIN"},
    # },
    # "tire_condition": NOT FOUND CURRENTLY,
    "total_repair_estimate": "inspection.estimates.total_new",
    "vin__last_8_": {
        "path": "vehicle.vin",
        "processor": "truncate_string",
        "args": {"index": -8},
    },
    "vin_from_inspection": "inspection.vin",
    "warning_lights_pic_url": "forms.attachments.additional_requirements.take_a_photo_of_the_dash_and_any_warning_lights_that_are_present.0.url",
    "_interior_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "02"},
    },
    "_interior_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "02"},
    },
    "_cluster_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "03"},
    },
    "_cluster_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "03"},
    },
    "_driver_side_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "04"},
    },
    "_driver_side_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "04"},
    },
    "_front_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "05"},
    },
    "_front_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "05"},
    },
    "_tires_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "06"},
    },
    "_tires_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "06"},
    },
    "_passenger_side_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "07"},
    },
    "_passenger_side_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "07"},
    },
    "_rear_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "08"},
    },
    "_rear_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "08"},
    },
    "_windshield_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "09"},
    },
    "_windshield_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "09"},
    },
    "_front_left_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "10"},
    },
    "_front_left_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "10"},
    },
    "_front_right_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "11"},
    },
    "_front_right_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "11"},
    },
    "_rear_left_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "13"},
    },
    "_rear_left_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "13"},
    },
    "_rear_right_pic_with_damage_circles": {
        "path": "inspection.detected_damages",
        "processor": "find_first_damage_photo_by_code",
        "args": {"code": "12"},
    },
    "_rear_right_pic_line_items": {
        "path": "inspection.detected_damages",
        "processor": "find_damage_line_items_by_code",
        "args": {"code": "12"},
    },
    "_which_tires_were_rotated": "forms.data.additional_requirements.if_yes_which_tires_were_rotated",
    "_last_tire_rotation_date": "forms.data.additional_requirements.date_of_last_tire_rotationif_applicable",
    "_last_tire_rotation_odometer": "forms.data.additional_requirements.odometer_reading_at_last_tire_rotation_if_applicable",
    "_which_tires_were_replaced": "forms.data.additional_requirements.if_yes_which_tires_were_replaced",
    "_last_tire_replacement_date": "forms.data.additional_requirements.date_of_last_tire_replacement_if_applicable",
    "_last_tire_replacement_odometer": "forms.data.additional_requirements.odometer_reading_at_last_tire_replacement",
    "_is_the_registration_in_the_vehicle": "forms.data.additional_requirements.is_the_registration_in_the_vehicle",
    "_has_the_registration_expired": "forms.data.additional_requirements.has_the_registration_expired",
    "_is_the_license_plate_installed": "forms.data.additional_requirements.is_the_license_plate_installed",
}

NOTE_ITEMS = [
    {"type": "header", "field": "inspection_name"},
    {
        "type": "pdf_link",
        "field": "condition_report_url",
        "label": "Condition Report (PDF)",
    },
    {"field": "pave_session_key", "label": "Pave Session Key"},
    {"field": "reservation_id", "label": "Reservation ID"},
    {"field": "vin", "label": "VIN"},
    {"field": "license_plate__", "label": "License Plate or Temp Plate"},
    {"field": "inspected_by", "label": "Inspected By"},
    {"field": "inspection_started_at", "label": "Inspection Started At"},
    {"field": "inspection_end_date", "label": "Inspection Completion Date"},
    {"field": "odometer", "label": "Odometer"},
    {"field": "cr_rating", "label": "CR Rating"},
    {
        "field": "does_the_vehicle_pass_kingbee_qc",
        "label": "Does the vehicle pass Kingbee QC?",
    },
    {
        "field": "does_the_vehicle_have_the_correct_package",
        "label": "Does the vehicle have the correct package?",
    },
    {
        "field": "does_the_vehicle_have_the_correct_signage",
        "label": "Does the vehicle have the correct signage?",
    },
    {
        "field": "does_the_vehicle_pass_kingbee_receiving_standards_and_is_ready_to_rent",
        "label": "Does the vehicle pass Kingbee Receiving Standards and is ready to rent?",
    },
    {
        "field": "does_the_vehicle_have_any_visible_damage",
        "label": "Does the vehicle have any visible damage?",
        "condition": lambda data: data is True,
        "children": [
            {
                "field": "notes_regarding_any_visible_damage__if_applicable_",
                "label": "Notes regarding any visible damage (if applicable)",
            },
        ],
    },
    {"field": "vin_pic_url", "label": "VIN Picture"},
    {"field": "n2__cluster_pic_url", "label": "Cluster Picture"},
    {
        "field": "does_the_vehicle_have_any_warning_lights_on",
        "label": "Does the vehicle have any warning lights on?",
        "condition": lambda data: data is True,
        "children": [
            {
                "field": "notes_regarding_warning_lights__if_applicable_",
                "label": "Notes regarding warning lights",
            },
            {"field": "warning_lights_pic_url", "label": "Warning Lights Picture"},
        ],
    },
    {"field": "n2__interior_pic_url", "label": "Interior Picture"},
    {"field": "n4__driver_side_pic_url", "label": "Driver Side Picture"},
    {"field": "n8__rear_pic_url", "label": "Rear Picture"},
    {"field": "n7__passenger_side_pic_url", "label": "Passenger Side Picture"},
    {"field": "n5__front_pic_url", "label": "Front Picture"},
    {
        "field": "cargo_area_from_the_side_door_pic_url",
        "label": "Cargo Area from the Side Door Picture",
    },
    {
        "field": "cargo_area_from_the_rear_doors_pic_url__cloned_",
        "label": "Cargo Area from the Rear Doors Picture",
    },
    {
        "field": "driver_side_cargo_shelving_pic_url",
        "label": "Driver Side Cargo Shelving Picture",
    },
    {
        "field": "passenger_side_cargo_shelving_pic_url",
        "label": "Passenger Side Cargo Shelving Picture",
    },
    {"field": "partition_pic_url", "label": "Partition Picture"},
    {
        "field": "any_other_shelving_or_equipment_pic_url_1",
        "label": "Any Other Shelving or Equipment Picture 1",
    },
    {
        "field": "any_other_shelving_or_equipment_pic_url_2",
        "label": "Any Other Shelving or Equipment Picture 2",
    },
    {
        "field": "any_other_shelving_or_equipment_pic_url_3",
        "label": "Any Other Shelving or Equipment Picture 3",
    },
    {
        "field": "_driver_side_pic_with_damage_circles",
        "label": "Driver Side Picture with Damage Circles (if applicable)",
        "children_list": "_driver_side_pic_line_items",
    },
    {
        "field": "_rear_pic_with_damage_circles",
        "label": "Rear Picture with Damage Circles (if applicable)",
        "children_list": "_rear_pic_line_items",
    },
    {
        "field": "_rear_left_pic_with_damage_circles",
        "label": "Rear Left Picture with Damage Circles (if applicable)",
        "children_list": "_rear_left_pic_line_items",
    },
    {
        "field": "_rear_right_pic_with_damage_circles",
        "label": "Rear Right Picture with Damage Circles (if applicable)",
        "children_list": "_rear_right_pic_line_items",
    },
    {
        "field": "_passenger_side_pic_with_damage_circles",
        "label": "Passenger Side Picture with Damage Circles (if applicable)",
        "children_list": "_passenger_side_pic_line_items",
    },
    {
        "field": "_front_pic_with_damage_circles",
        "label": "Front Picture with Damage Circles (if applicable)",
        "children_list": "_front_pic_line_items",
    },
    {
        "field": "_front_left_pic_with_damage_circles",
        "label": "Front Left Picture with Damage Circles (if applicable)",
        "children_list": "_front_left_pic_line_items",
    },
    {
        "field": "_front_right_pic_with_damage_circles",
        "label": "Front Right Picture with Damage Circles (if applicable)",
        "children_list": "_front_right_pic_line_items",
    },
    {
        "field": "_tires_pic_with_damage_circles",
        "label": "Tires Picture with Damage Circles (if applicable)",
        "children_list": "_tires_pic_line_items",
    },
    {
        "field": "does_the_vehicle_have_any_cracks_or_chips_in_the_windshield",
        "label": "Does the windshield have any cracks or chips?",
        "condition": lambda data: data is True,
        "children": [
            {
                "field": "notes_regarding_any_windshield_damage__if_applicable_",
                "label": "Notes regarding any windshield damage",
            },
        ],
    },
    {
        "field": "_windshield_pic_with_damage_circles",
        "label": "Windshield Picture with Damage Circles (if applicable)",
        "children_list": "_windshield_pic_line_items",
    },
    {
        "field": "does_the_vehicle_need_an_oil_change",
        "label": "Does the vehicle need an oil change?",
    },
    {
        "field": "did_the_vehicle_get_an_oil_change_while_in_your_possession",
        "label": "Did the vehicle get an oil change while in your possession?",
        "condition": lambda data: data is True,
        "children": [
            {
                "field": "odometer_reading_at_last_oil_change",
                "label": "Odometer Reading at Last Oil Change",
            },
            {
                "field": "date_of_last_oil_change",
                "label": "Date of Last Oil Change",
            },
        ],
    },
    {
        "field": "do_any_tires_need_to_be_rotated",
        "label": "Do any tires need to be rotated?",
    },
    {
        "field": "do_any_tires_need_to_be_replaced",
        "label": "Do any tires need to be replaced?",
    },
    {
        "field": "did_the_tires_get_rotated_while_in_your_possession",
        "label": "Did the tires get rotated while in your possession?",
        "condition": lambda data: data is True,
        "children": [
            {
                "field": "_last_tire_rotation_date",
                "label": "Last Tire Rotation Date",
            },
            {
                "field": "_last_tire_rotation_odometer",
                "label": "Last Tire Rotation Odometer",
            },
            {
                "field": "_which_tires_were_rotated",
                "label": "Which Tires Were Rotated",
            },
        ],
    },
    {
        "field": "did_any_tires_get_replaced_while_in_your_possession",
        "label": "Did any tires get replaced while in your possession?",
        "condition": lambda data: data is True,
        "children": [
            {
                "field": "_last_tire_replacement_date",
                "label": "Last Tire Replacement Date",
            },
            {
                "field": "_last_tire_replacement_odometer",
                "label": "Last Tire Replacement Odometer",
            },
            {
                "field": "_which_tires_were_replaced",
                "label": "Which Tires Were Replaced",
            },
        ],
    },
    {
        "field": "_is_the_registration_in_the_vehicle",
        "label": "Is the registration in the vehicle?",
        "condition": lambda data: data is False,
    },
    {
        "field": "_has_the_registration_expired",
        "label": "Has the registration expired?",
        "condition": lambda data: data is True,
    },
    {
        "field": "does_the_vehicle_start",
        "label": "Does the vehicle start?",
        "condition": lambda data: data is False,
    },
    {
        "field": "do_the_windows_work_properly",
        "label": "Do the windows work properly?",
        "condition": lambda data: data is False,
    },
    {
        "field": "do_the_door_handles_work_properly",
        "label": "Do the door handles work properly?",
        "condition": lambda data: data is False,
    },
    {
        "field": "do_the_locks_work_properly",
        "label": "Do the locks work properly?",
        "condition": lambda data: data is False,
    },
    {
        "field": "does_the_registration_vin_match_the_vehicle_vin_and_the_key_vin",
        "label": "Does the registration VIN match the vehicle VIN and the key VIN?",
        "condition": lambda data: data is False,
    },
    {
        "field": "does_the_license_plate_match_the_registration",
        "label": "Does the license plate match the registration?",
        "condition": lambda data: data is False,
    },
    {
        "field": "is_the_license_plate_installed",
        "label": "Is the license plate installed?",
    },
    {
        "field": "does_the_vehicle_have_any_visible_damage",
        "label": "Vehicle Damage Pictures should be below?",
        "condition": lambda data: data is True,
        "children": [
            {
                "field": "any_visible_damage_pic_url_1",
                "label": "Any Visible Damage Picture 1",
            },
            {
                "field": "any_visible_damage_pic_url_2",
                "label": "Any Visible Damage Picture 2",
            },
            {
                "field": "any_visible_damage_pic_url_3",
                "label": "Any Visible Damage Picture 3",
            },
            {
                "field": "any_visible_damage_pic_url_4",
                "label": "Any Visible Damage Picture 4",
            },
            {
                "field": "any_visible_damage_pic_url_5",
                "label": "Any Visible Damage Picture 5",
            },
            {
                "field": "any_visible_damage_pic_url_6",
                "label": "Any Visible Damage Picture 6",
            },
            {
                "field": "any_visible_damage_pic_url_7",
                "label": "Any Visible Damage Picture 7",
            },
            {
                "field": "any_visible_damage_pic_url_8",
                "label": "Any Visible Damage Picture 8",
            },
            {
                "field": "any_visible_damage_pic_url_9",
                "label": "Any Visible Damage Picture 9",
            },
            {
                "field": "any_visible_damage_pic_url_10",
                "label": "Any Visible Damage Picture 10",
            },
        ],
    },
]
