import os

GCS_BUCKET = "pave-inspection-details"
HUBSPOT_ACCESS_TOKEN = os.environ.get("HUBSPOT_ACCESS_TOKEN", None)
SENDGRID_API_KEY = os.environ.get("SENDGRID_API_KEY", None)
