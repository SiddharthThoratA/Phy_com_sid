import json
import logging


class JsonFormatter(logging.Formatter):
    """Custom formatter to output logs in JSON format."""

    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "log_level": record.levelname,
            "log_message": record.getMessage(),
        }
        return json.dumps(log_entry)


logger = logging.getLogger("global_json_logger")
logger.setLevel(logging.DEBUG)

if not logger.hasHandlers():
    logger.propagate = False
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logger.addHandler(handler)


def get_logger() -> logging.Logger:
    return logger
