import os
import traceback

import requests

from config.logger import logger
from utils.helpers import send_email


def mark_inspection_complete_neptune(session_key, source_name):
    base_url, email, password = None, None, None
    try:
        if source_name[-7:] == "Eng Dev":
            email = os.environ.get("NEPTUNE_STAGE_EMAIL")
            password = os.environ.get("NEPTUNE_STAGE_PASSWORD")
            base_url = os.environ.get("NEPTUNE_STAGE_BASE_URL")
        else:
            email = os.environ.get("NEPTUNE_EMAIL")
            password = os.environ.get("NEPTUNE_PASSWORD")
            base_url = os.environ.get("NEPTUNE_BASE_URL")

        login_url = "api/login"
        login_json = {
            "email": email,
            "password": password,
        }
        response = requests.post(f"{base_url}/{login_url}", json=login_json)
        response.raise_for_status()
        token = response.json()["data"]["token"]

        pave_inspection_endpoint = "api/v1/reservations/pave_inspections"
        params = {"session-keys": f"{session_key}"}

        response = requests.get(
            f"{base_url}/{pave_inspection_endpoint}",
            headers={"Authorization": f"Bearer {token}"},
            params=params,
        )
        response.raise_for_status()
        pave_inspection_uuid = response.json()["data"][0]["paveInspectionUUID"]
        if not pave_inspection_uuid:
            send_email(
                "Neptune API: Pave Inspection UUID Not Found",
                f"Unable to find Pave Inspection UUID for session key: {session_key}",
                "data-engineering@kingbee-vans.com",
            )
        patch_payload = {
            "uuid": pave_inspection_uuid,
            "status": "COMPLETE",
        }

        response = requests.patch(
            f"{base_url}/{pave_inspection_endpoint}",
            json=patch_payload,
            headers={"Authorization": f"Bearer {token}"},
        )
        response.raise_for_status()
    except Exception as e:
        logger.error(
            f"Error marking inspection '{session_key}' complete in Neptune: {str(e)}"
        )
        content = "<p>Function mark_inspection_complete_neptune failed.</p>"
        content += f"<p>Error: {e}</p>"
        content += (
            "<pre>"
            + "".join(traceback.format_exception(type(e), e, e.__traceback__))
            + "</pre>"
        )
        subject = f"Neptune API: Marking PAVE Inspection '{session_key}'-'{source_name}' Complete in Neptune Failed"
        send_email(subject, content, "data-engineering@kingbee-vans.com")
    return


def mark_inspection_status_change_neptune(
    session_key: str, status: str | None, form_submitted: bool | None
) -> None:
    """Update the status of a Pave Inspection in Neptune (prod first, then stage)."""

    def try_env(env_prefix: str) -> tuple[str | None, str | None, str]:
        if env_prefix == "PROD":
            email = os.environ.get("NEPTUNE_EMAIL")
            password = os.environ.get("NEPTUNE_PASSWORD")
            base_url = os.environ.get("NEPTUNE_BASE_URL")
        else:
            email = os.environ.get(f"NEPTUNE_{env_prefix}_EMAIL")
            password = os.environ.get(f"NEPTUNE_{env_prefix}_PASSWORD")
            base_url = os.environ.get(f"NEPTUNE_{env_prefix}_BASE_URL")
        login_url = f"{base_url}/api/login"
        login_json = {"email": email, "password": password}

        response = requests.post(login_url, json=login_json)
        response.raise_for_status()
        token = response.json()["data"]["token"]

        params = {"session-keys": session_key}
        inspection_url = f"{base_url}/api/v1/reservations/pave_inspections"
        response = requests.get(
            inspection_url, headers={"Authorization": f"Bearer {token}"}, params=params
        )
        response.raise_for_status()

        data = response.json().get("data")
        if data:
            return data[0]["paveInspectionUUID"], token, env_prefix.lower()
        return None, token, env_prefix.lower()

    try:
        pave_inspection_uuid, token, env, base_url = None, None, None, None

        try:
            logger.info("Trying to find Pave Inspection UUID in PROD environment")
            pave_inspection_uuid, token, env = try_env("PROD")
        except Exception as e:
            logger.info(f"Prod env error: {e}")

        if not pave_inspection_uuid:
            try:
                logger.info("Trying to find Pave Inspection UUID in STAGE environment")
                pave_inspection_uuid, token, env = try_env("STAGE")
            except Exception as e:
                raise Exception("Both prod and stage environments failed") from e
        logger.info(f"Found Pave Inspection UUID: {pave_inspection_uuid} in env: {env}")

        if not pave_inspection_uuid or not env:
            send_email(
                "Neptune API: Pave Inspection UUID Not Found",
                f"Unable to find Pave Inspection UUID for session key: {session_key} in either environment",
                "data-engineering@kingbee-vans.com",
            )
            return

        if env == "prod":
            base_url = os.environ.get("NEPTUNE_BASE_URL")
        elif env:
            base_url = os.environ.get(f"NEPTUNE_{env.upper()}_BASE_URL")

        if status:
            patch_payload = {"uuid": pave_inspection_uuid, "status": status}
            logger.info(
                f"Marking inspection '{session_key}' with status: '{status}' in Neptune env: '{env}'"
            )
        elif form_submitted:
            patch_payload = {
                "uuid": pave_inspection_uuid,
                "formSubmitted": form_submitted,
            }
            logger.info(
                f"Marking inspection '{session_key}' with formSubmitted: '{form_submitted}' in Neptune env: '{env}'"
            )
        else:
            logger.error(
                f"Either one of status or form_submitted should be non-null for inspection: '{session_key}'"
            )
            raise Exception("Either status or form_submitted should be non-null")
        patch_url = f"{base_url}/api/v1/reservations/pave_inspections"
        response = requests.patch(
            patch_url,
            json=patch_payload,
            headers={"Authorization": f"Bearer {token}"},
        )
        if response.status_code:
            logger.info(f"Status code from Neptune: {response.status_code}")
        if response.text:
            logger.info(f"Response text from Neptune: {response.text}")
        if response.headers:
            logger.info(f"Response headers from Neptune: {response.headers}")
        response.raise_for_status()
        return

    except Exception as e:
        logger.info(
            f"Error marking inspection '{session_key}' with status: {status}: {e}"
        )
        content = f"<p>Function mark_inspection_status_change_neptune with status {status} failed.</p>"
        content += f"<p>Error: {e}</p><pre>{''.join(traceback.format_exception(type(e), e, e.__traceback__))}</pre>"
        subject = (
            f"Neptune API: Marking PAVE Inspection '{session_key}' with {status} Failed"
        )
        send_email(subject, content, "data-engineering@kingbee-vans.com")
        return
