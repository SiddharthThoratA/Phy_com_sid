import functools
import logging
import time
import traceback
from typing import Any, Callable, Literal

import sendgrid

from config.config import SENDGRID_API_KEY
from config.logger import logger


def send_email(
    subject: str,
    content: str,
    email: str,
) -> None:
    sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)
    message = sendgrid.Mail(
        from_email="data-monitoring@kingbee-vans.com",
        to_emails=email,
        subject=subject,
        html_content=content,
    )
    try:
        response = sg.send(message)
        logger.info(f"Email sent to {email} with status code {response.status_code}")
    except Exception as e:
        logger.error(f"Error sending email to {email}: {e}")


def retry_decorator(
    max_retries: int = 5,
    delay: int = 20,
    delay_type: Literal["exponential", "linear"] = "linear",
    email_on_max_retries: bool = True,
) -> Callable:
    def decorator(func) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            base_delay = delay
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt < max_retries - 1:
                        if delay_type == "exponential":
                            sleep_seconds = base_delay * 2**attempt
                        else:
                            sleep_seconds = base_delay
                        logging.info(
                            f"Attempt {attempt + 2} in {sleep_seconds} seconds. Exception: {traceback.format_exc()}"
                        )
                        time.sleep(sleep_seconds)
                    else:
                        logging.error(
                            f"Max retries reached: {e}\n"
                            + "".join(
                                traceback.format_exception(type(e), e, e.__traceback__)
                            )
                        )
                        subject = "Error Notification: Max Retries Reached"
                        content = f"<p>Function {func.__name__} failed after {max_retries} attempts.</p>"
                        content += f"<p>Error: {e}</p>"
                        content += (
                            "<pre>"
                            + "".join(
                                traceback.format_exception(type(e), e, e.__traceback__)
                            )
                            + "</pre>"
                        )
                        if email_on_max_retries:
                            email = "data-monitoring@kingbee-vans.com"
                        else:
                            email = "data-engineering@kingbee-vans.com"
                        send_email(subject, content, email)
                        raise

        return wrapper

    return decorator
