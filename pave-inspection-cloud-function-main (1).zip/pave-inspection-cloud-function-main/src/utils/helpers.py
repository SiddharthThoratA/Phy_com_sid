import io
import mimetypes
from datetime import datetime
from urllib.parse import unquote

import requests
import sendgrid
from google.cloud import storage
from PIL import Image

from config.config import GCS_BUCKET, HUBSPOT_ACCESS_TOKEN, SENDGRID_API_KEY
from config.logger import logger
from hubspot.hubspot_helper import HubSpotHelper
from mappings.mappings import FIELD_MAPPINGS, NOTE_ITEMS
from utils.retry_decorator import retry_decorator


def send_email(
    subject: str,
    content: str,
    email: str | list[str],
) -> None:
    sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)
    message = sendgrid.Mail(
        from_email="data-monitoring@kingbee-vans.com",
        to_emails=email,
        subject=subject,
        html_content=content,
    )
    try:
        response = sg.send(message)
        logger.info(f"Email sent to {email} with status code {response.status_code}")
    except Exception as e:
        logger.error(f"Error sending email to {email}: {e}")


def parse_int(value, default=None):
    """Parse integer value with default"""
    try:
        return str(int(value))
    except (ValueError, TypeError):
        try:
            return str(int(value.replace(",", "")))
        except (ValueError, AttributeError):
            return default


def truncate_string(value, index):
    """Truncate string to specified length"""
    if index > 0:
        return value[:index]
    return value[index:]


def find_photo_by_label(photos, label):
    """Find photo URL by label in list of photos"""
    for photo in photos:
        if photo.get("photo_label") == label:
            return photo.get("url")
    return None


def check_if_inspection_exists(name, inspection_object_id):
    hubspot = HubSpotHelper(pat_token=HUBSPOT_ACCESS_TOKEN)
    return (
        hubspot.search_object_get_id(inspection_object_id, "inspection_name", name)
        is not None
    )


def generate_inspection_name(data, inspection_object_id):
    """Combines VIN, source API name, and current date while ensuring name does not exist"""
    vin = get_nested_value(data, "vehicle.vin")
    if vin is None:
        raise ValueError("VIN not found in data")
    source_name = get_nested_value(data, "session.source.properties.api_name")
    if source_name is None:
        raise ValueError("Source API name not found in data")
    current_date = datetime.now().strftime("%Y-%m-%d")
    base_name = f"{current_date} - {vin} - {source_name}"
    inspection_name = base_name
    attempt = 1
    while check_if_inspection_exists(inspection_name, inspection_object_id):
        attempt += 1
        inspection_name = f"{base_name} UPLOAD {attempt}"
    return inspection_name


def process_field(data, mapping=None):
    """Process field value based on mapping"""
    if isinstance(mapping, dict):
        processor = globals().get(mapping["processor"])
        value = get_nested_value(data, mapping["path"]) if mapping["path"] else data
        return processor(value, **mapping["args"]) if processor else None
    else:
        return get_nested_value(data, mapping)


def replace_characters(data, characters: list[str], replacement: list[str]):
    """Replace characters in data with replacement characters"""
    for char, repl in zip(characters, replacement):
        data = data.replace(char, repl)
    return data


def concat_values(data, values: list[str], separator: str = " "):
    """Concatenate values with separator"""
    output = []
    for value in values:
        if not get_nested_value(data, value):
            pass
        else:
            output.append(get_nested_value(data, str(value)))
    return separator.join(output)


def get_nested_value(data, path):
    """Get nested value from data based on dot-separated path"""
    keys = path.split(".")
    value = data
    for key in keys:
        if isinstance(value, list):
            try:
                index = int(key)
                value = value[index] if index < len(value) else None
            except ValueError:
                logger.error(f"Invalid index: {key}")
                return None
        elif isinstance(value, dict):
            value = value.get(key)
        else:
            return None
        if value is None:
            break
    return value


def upload_to_gcs(bucket_name, destination, content):
    """Upload content to GCS bucket with proper MIME type handling"""
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(destination)

    content_type, _ = mimetypes.guess_type(destination)
    if not content_type:
        if destination.endswith(".json"):
            content_type = "application/json"
        elif destination.endswith(".pdf"):
            content_type = "application/pdf"
        elif destination.lower().endswith((".png", ".jpg", ".jpeg", ".gif")):
            content_type = f"image/{destination.split('.')[-1].lower()}"
            if content_type == "image/jpg":
                content_type = "image/jpeg"
        else:
            content_type = "application/octet-stream"

    if isinstance(content, str) and content_type.startswith("text"):
        blob.upload_from_string(content, content_type=content_type or "text/plain")
    else:
        blob.upload_from_string(
            content, content_type=content_type or "application/octet-stream"
        )

    return f"gs://{bucket_name}/{destination}"


def process_inspection(data):
    """Process inspection data and return flat structure"""
    flat_data = {}
    for field, mapping in FIELD_MAPPINGS.items():
        flat_data[field] = process_field(data, mapping)
    return flat_data


def sanitize_filename(name):
    """Remove invalid characters for HubSpot filenames"""
    decoded = unquote(name)
    decoded = decoded.replace(" ", "")
    decoded = decoded.replace("-", "_")
    return decoded


def is_valid_jpeg(image_path: str) -> bool:
    """Check if image is a valid JPEG"""
    try:
        with Image.open(image_path) as img:
            img.verify()
        return True
    except Exception as e:
        logger.error(f"Invalid image: {e}")
        return False


def find_first_damage_photo_by_code(data: list | None, code: str):
    """Find first damage photo URL by code in list of damage items"""

    if not data:
        return None
    for damage_item in data:
        if get_nested_value(damage_item, "photo.code") == code:
            return get_nested_value(damage_item, "photo.url")
    return None


def find_damage_line_items_by_code(data: list | None, code: str):
    """Find all damage line items by code in list of damage items"""
    line_items = []
    if not data:
        return line_items
    for damage_item in data:
        if get_nested_value(damage_item, "photo.code") == code:
            line_item = " | ".join(
                [
                    "Location: " + str(damage_item.get("component_label", "N/A")),
                    "Label: " + str(damage_item.get("label", "N/A")),
                    "Estimated Cost: " + str(damage_item.get("total", "N/A")),
                ]
            )
            line_items.append(line_item)
    return line_items


def build_note_html(flat_data: dict) -> str:
    """Build an HTML note from flat_data using NOTE_ITEMS."""
    parts: list[str] = [
        "<!DOCTYPE html>",
        "<html>",
        "<head></head>",
        "<body>",
    ]

    for item in NOTE_ITEMS:
        field: str = item["field"]
        note_type: str = item.get("type", "normal")
        label: str = item.get("label", field)
        condition = item.get("condition")
        children = item.get("children", [])
        children_list_key = item.get("children_list")

        if condition is not None:
            field_value = flat_data.get(field)
            if not condition(field_value):
                continue

        value = flat_data.get(field)
        if not value and value != 0:
            continue

        if note_type == "header":
            parts.append(f"<h1>{value}</h1>")
        elif note_type == "pdf_link":
            parts.append(
                f'<p><b>{label}:</b> <a href="{value}" target="_blank">{label}</a></p>'
            )
        elif isinstance(value, str) and value.startswith("https://"):
            parts.append(
                f'<div><p><b>{label} (Image Below):</b></p><img src="{value}" alt="{label}" style="max-width: 100%; height: auto;"></div>'
            )
        else:
            parts.append(f"<p><b>{label}:</b> {value}</p>")

        for child in children:
            cfield = child["field"]
            clabel = child.get("label", cfield)
            cvalue = flat_data.get(cfield)
            if cvalue and not cvalue.startswith("https://"):
                parts.append(f"<p><b>{clabel}:</b> {cvalue}</p>")
            if cvalue and cvalue.startswith("https://"):
                parts.append(
                    f'<div><p><b>{clabel} (Image Below):</b></p><img src="{cvalue}" alt="{clabel}" style="max-width: 100%; height: auto;"></div>'
                )

        if children_list_key and children_list_key in flat_data:
            child_list_data = flat_data[children_list_key]
            if isinstance(child_list_data, list) and child_list_data:
                parts.append("<ul>")
                for li_item in child_list_data:
                    parts.append(f"<li>{li_item}</li>")
                parts.append("</ul>")

    parts.append("</body>")
    parts.append("</html>")
    if not parts:
        logger.warning("No note items found")
    return "\n".join(parts)


@retry_decorator(max_retries=5, delay=1, delay_type="exponential")
def get_pave_data(data):
    response = requests.get(data, timeout=20)
    response.raise_for_status()
    return io.BytesIO(response.content), response.content


def create_hubspot_files_and_note_html(
    flat_data: dict, gcs_path: str, session_key: str
) -> tuple[dict, str, list]:
    """Handle image and pdf uploads to Hubspot and create note"""
    upload_unix_timestamp = datetime.now().timestamp()
    hubspot = HubSpotHelper(pat_token=HUBSPOT_ACCESS_TOKEN)
    inspection_name = flat_data.get("inspection_name")
    vin = flat_data.get("vin")
    note_attachment_ids = []
    date_str = datetime.now().isoformat()[:10]

    for field_name, data in flat_data.items():
        if not data or not isinstance(data, str):
            pass
        elif data.endswith(".jpg"):
            try:
                image_data, response_content = get_pave_data(data)
                image_response = hubspot.upload_file(
                    file_source=image_data,
                    folder_path=f"inspections/{vin}/{inspection_name}/{upload_unix_timestamp}",
                    file_name=sanitize_filename(
                        f"{vin}_{datetime.now().date()}_{field_name}.jpg"
                    ),
                    overwrite=True,
                    access="PUBLIC_NOT_INDEXABLE",
                )
                gcs_path = (
                    f"inspections/{vin}/{date_str}/{session_key}/{field_name}.jpg"
                )
                upload_to_gcs(GCS_BUCKET, gcs_path, response_content)
                flat_data[field_name] = image_response.get("url", None)
                if image_response.get("id", None):
                    note_attachment_ids.append(image_response.get("id"))
            except Exception as e:
                logger.error(f"Error uploading image: {str(e)}")
        elif field_name == "condition_report_url":
            try:
                pdf_data, response_content = get_pave_data(data)
                pdf_response = hubspot.upload_file(
                    file_source=pdf_data,
                    folder_path=f"inspections/{vin}/{inspection_name}/{upload_unix_timestamp}",
                    file_name=sanitize_filename(
                        f"{vin}_{datetime.now().date()}_{field_name}.pdf"
                    ),
                    overwrite=True,
                )
                gcs_path = (
                    f"inspections/{vin}/{date_str}/{session_key}/{field_name}.pdf"
                )

                upload_to_gcs(GCS_BUCKET, gcs_path, response_content)
                flat_data[field_name] = pdf_response.get("url", None)
            except Exception as e:
                logger.error(f"Error uploading pdf: {str(e)}")
        else:
            pass

    final_note = build_note_html(flat_data)
    final_flat_data = {k: v for k, v in flat_data.items() if not k.startswith("_")}
    return final_flat_data, final_note, note_attachment_ids
