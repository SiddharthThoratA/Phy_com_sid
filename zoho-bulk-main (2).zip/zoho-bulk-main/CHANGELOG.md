# Changelog

## [1.3.6](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.3.5...v1.3.6) (2025-06-14)


### :wrench: Chores

* runtime ([#137](https://github.com/fluidtruck-data/zoho-bulk/issues/137)) ([c096811](https://github.com/fluidtruck-data/zoho-bulk/commit/c09681134e92e13ca6a6d267d8c63fbeffac8305))

## [1.3.5](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.3.4...v1.3.5) (2025-03-25)


### :wrench: Chores

* emails to kingbee-vans ([#135](https://github.com/fluidtruck-data/zoho-bulk/issues/135)) ([f4219f8](https://github.com/fluidtruck-data/zoho-bulk/commit/f4219f89b4da37186e4660b9aee2278bc31bebbf))

## [1.3.4](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.3.3...v1.3.4) (2025-01-14)


### :wrench: Chores

* set cpu and mem resources ([806f736](https://github.com/fluidtruck-data/zoho-bulk/commit/806f7365fec5907d9f6b2ecfb90285fe2656f984))

## [1.3.3](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.3.2...v1.3.3) (2024-10-15)


### :wrench: Chores

* update helm to 2.2.3 ([#132](https://github.com/fluidtruck-data/zoho-bulk/issues/132)) ([cc67b93](https://github.com/fluidtruck-data/zoho-bulk/commit/cc67b93416c1dc03d659ac435db40d618bbc5daf))

## [1.3.2](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.3.1...v1.3.2) (2024-10-02)


### :bug: Bug Fixes

* entrypoint path ([#130](https://github.com/fluidtruck-data/zoho-bulk/issues/130)) ([578d7c7](https://github.com/fluidtruck-data/zoho-bulk/commit/578d7c7d7d6f24b86d9bd8f675a83b051bde0475))


### :wrench: Chores

* alter logging to capture uvicorn ([#131](https://github.com/fluidtruck-data/zoho-bulk/issues/131)) ([271d1f4](https://github.com/fluidtruck-data/zoho-bulk/commit/271d1f455ca6e756ae4f7764c9eab14bfcf7206e))
* log consul ([#128](https://github.com/fluidtruck-data/zoho-bulk/issues/128)) ([700d529](https://github.com/fluidtruck-data/zoho-bulk/commit/700d5291b38f831636156f191faead4da87544bd))
* log consul attempt ([#129](https://github.com/fluidtruck-data/zoho-bulk/issues/129)) ([7ee477a](https://github.com/fluidtruck-data/zoho-bulk/commit/7ee477aeb9035bc69efe8d228270f78244722b59))
* queue safety ([#125](https://github.com/fluidtruck-data/zoho-bulk/issues/125)) ([1469fc9](https://github.com/fluidtruck-data/zoho-bulk/commit/1469fc9a5605a3f8553e369c78f82dde178a8b50))
* remove newrelic ([#127](https://github.com/fluidtruck-data/zoho-bulk/issues/127)) ([f3b6645](https://github.com/fluidtruck-data/zoho-bulk/commit/f3b6645f7aa88b209b1b7e5addbcd7ba362f551c))

## [1.3.1](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.3.0...v1.3.1) (2024-07-26)


### :hammer: Code Refactoring

* lessen GCS calls ([#122](https://github.com/fluidtruck-data/zoho-bulk/issues/122)) ([882572c](https://github.com/fluidtruck-data/zoho-bulk/commit/882572c870efcc2c9b37ef546d268fff70e16236))


### :wrench: Chores

* cache start file for killswitch ([#124](https://github.com/fluidtruck-data/zoho-bulk/issues/124)) ([fcdf6b9](https://github.com/fluidtruck-data/zoho-bulk/commit/fcdf6b9474c7f5cffd27d8347b07fd33563b1919))

## [1.3.0](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.12...v1.3.0) (2024-07-25)


### :sparkles: Features

* add killswitch ([#119](https://github.com/fluidtruck-data/zoho-bulk/issues/119)) ([4917a14](https://github.com/fluidtruck-data/zoho-bulk/commit/4917a14e54446d9acb1d848d1b7bde647406bb2d))


### :bug: Bug Fixes

* capture GCP post error and better logging ([#114](https://github.com/fluidtruck-data/zoho-bulk/issues/114)) ([96e9f95](https://github.com/fluidtruck-data/zoho-bulk/commit/96e9f9523b73c480c415959eb4d25442bae57455))
* enable shutdown ([#120](https://github.com/fluidtruck-data/zoho-bulk/issues/120)) ([d967ed9](https://github.com/fluidtruck-data/zoho-bulk/commit/d967ed94fe287f900a6d1a26e878bc97806aa395))
* job result not triggering ([#118](https://github.com/fluidtruck-data/zoho-bulk/issues/118)) ([4173eab](https://github.com/fluidtruck-data/zoho-bulk/commit/4173eab6b1981997d330fa84d599d5e23a35ceed))
* yield generator to allow new entries ([#117](https://github.com/fluidtruck-data/zoho-bulk/issues/117)) ([cca920d](https://github.com/fluidtruck-data/zoho-bulk/commit/cca920dbde7121cf57c4b294a8dd6afd23a3f4f6))


### :wrench: Chores

* add extra logging ([#116](https://github.com/fluidtruck-data/zoho-bulk/issues/116)) ([341131c](https://github.com/fluidtruck-data/zoho-bulk/commit/341131ccce45de71770909d6fa453f78ac902365))
* move wait to after upload ([#121](https://github.com/fluidtruck-data/zoho-bulk/issues/121)) ([b441335](https://github.com/fluidtruck-data/zoho-bulk/commit/b44133590b38f1d14b1f771c903a9d414d3f1c39))

## [1.2.12](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.11...v1.2.12) (2024-07-03)


### :bug: Bug Fixes

* attempt to prevent infinite run in get_job_result ([#112](https://github.com/fluidtruck-data/zoho-bulk/issues/112)) ([16a4525](https://github.com/fluidtruck-data/zoho-bulk/commit/16a4525a01ad3e5be9b893bb75983c7fcaf1a619))

## [1.2.11](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.10...v1.2.11) (2024-07-01)


### :bug: Bug Fixes

* enable clean timer kill ([#110](https://github.com/fluidtruck-data/zoho-bulk/issues/110)) ([744eda7](https://github.com/fluidtruck-data/zoho-bulk/commit/744eda75c022d218001d6b016affa299a9bcbb8a))
* end timer ([#111](https://github.com/fluidtruck-data/zoho-bulk/issues/111)) ([fbc935b](https://github.com/fluidtruck-data/zoho-bulk/commit/fbc935b99aa6cfb417a19012a50ef0fe26200736))


### :hammer: Code Refactoring

* reorganize and add timeout ([#109](https://github.com/fluidtruck-data/zoho-bulk/issues/109)) ([f486357](https://github.com/fluidtruck-data/zoho-bulk/commit/f486357f4b58490b85764b90428cae4971d23cd3))


### :wrench: Chores

* allow hung threads to end ([#106](https://github.com/fluidtruck-data/zoho-bulk/issues/106)) ([f25d869](https://github.com/fluidtruck-data/zoho-bulk/commit/f25d8698f51a0d3113b7aa01e1a97edc1dfefc4c))
* **thread-killing:** return None not logging.error ([#108](https://github.com/fluidtruck-data/zoho-bulk/issues/108)) ([4867139](https://github.com/fluidtruck-data/zoho-bulk/commit/4867139d424f1be6fcf309f26af9db549abe398f))

## [1.2.10](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.9...v1.2.10) (2024-06-04)


### :bug: Bug Fixes

* additional gcs rate limiter check ([#103](https://github.com/fluidtruck-data/zoho-bulk/issues/103)) ([ab07661](https://github.com/fluidtruck-data/zoho-bulk/commit/ab076611eda2da9b741e31f9bb615bf53dfc6a16))
* continuous call correction ([#105](https://github.com/fluidtruck-data/zoho-bulk/issues/105)) ([f6860e6](https://github.com/fluidtruck-data/zoho-bulk/commit/f6860e636e992a79ebf17dcfcfaa88e686679417))
* global lock ([#104](https://github.com/fluidtruck-data/zoho-bulk/issues/104)) ([4334110](https://github.com/fluidtruck-data/zoho-bulk/commit/43341102e825086cd89551beca916c0abd6e3cec))
* lock GCS file transfers, retry failed job ([#101](https://github.com/fluidtruck-data/zoho-bulk/issues/101)) ([60e0f37](https://github.com/fluidtruck-data/zoho-bulk/commit/60e0f37954486692696907d102b2ed755a5fd237))

## [1.2.9](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.8...v1.2.9) (2024-05-29)


### :wrench: Chores

* add monitoring logging ([#100](https://github.com/fluidtruck-data/zoho-bulk/issues/100)) ([2bddd9e](https://github.com/fluidtruck-data/zoho-bulk/commit/2bddd9e40951db469687af166cb1ab6023027a27))


### :robot: CI/CD

* allow full CD run from workflow_dispatch ([#99](https://github.com/fluidtruck-data/zoho-bulk/issues/99)) ([c19d02f](https://github.com/fluidtruck-data/zoho-bulk/commit/c19d02f0690d0326f6f6cc103a91ac0a5bccf05e))
* allow manual CD workflow trigger ([#97](https://github.com/fluidtruck-data/zoho-bulk/issues/97)) ([d0ffd08](https://github.com/fluidtruck-data/zoho-bulk/commit/d0ffd08f470efb825ee66ea8ddcdf69c316a6a44))

## [1.2.8](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.7...v1.2.8) (2024-05-22)


### :wrench: Chores

* move staging out of final subfolder ([#94](https://github.com/fluidtruck-data/zoho-bulk/issues/94)) ([d7b9fa7](https://github.com/fluidtruck-data/zoho-bulk/commit/d7b9fa70805e6240dc191d22a1844c0561079693))
* update requests for vulnerability ([#96](https://github.com/fluidtruck-data/zoho-bulk/issues/96)) ([cf23354](https://github.com/fluidtruck-data/zoho-bulk/commit/cf2335445bcea8b14b0f22b12098cd6eb90f401d))

## [1.2.7](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.6...v1.2.7) (2024-05-21)


### :bug: Bug Fixes

* logging ([#90](https://github.com/fluidtruck-data/zoho-bulk/issues/90)) ([5998d15](https://github.com/fluidtruck-data/zoho-bulk/commit/5998d151446f7f45c8d3f7698ac00bb06a5dd4e7))
* switch staging at end ([#91](https://github.com/fluidtruck-data/zoho-bulk/issues/91)) ([1c0da92](https://github.com/fluidtruck-data/zoho-bulk/commit/1c0da920aaeb8768bd40a35d3e528db9021906f9))


### :wrench: Chores

* add GCS staging ([#88](https://github.com/fluidtruck-data/zoho-bulk/issues/88)) ([fb7f6f4](https://github.com/fluidtruck-data/zoho-bulk/commit/fb7f6f40fb94c18392bd8f25ee86481ed8633a31))
* add prod check to dag trigger ([#92](https://github.com/fluidtruck-data/zoho-bulk/issues/92)) ([46ff12b](https://github.com/fluidtruck-data/zoho-bulk/commit/46ff12bb70a5442295c527af5a42b357e9bb0765))
* clear spawned threads ([#93](https://github.com/fluidtruck-data/zoho-bulk/issues/93)) ([cf4f4fc](https://github.com/fluidtruck-data/zoho-bulk/commit/cf4f4fcfd70f5f806b342c44c70d167ee1b75a40))

## [1.2.6](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.5...v1.2.6) (2024-05-10)


### :bug: Bug Fixes

* empty json response catch ([#85](https://github.com/fluidtruck-data/zoho-bulk/issues/85)) ([29a6462](https://github.com/fluidtruck-data/zoho-bulk/commit/29a646206804f369648a697666bec64cba4047d3))


### :robot: CI/CD

* account for Google Breaking Change ([#86](https://github.com/fluidtruck-data/zoho-bulk/issues/86)) ([314e7c0](https://github.com/fluidtruck-data/zoho-bulk/commit/314e7c09dacdaf2c1617eacb7b41b24a61f1d2bc))

## [1.2.5](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.4...v1.2.5) (2024-03-22)


### :wrench: Chores

* add logging filter for 'Incoming Request' ([#83](https://github.com/fluidtruck-data/zoho-bulk/issues/83)) ([ae7a8c9](https://github.com/fluidtruck-data/zoho-bulk/commit/ae7a8c9d53d023659122de392ed78a4c2534ba53))
* add logging filter for json 'Incoming Request' ([#84](https://github.com/fluidtruck-data/zoho-bulk/issues/84)) ([2324a88](https://github.com/fluidtruck-data/zoho-bulk/commit/2324a886978bb4f3b1bcb52378ee360e4ffcb1d0))
* stream to stdout explicitly ([#82](https://github.com/fluidtruck-data/zoho-bulk/issues/82)) ([d15af21](https://github.com/fluidtruck-data/zoho-bulk/commit/d15af21ec02fd436459f13fe6397f0dad5c7860e))


### :robot: CI/CD

* release-please update ([#80](https://github.com/fluidtruck-data/zoho-bulk/issues/80)) ([9c802ab](https://github.com/fluidtruck-data/zoho-bulk/commit/9c802ab447e8396469bebd92572d8883cd3f23e9))

## [1.2.4](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.3...v1.2.4) (2024-03-20)


### :bug: Bug Fixes

* yield None and better error parsing ([#76](https://github.com/fluidtruck-data/zoho-bulk/issues/76)) ([c94a654](https://github.com/fluidtruck-data/zoho-bulk/commit/c94a65481d4adb1fe845e885f323dfefdeeb00f7))


### :wrench: Chores

* make new pr to try deploy ([#79](https://github.com/fluidtruck-data/zoho-bulk/issues/79)) ([83ee182](https://github.com/fluidtruck-data/zoho-bulk/commit/83ee18264df85a8de85091d3ac3eee197b48216e))
* use the correct cursor ([#78](https://github.com/fluidtruck-data/zoho-bulk/issues/78)) ([90e7fae](https://github.com/fluidtruck-data/zoho-bulk/commit/90e7faeaa9ad93b4b715fdc244db9843eb48d173))

## [1.2.3](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.2...v1.2.3) (2024-03-19)


### :wrench: Chores

* check attempts to limit ([#75](https://github.com/fluidtruck-data/zoho-bulk/issues/75)) ([946b356](https://github.com/fluidtruck-data/zoho-bulk/commit/946b356ab5b4d841afa5ea2c54e66c67f1b5f5b5))
* retry empty file ([#73](https://github.com/fluidtruck-data/zoho-bulk/issues/73)) ([5c76035](https://github.com/fluidtruck-data/zoho-bulk/commit/5c76035054d0971f3b3ef277d4b87fa10723cd21))

## [1.2.2](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.1...v1.2.2) (2024-03-08)


### :wrench: Chores

* shorten heartbeat ([#71](https://github.com/fluidtruck-data/zoho-bulk/issues/71)) ([f63c85a](https://github.com/fluidtruck-data/zoho-bulk/commit/f63c85a02ebf96454ed46ba2b134cabc293d508a))

## [1.2.1](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.2.0...v1.2.1) (2024-03-06)


### :wrench: Chores

* add allowance for mispelled tables ([#70](https://github.com/fluidtruck-data/zoho-bulk/issues/70)) ([455cee0](https://github.com/fluidtruck-data/zoho-bulk/commit/455cee01d8478b1733f703c8db3cbd01812a0af8))
* delete from stage source ([#69](https://github.com/fluidtruck-data/zoho-bulk/issues/69)) ([c77a94c](https://github.com/fluidtruck-data/zoho-bulk/commit/c77a94c7f7a26ceb7f3a6d066a7c9c5abe3b8681))
* separate stage and prod uploads ([#68](https://github.com/fluidtruck-data/zoho-bulk/issues/68)) ([e7c3e61](https://github.com/fluidtruck-data/zoho-bulk/commit/e7c3e614cf7019931902a335fa642fca1cc9f723))


### :robot: CI/CD

* bump python to v2.0.1 ([#66](https://github.com/fluidtruck-data/zoho-bulk/issues/66)) ([d0e95aa](https://github.com/fluidtruck-data/zoho-bulk/commit/d0e95aa323d99bb6c1e5c17eb0f310bba4e5b1b5))

## [1.2.0](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.7...v1.2.0) (2023-12-14)


### :sparkles: Features

* add email upon job completion ([#64](https://github.com/fluidtruck-data/zoho-bulk/issues/64)) ([a6933f1](https://github.com/fluidtruck-data/zoho-bulk/commit/a6933f1a8d11e6d89519d7f030c9841d52058344))

## [1.1.7](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.6...v1.1.7) (2023-12-11)


### :wrench: Chores

* logging to INFO ([#62](https://github.com/fluidtruck-data/zoho-bulk/issues/62)) ([24499db](https://github.com/fluidtruck-data/zoho-bulk/commit/24499db534603a4e2e12d4f43d80caa3ba2533a5))

## [1.1.6](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.5...v1.1.6) (2023-12-07)


### :wrench: Chores

* add heartbeat for logging failure ([#60](https://github.com/fluidtruck-data/zoho-bulk/issues/60)) ([aac3683](https://github.com/fluidtruck-data/zoho-bulk/commit/aac3683bd80cadf03ce5dc7507357aa5922856c6))
* add retry ([#55](https://github.com/fluidtruck-data/zoho-bulk/issues/55)) ([120d9f8](https://github.com/fluidtruck-data/zoho-bulk/commit/120d9f8d527fd6b7efc0c3a6c97a013fc1a9c200))
* **deps:** bump google-github-actions/release-please-action from 3 to 4 ([#54](https://github.com/fluidtruck-data/zoho-bulk/issues/54)) ([42481d3](https://github.com/fluidtruck-data/zoho-bulk/commit/42481d319a5fa6c6aa21aaca2c990d74c0ad64a3))
* release-please v4 had breaking changes ([#58](https://github.com/fluidtruck-data/zoho-bulk/issues/58)) ([9fc3237](https://github.com/fluidtruck-data/zoho-bulk/commit/9fc3237461d58ec7e7ef1116b31b5f8ea2beb04e))


### :robot: CI/CD

* further changes ([#57](https://github.com/fluidtruck-data/zoho-bulk/issues/57)) ([08d176c](https://github.com/fluidtruck-data/zoho-bulk/commit/08d176c782b9c895740d02b21fc92edbcdebf03d))
* update release please ([#56](https://github.com/fluidtruck-data/zoho-bulk/issues/56)) ([3e29639](https://github.com/fluidtruck-data/zoho-bulk/commit/3e2963907d9684c6ad638f35e32e113c05b09fe2))

## [1.1.5](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.4...v1.1.5) (2023-11-29)


### :wrench: Chores

* add logging, fix order ([#52](https://github.com/fluidtruck-data/zoho-bulk/issues/52)) ([3a47cca](https://github.com/fluidtruck-data/zoho-bulk/commit/3a47cca2cc824f140b1b4338960fdb671d92d686))
* log zoho auth closure ([#53](https://github.com/fluidtruck-data/zoho-bulk/issues/53)) ([f559e03](https://github.com/fluidtruck-data/zoho-bulk/commit/f559e03fe281f070c3a6e8f5ce7a80b6b20c6b1d))
* pause stage run ([#50](https://github.com/fluidtruck-data/zoho-bulk/issues/50)) ([d0470d4](https://github.com/fluidtruck-data/zoho-bulk/commit/d0470d424989f4453a333ba83c2eb1e119c0633f))

## [1.1.4](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.3...v1.1.4) (2023-11-28)


### :bug: Bug Fixes

* retry limiting ([#47](https://github.com/fluidtruck-data/zoho-bulk/issues/47)) ([33329c7](https://github.com/fluidtruck-data/zoho-bulk/commit/33329c7d87fbc69203030f15b2dc31f52499a0a2))
* update headers ([#49](https://github.com/fluidtruck-data/zoho-bulk/issues/49)) ([70283ca](https://github.com/fluidtruck-data/zoho-bulk/commit/70283ca152af3f4f9c5cc1efdac16eeef2dc5998))

## [1.1.3](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.2...v1.1.3) (2023-11-28)


### :bug: Bug Fixes

* add retries ([#45](https://github.com/fluidtruck-data/zoho-bulk/issues/45)) ([d8f9586](https://github.com/fluidtruck-data/zoho-bulk/commit/d8f9586a25b761473d12aefd9bbbce0c05532989))
* auth cleanup ([#46](https://github.com/fluidtruck-data/zoho-bulk/issues/46)) ([cb2a6f4](https://github.com/fluidtruck-data/zoho-bulk/commit/cb2a6f45881caabce7b8ae18caf60cd09df9020f))
* Created centralized Auth Manager ([#43](https://github.com/fluidtruck-data/zoho-bulk/issues/43)) ([887fd1d](https://github.com/fluidtruck-data/zoho-bulk/commit/887fd1dbbb8a626525b1d64cfb815758b9eb8f50))

## [1.1.2](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.1...v1.1.2) (2023-11-20)


### :wrench: Chores

* add retry, short timer for stage test ([#41](https://github.com/fluidtruck-data/zoho-bulk/issues/41)) ([7e6ec37](https://github.com/fluidtruck-data/zoho-bulk/commit/7e6ec371a34e4753cec03047efdc5535ef710f54))
* timer for 55 minutes ([#42](https://github.com/fluidtruck-data/zoho-bulk/issues/42)) ([00ca269](https://github.com/fluidtruck-data/zoho-bulk/commit/00ca269f02c0e5a8119d5b5bd77365b8b2e7c193))
* update repo for local running and ruff ([#39](https://github.com/fluidtruck-data/zoho-bulk/issues/39)) ([407b772](https://github.com/fluidtruck-data/zoho-bulk/commit/407b772fee73ce80a0855a47a1188e41cbfe8438))

## [1.1.1](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.1.0...v1.1.1) (2023-11-06)


### :bug: Bug Fixes

* All_Claims_Export crashes, lower read ([392857c](https://github.com/fluidtruck-data/zoho-bulk/commit/392857cdb6dc5655eac2844ba845afbc6a57aa39))
* deal with empty buffer ([#36](https://github.com/fluidtruck-data/zoho-bulk/issues/36)) ([fefb3ef](https://github.com/fluidtruck-data/zoho-bulk/commit/fefb3efaa1a66a52649a5d6789851d86768bb6de))
* init buffer ([623e4a4](https://github.com/fluidtruck-data/zoho-bulk/commit/623e4a493eed92d1076b3c37b5214511b26513f7))
* initialize new buffer after closing the uploaded one ([ab47c83](https://github.com/fluidtruck-data/zoho-bulk/commit/ab47c831239239f9061a6cfe9c44c5893ad5cab3))
* lower concurrency ([df32403](https://github.com/fluidtruck-data/zoho-bulk/commit/df324036ffddb731e56c8be1c9466130f1a7bf47))


### :wrench: Chores

* add additional limiting ([#37](https://github.com/fluidtruck-data/zoho-bulk/issues/37)) ([4a438e5](https://github.com/fluidtruck-data/zoho-bulk/commit/4a438e5adcafab797b2dfe54f769180e2b5ed866))
* add logging to see where it fails ([fa8d529](https://github.com/fluidtruck-data/zoho-bulk/commit/fa8d5296a3d31d42f2ecda68ed3d3b08afaacee8))
* lower workers again ([ad864f7](https://github.com/fluidtruck-data/zoho-bulk/commit/ad864f75f5a822921f423f0e3dbf0499e45b0c90))
* results lock ([#38](https://github.com/fluidtruck-data/zoho-bulk/issues/38)) ([6af2936](https://github.com/fluidtruck-data/zoho-bulk/commit/6af293628d86b75cc61b39b4f7448118df908255))
* try limiting size ([#35](https://github.com/fluidtruck-data/zoho-bulk/issues/35)) ([a32eea1](https://github.com/fluidtruck-data/zoho-bulk/commit/a32eea1379cb5b1f96054d6a5ad2f2684856c57c))
* try smaller batch size ([a3f3f37](https://github.com/fluidtruck-data/zoho-bulk/commit/a3f3f3758ff3a129e6a83ecd30f9a05d62c24047))
* try smaller batch size ([f74a49d](https://github.com/fluidtruck-data/zoho-bulk/commit/f74a49d7e573e91be6fa4dbd318b227ad6ab055e))
* Vehicle_Local_Move_Request_Report_Export test ([28b2e39](https://github.com/fluidtruck-data/zoho-bulk/commit/28b2e3986876839be51726261e1d5e3a213a75aa))

## [1.1.0](https://github.com/fluidtruck-data/zoho-bulk/compare/v1.0.0...v1.1.0) (2023-11-04)


### :sparkles: Features

* limited cpu usage ([#33](https://github.com/fluidtruck-data/zoho-bulk/issues/33)) ([21c7426](https://github.com/fluidtruck-data/zoho-bulk/commit/21c74264e4b793c12fea7d079c1e01c2239c155a))


### :wrench: Chores

* add logging ([#12](https://github.com/fluidtruck-data/zoho-bulk/issues/12)) ([db8c3b8](https://github.com/fluidtruck-data/zoho-bulk/commit/db8c3b871df1671827d2d218448a764cffce8a20))
* add subscription switching ([#17](https://github.com/fluidtruck-data/zoho-bulk/issues/17)) ([b0ff28f](https://github.com/fluidtruck-data/zoho-bulk/commit/b0ff28f3743e739fdf2985dc29b292cd23cc9b4d))
* additional testing ([#13](https://github.com/fluidtruck-data/zoho-bulk/issues/13)) ([a7ac0a2](https://github.com/fluidtruck-data/zoho-bulk/commit/a7ac0a27e5e639bb553453b94b83e5339aff0778))
* adjust read limiter ([#20](https://github.com/fluidtruck-data/zoho-bulk/issues/20)) ([5caa358](https://github.com/fluidtruck-data/zoho-bulk/commit/5caa3583638757f9c716fe3d857b5872766aa2e4))
* adjust yaml ([#26](https://github.com/fluidtruck-data/zoho-bulk/issues/26)) ([8b285b8](https://github.com/fluidtruck-data/zoho-bulk/commit/8b285b853597f2598f1b882ca5f5c9e5402be49c))
* decrease avro file size ([#27](https://github.com/fluidtruck-data/zoho-bulk/issues/27)) ([a8267e9](https://github.com/fluidtruck-data/zoho-bulk/commit/a8267e96463557d85f08a423a77b8d8441da1a97))
* decrease avro further ([#28](https://github.com/fluidtruck-data/zoho-bulk/issues/28)) ([76ba9dd](https://github.com/fluidtruck-data/zoho-bulk/commit/76ba9dd1bd401a3ae4c433324d79157383083e89))
* even more ([#15](https://github.com/fluidtruck-data/zoho-bulk/issues/15)) ([2207290](https://github.com/fluidtruck-data/zoho-bulk/commit/220729034ef6b41812485be76beb05f65accb419))
* even smaller writer size ([e3b2330](https://github.com/fluidtruck-data/zoho-bulk/commit/e3b23309c4d0792b5752a011162433d8bac49c02))
* get job results testing ([#14](https://github.com/fluidtruck-data/zoho-bulk/issues/14)) ([b611aa2](https://github.com/fluidtruck-data/zoho-bulk/commit/b611aa2f1130e196b1fbdd1e2e3329b51fdae92f))
* lessen concurrency ([#30](https://github.com/fluidtruck-data/zoho-bulk/issues/30)) ([dc44dda](https://github.com/fluidtruck-data/zoho-bulk/commit/dc44ddab754b00618626b46adea22d124420e115))
* limit writer ([#31](https://github.com/fluidtruck-data/zoho-bulk/issues/31)) ([221d151](https://github.com/fluidtruck-data/zoho-bulk/commit/221d15125f711c829847a6662bde47022e1b0719))
* log inside ([#22](https://github.com/fluidtruck-data/zoho-bulk/issues/22)) ([3bc1cb3](https://github.com/fluidtruck-data/zoho-bulk/commit/3bc1cb3cbbb075f2b9d39fcfe838562028e81992))
* logs on logs ([#24](https://github.com/fluidtruck-data/zoho-bulk/issues/24)) ([ea710a0](https://github.com/fluidtruck-data/zoho-bulk/commit/ea710a05f8deb3e7b4081e25372a6ac9f3ef0799))
* remove extra logging ([#19](https://github.com/fluidtruck-data/zoho-bulk/issues/19)) ([98c452b](https://github.com/fluidtruck-data/zoho-bulk/commit/98c452b07f74c11c2b3acea3bed8fcfaa7add45e))
* remove extra logging ([#29](https://github.com/fluidtruck-data/zoho-bulk/issues/29)) ([58f2982](https://github.com/fluidtruck-data/zoho-bulk/commit/58f2982faaba56d652e90036cc8d6a78310764d0))
* response content check ([#21](https://github.com/fluidtruck-data/zoho-bulk/issues/21)) ([53258d2](https://github.com/fluidtruck-data/zoho-bulk/commit/53258d2bf228f38c19edfb39bfbfc5e336fe4dea))
* something different ([#16](https://github.com/fluidtruck-data/zoho-bulk/issues/16)) ([ff1cd00](https://github.com/fluidtruck-data/zoho-bulk/commit/ff1cd007aadf4ee24b986fc3056f4518f4ea98ea))
* subscription logging ([#10](https://github.com/fluidtruck-data/zoho-bulk/issues/10)) ([fe0bb22](https://github.com/fluidtruck-data/zoho-bulk/commit/fe0bb2222a9204b90b6e96d871186d173295fb6d))
* test downstream ([#25](https://github.com/fluidtruck-data/zoho-bulk/issues/25)) ([e8b11a7](https://github.com/fluidtruck-data/zoho-bulk/commit/e8b11a7f2f446fdf6c5133be48bb642ea8c51828))
* try print csv ([#23](https://github.com/fluidtruck-data/zoho-bulk/issues/23)) ([f15f95a](https://github.com/fluidtruck-data/zoho-bulk/commit/f15f95a662f3ee3538bd230eeef17e8540fb1011))
* update subscription and remove potentially crashing log ([#18](https://github.com/fluidtruck-data/zoho-bulk/issues/18)) ([f7ae992](https://github.com/fluidtruck-data/zoho-bulk/commit/f7ae99240ab0c3dce8c4b39259149c8c5cbc89c5))
* wait for csv, 3 threads only ([#32](https://github.com/fluidtruck-data/zoho-bulk/issues/32)) ([5a054dd](https://github.com/fluidtruck-data/zoho-bulk/commit/5a054dd76a93b78c7cc58ed4a41e04821ec566ff))

## 1.0.0 (2023-11-02)


### :sparkles: Features

* initial transfer of existing code ([#3](https://github.com/fluidtruck-data/zoho-bulk/issues/3)) ([d55e591](https://github.com/fluidtruck-data/zoho-bulk/commit/d55e5919b0ae540176054ca2fb85cee5c6b0505a))


### :wrench: Chores

* add subscription code back in ([#9](https://github.com/fluidtruck-data/zoho-bulk/issues/9)) ([55c245f](https://github.com/fluidtruck-data/zoho-bulk/commit/55c245fb48fc21e52a36b32bb97fdaf238b43a5f))
* adjusted startup subscription ([#5](https://github.com/fluidtruck-data/zoho-bulk/issues/5)) ([3b55bd7](https://github.com/fluidtruck-data/zoho-bulk/commit/3b55bd7057aa7f7035b27a23273ee64559198fa4))
* attempt new subscription fxn ([#6](https://github.com/fluidtruck-data/zoho-bulk/issues/6)) ([4b67a40](https://github.com/fluidtruck-data/zoho-bulk/commit/4b67a4003e713ac4051bb22676d8265f481c67dc))
* changed readme ([#4](https://github.com/fluidtruck-data/zoho-bulk/issues/4)) ([de9da40](https://github.com/fluidtruck-data/zoho-bulk/commit/de9da409d3c4489620c590f3a53a97478a470cba))
* remove golang left overs ([1e5386d](https://github.com/fluidtruck-data/zoho-bulk/commit/1e5386de8363eaafea353f37fbf744c62db19597))
* scaffolded with backstage :tada: ([4030e6f](https://github.com/fluidtruck-data/zoho-bulk/commit/4030e6fc0ca1411835c66c50531f5117de1c5452))
* test ([#7](https://github.com/fluidtruck-data/zoho-bulk/issues/7)) ([b6e8041](https://github.com/fluidtruck-data/zoho-bulk/commit/b6e8041a14d70dbea28b81c89bb28dd1c80270b3))
* trigger settings snyc ([9998c6a](https://github.com/fluidtruck-data/zoho-bulk/commit/9998c6a3f4f8734db56b9fc45240e02f1057d441))
* trigger settings sync ([02f8e4e](https://github.com/fluidtruck-data/zoho-bulk/commit/02f8e4e7be348950d304565365c93c669d3639c9))
* try add a / endpoint ([#8](https://github.com/fluidtruck-data/zoho-bulk/issues/8)) ([7983edb](https://github.com/fluidtruck-data/zoho-bulk/commit/7983edbb623d3ebcfa2b78da71d4243405376909))


### :robot: CI/CD

* use 1.3.2 chart ([#2](https://github.com/fluidtruck-data/zoho-bulk/issues/2)) ([5671363](https://github.com/fluidtruck-data/zoho-bulk/commit/5671363d429018778c726694787d1da7bfabdb9d))
