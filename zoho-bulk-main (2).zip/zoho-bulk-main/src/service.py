import logging
from typing import Any

from job.zoho_bulk import zoho_bulk


def convert_strings(data: list[list[str]]) -> list[list[Any]]:
    typed_data = []
    for sublist in data:
        new_sublist = []
        for value in sublist:
            if value.isdigit():
                new_sublist.append(int(value))
            elif value.lower() == "true":
                new_sublist.append(True)
            elif value.lower() == "false":
                new_sublist.append(False)
            elif value.lower() == "null":
                new_sublist.append(None)
            elif value.lower() == "":
                new_sublist.append(None)
            else:
                try:
                    new_sublist.append(float(value))
                except ValueError:
                    new_sublist.append(value)
        typed_data.append(new_sublist)
    return typed_data


def service(data: list[list[str]], job_type: str | None, email: str) -> None:
    typed_data = convert_strings(data)
    logging.info(f"ready to call service_run with: {typed_data}")
    service_run(typed_data, job_type, email)


def service_run(data: list[list[Any]], job_type: str | None, email: str):
    zoho_bulk(data, job_type, email)
