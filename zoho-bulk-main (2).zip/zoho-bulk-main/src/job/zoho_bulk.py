import concurrent.futures
import logging
import threading
import time
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

import job.constants.globals as globals
from job.constants.constants import (
    ENV,
    ZOHO_CREATOR_CLIENT_ID,
    ZOHO_CREATOR_CLIENT_SECRET,
    ZOHO_CREATOR_REFRESH_TOKEN,
)
from job.job_handler.job_handler import BulkJobHandler
from job.utils.external_communication import (
    send_completion_email,
    send_global_timer_email,
    send_heartbeat,
    send_killed_thread_email,
)
from job.utils.gcs_fxns import upload_dag_trigger_to_gcs
from job.utils.global_classes import RateLimiter
from job.utils.zoho_auth import ZohoAuthManager

thread_names = {}


def worker(handler: BulkJobHandler, thread_names: dict) -> None:
    thread_name = handler.report
    threading.current_thread().name = thread_name
    thread_names[threading.get_ident()] = thread_name
    logging.info(f"Thread {thread_name} started.")
    try:
        handler.initiate_job()
    except Exception as e:
        logging.error(f"Error in thread {thread_name}: {e}")
        send_killed_thread_email(job=thread_name, failure_type=f"Uncaught: {e} ")
    finally:
        logging.info(f"Thread {thread_name} finished.")


def zoho_bulk(data: list[list[Any]], job_type: str | None, email: str) -> None:
    start_time = datetime.now(ZoneInfo("UTC"))
    jobs = [row[0] for row in data]
    logging.info(f"{job_type=}")
    logging.info(f"{jobs=}")
    stop_heartbeat = None
    if job_type == "full" and ENV == "prod":
        logging.info("starting the heartbeat thread")
        stop_heartbeat = threading.Event()
        heartbeat_thread = threading.Thread(
            target=send_heartbeat, args=(stop_heartbeat,), daemon=True
        )
        heartbeat_thread.start()
    create_limiter = RateLimiter(5, 61)
    read_limiter = RateLimiter(10, 61)
    gcs_limiter = RateLimiter(1, 2)

    if (
        ZOHO_CREATOR_REFRESH_TOKEN
        and ZOHO_CREATOR_CLIENT_SECRET
        and ZOHO_CREATOR_CLIENT_ID
    ):
        zoho_client = ZohoAuthManager(
            client_id=ZOHO_CREATOR_CLIENT_ID,
            client_secret=ZOHO_CREATOR_CLIENT_SECRET,
            refresh_token=ZOHO_CREATOR_REFRESH_TOKEN,
            update_interval=3000,
        )
        time.sleep(5)
    else:
        logging.error("Cannot access Zoho Creator. Ending Run.")
        return

    if not job_type:
        job_type = "partial"
    globals.runtime_checks.start_job(job_type)

    handlers = [
        BulkJobHandler(create_limiter, read_limiter, gcs_limiter, zoho_client, job)
        for job in jobs
    ]

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        future_to_handler = {
            executor.submit(worker, handler, thread_names): handler
            for handler in handlers
        }

        while not globals.runtime_checks.should_terminate("concurrent futures") and any(
            not future.done() for future in future_to_handler
        ):
            time.sleep(5)

    if globals.runtime_checks.should_terminate("thread wrap-ups"):
        for future in future_to_handler:
            future.cancel()
        for thread in globals.q.queue:
            thread.join()
        logging.info("All threads terminated")
        send_killed_thread_email(job="Main Thread", failure_type="Runtime Checks")

        return

    try:
        for future in future_to_handler:
            handler = future_to_handler[future]
            try:
                future.result()
            except Exception as exc:
                logging.error(f"Handler {handler.report} generated an exception: {exc}")
            else:
                logging.info(f"Handler {handler.report} completed.")

        while not globals.q.empty():
            thread = globals.q.get()
            thread.join()
            logging.info(f"Joined thread {thread.name}")

        if job_type == "full" and ENV == "prod":
            logging.info("uploading dag trigger to gcs")
            if not globals.runtime_checks.should_terminate("dag_trigger_file"):
                upload_dag_trigger_to_gcs()
            if stop_heartbeat and not stop_heartbeat.is_set():
                logging.info("stopping the heartbeat thread")
                stop_heartbeat.set()
        else:
            logging.info("partial run, not uploading dag trigger")
        logging.info("stopping the auth refresh thread")
        if not globals.runtime_checks.should_terminate("final check"):
            send_completion_email(email, jobs, job_type, start_time)
        else:
            send_global_timer_email()
        zoho_client.stop()
        globals.runtime_checks.stop_job()
    except Exception as e:
        logging.error(f"Error in main thread: {e}")
        send_killed_thread_email(job="Main Thread", failure_type=f"Uncaught: {e}")
        logging.info("the job did not complete successfully")
        logging.info("stopping the auth refresh thread")
        zoho_client.stop()
        if stop_heartbeat and not stop_heartbeat.is_set():
            logging.info("stopping the heartbeat thread")
            stop_heartbeat.set()
        globals.runtime_checks.stop_job()
