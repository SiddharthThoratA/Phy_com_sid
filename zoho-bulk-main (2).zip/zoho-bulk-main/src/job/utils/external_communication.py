import json
import logging
import threading
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import requests
import sendgrid
from google.cloud import storage

from job.constants.constants import (
    BUCKET,
    DATA_ANALYTICS_SLACK_URL,
    ENV,
    HEARTBEAT_GCS_LOCATION,
    SENDGRID_API_KEY,
)


def send_completion_email(
    email: str, jobs: list[str], job_type: str | None, start_time: datetime
) -> None:
    bullet_points = "".join([f"<li>{job}</li>" for job in jobs])
    duration = datetime.now(ZoneInfo("UTC")) - start_time
    html_content = (
        f"<p>The following jobs have been completed at {datetime.now(ZoneInfo('UTC'))}"
        f"UTC in {duration}:</p><ul>{bullet_points}</ul>"
    )
    sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)
    if ENV != "prod" and job_type == "full":
        subject = f"{ENV} Zoho Bulk Refresh Completed"
    elif job_type == "full":
        subject = "Full Zoho Bulk Refresh Completed"
    else:
        subject = "Zoho Bulk Airflow Triggered Job Completed"
    message = sendgrid.Mail(
        from_email="data-monitoring@kingbee-vans.com",
        to_emails=email,
        subject=subject,
        html_content=html_content,
    )
    try:
        response = sg.send(message)
        logging.info(f"Email sent to {email} with status code {response.status_code}")
    except Exception as e:
        logging.error(f"Error sending email to {email}: {e}")


def send_empty_file_email(
    job: str, attempt: int, cursor: str | None, job_id: str | None
) -> None:
    html_content = (
        f"<p>Job-id {job}-{job_id} attempt {attempt} of 2"
        f" with cursor: {cursor} has returned an empty file at {datetime.now()} UTC</p>"
    )
    sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)
    subject = "Zoho Bulk Job Returned Empty File"
    message = sendgrid.Mail(
        from_email="data-monitoring@kingbee-vans.com",
        to_emails="data-engineering@kingbee-vans.com",
        subject=subject,
        html_content=html_content,
    )
    try:
        response = sg.send(message)
        logging.info(f"Email sent with status code {response.status_code}")
    except Exception as e:
        logging.error(f"Error sending email: {e}")


def send_killed_thread_email(job: str, failure_type: str) -> None:
    html_content = f"<p>Job {job} failed at {failure_type} at {datetime.now()} UTC</p>"
    sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)
    subject = "Zoho Bulk Thread Failure"
    message = sendgrid.Mail(
        from_email="data-monitoring@kingbee-vans.com",
        to_emails="data-engineering@kingbee-vans.com",
        subject=subject,
        html_content=html_content,
    )
    try:
        response = sg.send(message)
        logging.info(f"Email sent with status code {response.status_code}")
    except Exception as e:
        logging.error(f"Error sending email: {e}")


def send_global_timer_email() -> None:
    html_content = (
        f"<p>Global Timer ran out and all jobs killed at {datetime.now()} UTC</p>"
    )
    sg = sendgrid.SendGridAPIClient(api_key=SENDGRID_API_KEY)
    subject = "Zoho Global Timer Failure"
    message = sendgrid.Mail(
        from_email="data-monitoring@kingbee-vans.com",
        to_emails="data-engineering@kingbee-vans.com",
        subject=subject,
        html_content=html_content,
    )
    try:
        response = sg.send(message)
        logging.info(f"Email sent with status code {response.status_code}")
    except Exception as e:
        logging.error(f"Error sending email: {e}")


def send_heartbeat(stop_heartbeat: threading.Event) -> None:
    try:
        storage_client = storage.Client()
        bucket = storage_client.bucket(BUCKET)
        date = time.strftime("%Y%m%d")
        while not stop_heartbeat.is_set():
            logging.info("Heartbeat in progress")
            in_progress_file = f"{HEARTBEAT_GCS_LOCATION}/{date}/in_progress.txt"
            blob = bucket.blob(in_progress_file)
            blob.upload_from_string("")
            logging.info("Heartbeat uploaded")
            time.sleep(60)
        logging.info("Heartbeat stopped")
        finished_file = f"{HEARTBEAT_GCS_LOCATION}/{date}/finished.txt"
        blob = bucket.blob(finished_file)
        blob.upload_from_string("")
        logging.info("Heartbeat finished")
    except Exception as e:
        logging.exception(f"Exception in sending the heartbeat: {e}")
        raise


def send_slack_message(message: str) -> None:
    try:
        slack_data = {"text": message}
        if not DATA_ANALYTICS_SLACK_URL:
            logging.error("Slack URL not found")
            raise
        response = requests.post(
            DATA_ANALYTICS_SLACK_URL,
            data=json.dumps(slack_data),
            headers={"Content-Type": "application/json"},
        )
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        logging.exception(f"Exception in sending the slack message: {e}")
        raise
