import functools
import logging
from typing import Any, Callable
import time


def retry_decorator(max_retries: int = 3, delay: int = 20) -> Callable:
    def decorator(func) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception:
                    if attempt < max_retries - 1:
                        logging.info(f"Attempt {attempt + 2} in {delay} seconds.")
                        time.sleep(delay)
                    else:
                        logging.error("Max retries reached.", exc_info=True)
                        raise

        return wrapper

    return decorator
