import logging
import threading
from typing import IO, Any

import pandas as pd


def csv_to_avro_format(df_chunk: pd.DataFrame) -> list[Any]:
    records = []
    for _, row in df_chunk.iterrows():
        try:
            record = {
                "id": str(row.get("ID", "N/A")),
                "thefield": row.to_json(),
            }
        except Exception:
            logging.error(f"Unable to write the following record to avro format: {row}")
            continue
        records.append(record)
    return records


def read_csv_in_chunks(csv_file: IO, lock: threading.Lock, chunksize: int = 5000):
    try:
        csv_iterator = pd.read_csv(
            csv_file, chunksize=chunksize, dtype=str, iterator=True
        )
    except pd.errors.EmptyDataError:
        logging.error(f"Empty CSV file: {csv_file.name}")
        yield None
        return
    while True:
        try:
            with lock:
                chunk = next(csv_iterator)
            yield chunk
        except StopIteration:
            break
