import logging
import threading
import time

from google.cloud import storage

from job.constants.constants import BUCKET


class RateLimiter:
    def __init__(self, limit: int, seconds: int):
        self.limit = limit
        self.seconds = seconds
        self.timestamps = []
        self.lock = threading.Lock()
        self.logger = logging.getLogger(__name__)

    def can_call(self) -> bool:
        with self.lock:
            now = time.time()
            timeframe = now - self.seconds

            self.timestamps = [
                timestamp for timestamp in self.timestamps if timestamp > timeframe
            ]

            if len(self.timestamps) < self.limit:
                self.timestamps.append(now)
                return True
            else:
                return False

    def execute_in_continuous_section(self, func, *args, **kwargs):
        self.logger.info("Attempting to acquire continuous section lock.")
        with self.lock:
            self.logger.info("Continuous section lock acquired.")
            result = func(*args, **kwargs)
            self.logger.info("Continuous section lock released.")
            return result


class GlobalTimer:
    def __init__(self, duration: int) -> None:
        self.duration = duration
        self.terminate_event = threading.Event()
        self.timer_thread = None
        self.is_running = False
        self.end_time = 0

    def start_timer(self) -> None:
        current_time = time.time()
        if self.is_running:
            self.end_time = current_time + self.duration
            logging.info(f"Timer extended. New end time: {self.end_time}")
            return

        self.terminate_event.clear()
        self.end_time = current_time + self.duration
        self.timer_thread = threading.Thread(target=self._timer_func)
        self.timer_thread.start()
        self.is_running = True
        logging.info(f"Global timer started. End time: {self.end_time}")

    def _timer_func(self) -> None:
        while time.time() < self.end_time and not self.terminate_event.is_set():
            time.sleep(1)

        if not self.terminate_event.is_set():
            logging.info("Global timer expired. Signaling to terminate.")
            self.terminate_event.set()
        self.is_running = False

    def should_terminate(self) -> bool:
        return self.terminate_event.is_set()

    def stop_timer(self) -> None:
        if not self.is_running:
            logging.warning("Timer is not running. Ignoring stop request.")
            return

        self.terminate_event.set()
        if self.timer_thread and self.timer_thread.is_alive():
            self.timer_thread.join()
        self.is_running = False
        self.timer_thread = None
        logging.info("Timer stopped.")


class RuntimeChecks:
    def __init__(self, duration: int, file_name: str):
        self.global_timer = GlobalTimer(duration)
        self.bucket_name = BUCKET
        self.file_name = file_name
        self.start_time = None
        self.termination_flag = False
        self.termination_reason = ""
        self.cached_upload_time = None
        self.last_gcs_check_time = 0
        self.cache_ttl = 10

    def start_job(self, job_type: str):
        if job_type == "full":
            self._update_gcs_file()
            if self.start_time:
                logging.info("Start time is already set. Waiting 2 minutes")
                time.sleep(120)
        self.global_timer.start_timer()
        self.start_time = time.time()
        self.termination_flag = False
        self.termination_reason = ""

    def should_terminate(self, location: str, timer_only: bool = False) -> bool:
        if self.termination_flag:
            return True
        if self.global_timer.should_terminate():
            self.termination_flag = True
            self.termination_reason = "Global timer expired"
            logging.info(
                f"Termination triggered at {location}: {self.termination_reason}"
            )
            self.start_time = None
            return True
        if timer_only:
            return False
        if self._check_gcs_file():
            self.termination_flag = True
            self.termination_reason = (
                "GCS file check failed. File was added after start_time"
            )
            logging.info(
                f"Termination triggered at {location}: {self.termination_reason}"
            )
            self.start_time = None
            return True
        return False

    def _check_gcs_file(self) -> bool:
        upload_time = self._get_cached_upload_time()
        if upload_time is not None:
            if self.start_time:
                return upload_time > self.start_time
            else:
                logging.warning("Start time is not set. Stopping job.")
                return True
        return False

    def _get_cached_upload_time(self):
        current_time = time.time()
        if (
            self.cached_upload_time is None
            or current_time - self.last_gcs_check_time > self.cache_ttl
        ):
            self._update_gcs_data()
        return self.cached_upload_time

    def _update_gcs_data(self):
        client = storage.Client()
        bucket = client.get_bucket(self.bucket_name)
        blob = bucket.blob(self.file_name)

        try:
            blob.reload()
            self.cached_upload_time = float(blob.metadata.get("upload_time", 0))
        except Exception:
            self.cached_upload_time = None

        self.last_gcs_check_time = time.time()

    def _update_gcs_file(self):
        client = storage.Client()
        bucket = client.get_bucket(self.bucket_name)
        blob = bucket.blob(self.file_name)
        upload_time = time.time()
        metadata = {"upload_time": str(upload_time)}
        blob.metadata = metadata
        blob.upload_from_string("")
        self.cached_upload_time = upload_time
        self.last_gcs_check_time = time.time()

    def stop_job(self):
        self.global_timer.stop_timer()
        self.termination_flag = True
        self.termination_reason = "Job stopped successfully"
        client = storage.Client()
        bucket = client.get_bucket(self.bucket_name)
        blob = bucket.blob(self.file_name)
        try:
            blob.delete()
        except Exception:
            pass
        self.cached_upload_time = None
        self.last_gcs_check_time = time.time()
