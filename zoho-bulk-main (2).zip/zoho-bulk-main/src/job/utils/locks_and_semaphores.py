import threading
from contextlib import contextmanager

csv_read_lock = threading.Lock()

decompression_lock = threading.Lock()


@contextmanager
def locked_decompression():
    with decompression_lock:
        yield


writers_semaphore = threading.Semaphore(2)


@contextmanager
def locked_writing():
    with writers_semaphore:
        yield


results_semaphore = threading.Semaphore(5)


@contextmanager
def locked_results():
    with results_semaphore:
        yield
