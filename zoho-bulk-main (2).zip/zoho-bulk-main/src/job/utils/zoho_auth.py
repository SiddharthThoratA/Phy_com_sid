import logging
import threading
import time

import requests


class ZohoAuthManager:
    def __init__(
        self,
        client_id: str,
        client_secret: str,
        refresh_token: str,
        update_interval: int,
    ) -> None:
        self.client_id = client_id
        self.client_secret = client_secret
        self.refresh_token = refresh_token
        self.update_interval = update_interval
        self.access_token = None
        self.running = True
        self.update_access_token_lock = threading.Lock()
        self.update_thread = threading.Thread(
            target=self.update_access_token, daemon=True
        )
        self.update_thread.start()
        self.logger = logging.getLogger(__name__)
        self.attempts = 0

    def get_token(self):
        return self.access_token

    def get_access_token(self) -> None:
        with self.update_access_token_lock:
            logging.info("Updating the Zoho Creator Access Token")
            url = "https://accounts.zoho.com/oauth/v2/token"
            data = {
                "refresh_token": self.refresh_token,
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "grant_type": "refresh_token",
            }
            response = requests.post(url, data=data)
            if response.status_code == 200:
                self.access_token = response.json().get("access_token")
                time.sleep(10)
                logging.info("Zoho Creator Access Token Updated")
                return
            else:
                self.logger.error(
                    f"Unable to get Zoho Access Token: {response.status_code}"
                )
                raise

    def update_access_token(self) -> None:
        logging.info("Initial access token run")
        while self.running:
            self.get_access_token()
            time.sleep(self.update_interval)

    def stop(self):
        self.running = False
        self.update_thread.join()
        logging.info("Zoho Creator Access Token Update Thread Stopped")
