import json
import logging

from fastavro import parse_schema
from google.cloud import storage

from job.constants.constants import BUCKET, ENV, PROJECT, SERVICE


def upload_dag_trigger_to_gcs() -> None:
    storage_client = storage.Client()
    bucket = storage_client.bucket(BUCKET)
    if ENV == "prod":
        blob_path = f"{BUCKET}/{SERVICE}/dag_trigger.txt"
    else:
        blob_path = f"{BUCKET}/{SERVICE}/{ENV}/dag_trigger.txt"
    blob = bucket.blob(blob_path)
    try:
        blob.upload_from_string("")
        logging.info(f"DAG trigger successfully uploaded to {blob_path}")
    except Exception as e:
        logging.warning(f"Error uploading buffer DAG trigger to GCS: {e}")
        raise


def download_avro_schema_from_gcs():
    try:
        storage_client = storage.Client(project=PROJECT)
        bucket = storage_client.bucket(BUCKET)
        blob_name = f"{BUCKET}/{SERVICE}/schema.avsc"
        blob = bucket.blob(blob_name)
        schema_str = blob.download_as_text()
    except Exception as e:
        logging.exception(f"Exception in getting the Avro Schema: {e}")
        raise
    if not schema_str:
        logging.error("Schema string is empty")
        raise
    return parse_schema(json.loads(schema_str))
