import io
import logging
import threading
import time
import zipfile

import fastavro
import requests
from google.api_core import exceptions as gcp_exceptions
from google.cloud import storage

import job.constants.globals as globals
from job.constants.constants import (
    ACCOUNT_OWNER,
    APP_NAME,
    BATCH_SIZE,
    BUCKET,
    BUFFER_SIZE,
    CHUNK_SIZE,
    ENV,
    SERVICE,
)
from job.utils.csv_fxns import csv_to_avro_format, read_csv_in_chunks
from job.utils.external_communication import (
    send_empty_file_email,
    send_killed_thread_email,
    send_slack_message,
)
from job.utils.global_classes import RateLimiter
from job.utils.locks_and_semaphores import (
    csv_read_lock,
    locked_decompression,
    locked_results,
    locked_writing,
)
from job.utils.retry_decorator import retry_decorator
from job.utils.zoho_auth import ZohoAuthManager


class BulkJobHandler:
    def __init__(
        self,
        create_limiter: RateLimiter,
        read_limiter: RateLimiter,
        gcs_limiter: RateLimiter,
        zoho_auth_manager: ZohoAuthManager,
        report: str,
    ):
        self.started_at = time.time()
        self.create_limiter = create_limiter
        self.read_limiter = read_limiter
        self.gcs_limiter = gcs_limiter
        self.zoho_auth_manager = zoho_auth_manager
        self.report = report
        self.base_url = f"https://creator.zoho.com/api/bulk/v2/{ACCOUNT_OWNER}/{APP_NAME}/report/{self.report}/read"
        self.current_cursor = None
        self.record_cursor = None
        self.logger = logging.getLogger(__name__)
        self.attempts = 0
        self.allowed_attempts = 3
        self.global_timer_exits = 0

    def get_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Zoho-oauthtoken {self.zoho_auth_manager.get_token()}",
            "Content-Type": "application/json",
        }

    @retry_decorator()
    def create_job(self) -> str | None:
        while not self.create_limiter.can_call():
            time.sleep(10)
        logging.info(
            f"Job with Report: {self.report}, Record Cursor: {self.record_cursor}"
        )
        base = {}
        if self.record_cursor:
            base["record_cursor"] = self.record_cursor
        query = {"query": base}
        headers = self.get_headers()
        response = requests.post(self.base_url, headers=headers, json=query)
        if response.status_code == 200:
            self.current_cursor = self.record_cursor
            self.record_cursor = None
            return response.json()["details"]["id"]
        elif response.status_code == 404:
            logging.error(
                f"Report {self.report} not found. Response: {response.status_code}"
            )
            send_slack_message(
                (
                    f"*zoho-bulk k8s*:\n\t\tReport {self.report} not found."
                    "Ensure the report exists in Zoho Creator."
                )
            )
            return
        elif self.attempts <= self.allowed_attempts:
            self.attempts += 1
            logging.info(f"Response: {response.status_code}")
            logging.info(
                f"Retry {self.attempts} - action: create job for {self.report}"
            )
            time.sleep(20)
            return self.create_job()
        else:
            send_killed_thread_email(self.report, "create_job")
            logging.error(
                f"Unable to create job {self.report}. Response: {response.status_code}"
            )

    def get_job_status(self, job_id: str) -> str | None:
        url = self.base_url + f"/{job_id}"
        headers = self.get_headers()
        self.api_call_count += 1
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            response_json = response.json()
            if self.api_call_count % 10 == 0:
                logging.info(f"{self.report}-{job_id} API calls: {self.api_call_count}")
                logging.info(f"{self.report}-{job_id} job status: {response_json}")
            if (
                "details" in response_json
                and "result" in response_json["details"]
                and "record_cursor" in response_json["details"]["result"]
            ):
                self.record_cursor = response_json["details"]["result"]["record_cursor"]
            if response.status_code == 200:
                status = response.json()["details"]["status"]
                return status
            elif self.attempts <= self.allowed_attempts:
                self.attempts += 1
                logging.info(
                    f"Retry {self.attempts} - action: job status for {self.report}"
                )
                time.sleep(60)
                return self.get_job_status(job_id)
            else:
                send_killed_thread_email(self.report, "get_job_status")
                logging.error(f"Unable to get job status: {response.status_code}")
        except Exception as e:
            logging.error(f"Error getting job status on attempt {self.attempts}: {e}")
            self.attempts += 1
            if self.attempts <= self.allowed_attempts:
                time.sleep(60)
                return self.get_job_status(job_id)
            else:
                send_killed_thread_email(self.report, "get_job_status")
                logging.error(f"Unable to get job status: {e}")

    @retry_decorator(max_retries=3, delay=20)
    def upload_to_gcs(self, blob_name: str, data: io.BytesIO) -> None:
        storage_client = storage.Client()
        bucket = storage_client.bucket(BUCKET)
        if ENV == "prod":
            blob_path = f"{BUCKET}/{SERVICE}/" + blob_name
        else:
            blob_path = f"{BUCKET}/{SERVICE}/{ENV}/" + blob_name
        blob = bucket.blob(blob_path)
        try:
            while not self.gcs_limiter.can_call():
                time.sleep(1)
            data.seek(0)
            blob.upload_from_file(data, timeout=300)
            logging.info(f"{blob_path} successfully uploaded")
        except Exception as e:
            logging.warning(f"Error uploading buffer {blob_name} to GCS: {e}")
            raise

    def replace_ingestion_source(self, report: str) -> None:
        storage_client = storage.Client()
        bucket = storage_client.bucket(BUCKET)
        if ENV == "prod":
            folder_path = f"{BUCKET}/{SERVICE}/" + report + "/"
            staging_path = (
                f"{BUCKET}/{SERVICE}/staging/" + report + f"/{self.started_at}/"
            )
        else:
            folder_path = f"{BUCKET}/{SERVICE}/{ENV}/" + report + "/"
            staging_path = (
                f"{BUCKET}/{SERVICE}/{ENV}/staging/" + report + f"/{self.started_at}/"
            )
        blobs = bucket.list_blobs(prefix=folder_path)
        staging_blobs = bucket.list_blobs(prefix=staging_path)

        def continuous_section(blobs, staging_blobs):
            for blob in blobs:
                try:
                    blob.delete()
                except Exception as e:
                    logging.error(f"Error deleting {blob.name} in GCS: {e}")
            logging.info(f"{folder_path} .avro files successfully cleared")
            blobs = bucket.list_blobs(prefix=folder_path)
            for blob in staging_blobs:
                if (
                    "/staging/" in blob.name
                    and f"/{self.started_at}/" in blob.name
                    and blob.size > 0
                ):
                    try:
                        removed_staging = blob.name.replace("/staging/", "/")
                        new_blob_name = removed_staging.replace(
                            f"/{self.started_at}/", "/"
                        )
                        new_blob = bucket.copy_blob(blob, bucket, new_blob_name)
                        logging.info(f"{blob.name} moved to {new_blob.name}")
                        blob.delete()
                    except gcp_exceptions.ServiceUnavailable as e:
                        logging.info(f"Error posting {blob.name} in GCS: {e}")
                        logging.info(f"Retrying {blob.name} in 30s")
                        time.sleep(30)
                        removed_staging = blob.name.replace("/staging/", "/")
                        new_blob_name = removed_staging.replace(
                            f"/{self.started_at}/", "/"
                        )
                        new_blob = bucket.copy_blob(blob, bucket, new_blob_name)
                        logging.info(f"{blob.name} moved to {new_blob.name}")
                        blob.delete()
                    except Exception as e:
                        logging.error(f"Error copying and deleting {blob.name}: {e}")

        self.gcs_limiter.execute_in_continuous_section(
            continuous_section, blobs, staging_blobs
        )

    def get_job_result(self, job_id: str):
        logging.info(f"starting get_job_result for {self.report}")
        read_limiter_loops = 0
        while not self.read_limiter.can_call():
            time.sleep(10)
            if read_limiter_loops % 6 == 0:
                logging.info(f"Waiting for read limiter to allow action: {self.report}")
            read_limiter_loops += 1
        url = self.base_url + f"/{job_id}/result"
        logging.info(f"prepared to download {self.report}_{job_id}.csv")
        headers = self.get_headers()
        response = requests.get(url, headers=headers, timeout=300)
        logging.info(f"response: {response.status_code}")
        if response.status_code == 200 and response.content:
            logging.info(f"Downloaded {self.report}_{job_id}.csv")
            with locked_decompression():
                logging.info(f"Decompressing {self.report}_{job_id}.csv")
                zip_file = zipfile.ZipFile(io.BytesIO(response.content))
                logging.info(f"Decompressed {self.report}_{job_id}.csv")
        elif self.attempts <= self.allowed_attempts:
            self.attempts += 1
            logging.info(f"Retry action {self.attempts}: job result")
            time.sleep(60)
            return self.get_job_result(job_id)
        else:
            status_code = response.status_code
            logging.exception(f"Failed to get job result: {status_code}")
            send_killed_thread_email(self.report, "get_job_result")
            return
        self.attempts = 0
        chunk_number = 0
        chunksize = CHUNK_SIZE
        buffer = io.BytesIO()
        empty_file_result_count = 0
        logging.info(f"Reading {self.report}_{job_id}.csv")
        with zip_file.open(f"{self.report}_{job_id}.csv") as csv_file:
            for chunk in read_csv_in_chunks(
                csv_file, chunksize=chunksize, lock=csv_read_lock
            ):
                if chunk is None and empty_file_result_count < 2:
                    empty_file_result_count += 1
                    logging.info(
                        f"{self.report}_{job_id}.csv is empty"
                        f"{empty_file_result_count} times, retrying csv"
                    )
                    send_empty_file_email(
                        self.report,
                        empty_file_result_count,
                        self.record_cursor,
                        job_id,
                    )
                    self.record_cursor = self.current_cursor
                    self.initiate_job()
                elif (
                    chunk is None
                    and empty_file_result_count >= 2
                    and self.allowed_attempts > self.attempts
                ):
                    self.attempts += 1
                    logging.info(
                        f"{self.report}_{job_id}.csv has "
                        "been empty too many times, restarting job from the beginning"
                    )
                    self.record_cursor = None
                    self.initiate_job()
                if not buffer:
                    buffer = io.BytesIO()
                records = csv_to_avro_format(chunk)
                last_record_index = len(records) - 1
                batch = []
                for index, record in enumerate(records):
                    batch.append(record)
                    if len(records) < chunksize and last_record_index == index:
                        small_chunk = True
                    else:
                        small_chunk = False
                    if len(batch) >= BATCH_SIZE or small_chunk:
                        with locked_writing():
                            fastavro.writer(buffer, globals.schema, batch)
                        batch = []
                    if buffer.tell() > BUFFER_SIZE:
                        self.upload_to_gcs(
                            f"staging/{self.report}/{self.started_at}/{job_id}_{chunk_number}.avro",
                            buffer,
                        )
                        chunk_number += 1
                        buffer.close()
                        buffer = io.BytesIO()
                        if globals.runtime_checks.should_terminate("get_job_result"):
                            return
            if buffer:
                self.upload_to_gcs(
                    f"staging/{self.report}/{self.started_at}/{job_id}_{chunk_number}.avro",
                    buffer,
                )
                buffer.close()

    def initiate_job(self) -> None:
        if globals.runtime_checks.should_terminate("initiate_job"):
            return
        thread = threading.current_thread()
        self.api_call_count = 0
        if not self.record_cursor:
            while not self.gcs_limiter.can_call():
                time.sleep(1)
        job_id = self.create_job()
        if globals.runtime_checks.should_terminate("initiate_job-2"):
            return
        self.attempts = 0
        if not job_id:
            return logging.error(f"Job creation failed for {self.report}")
        job_status = "In-progress"
        status_checks = 0
        while job_status == "In-progress":
            time.sleep(10)
            job_status = self.get_job_status(job_id)
            status_checks += 1
            if globals.runtime_checks.should_terminate("initiate_job-job_status"):
                break

        self.attempts = 0

        logging.info(f"{thread.name} took {status_checks * 10}s for {job_status}")
        if job_status == "Completed":
            if self.record_cursor:
                if globals.runtime_checks.should_terminate("initiate_job-job_status-2"):
                    return
                with locked_results():
                    logging.info(f"{thread.name} getting job result")
                    self.get_job_result(job_id)

                if globals.runtime_checks.should_terminate("initiate_job-3"):
                    return

                new_job_thread = threading.Thread(
                    target=self.initiate_job,
                    name=f"{self.report}-{self.record_cursor}",
                )
                globals.q.put(new_job_thread)
                new_job_thread.start()
            else:
                self.get_job_result(job_id)
                logging.info(f"moving staging to final for {self.report}")
                self.replace_ingestion_source(self.report)
        elif job_status == "Failed" or not job_status:
            logging.error(
                f"{thread.name} failed to create and download report,"
                f" restarting job with cursor {self.current_cursor}"
                f" and record cursor {self.record_cursor} after 60s"
            )
            self.record_cursor = self.current_cursor
            time.sleep(60)
            self.initiate_job()
        elif not job_status and not globals.runtime_checks.should_terminate(
            "initiate_job-2"
        ):
            send_killed_thread_email(self.report, "initiate_job-4")
            logging.error(f"{thread.name} failed to get job status")
            return

        if globals.runtime_checks.should_terminate("initiate_job-5"):
            return

        return logging.info(f"{thread.name} fully downloaded")
