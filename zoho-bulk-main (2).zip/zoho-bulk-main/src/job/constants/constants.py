import os

ZOHO_CREATOR_CLIENT_ID = os.environ.get("ZOHO_CREATOR_CLIENT_ID")
ZOHO_CREATOR_CLIENT_SECRET = os.environ.get("ZOHO_CREATOR_CLIENT_SECRET")
ZOHO_CREATOR_REFRESH_TOKEN = os.environ.get("ZOHO_CREATOR_REFRESH_TOKEN")
SENDGRID_API_KEY = os.environ.get("SENDGRID_API_KEY")
ENV = os.environ.get("ENV", "local")
PROJECT = "deft-bonsai-304315"
ACCOUNT_OWNER = "fluidtruck"
APP_NAME = "Fluid-portal"
BUCKET = "bi-services"
SERVICE = "zoho-bulk"
BUFFER_SIZE = 25 * 1024 * 1024
BATCH_SIZE = 10
CHUNK_SIZE = 100
HEARTBEAT_GCS_LOCATION = "bi-services/zoho-bulk/heartbeat"
DATA_ANALYTICS_SLACK_URL = os.environ.get("DATA_ANALYTICS_SLACK_URL")
TIMEOUT_MINS = 78
