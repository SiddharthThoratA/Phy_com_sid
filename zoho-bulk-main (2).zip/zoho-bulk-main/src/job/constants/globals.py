import queue

from job.constants.constants import BUCKET, ENV, TIMEOUT_MINS
from job.utils.gcs_fxns import download_avro_schema_from_gcs
from job.utils.global_classes import RuntimeChecks

q = queue.Queue()
schema = download_avro_schema_from_gcs()

if ENV == "prod":
    runtime_check_file_location = f"{BUCKET}/zoho-bulk/killswitch/job_start.txt"
else:
    runtime_check_file_location = f"{BUCKET}/zoho-bulk/killswitch/{ENV}/job_start.txt"
runtime_checks = RuntimeChecks(TIMEOUT_MINS * 60, runtime_check_file_location)
