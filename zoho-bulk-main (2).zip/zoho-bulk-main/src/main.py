import json
import logging
import os
import socket
from contextlib import asynccontextmanager

import requests
import uvicorn
from fastapi import FastAPI
from google.cloud import pubsub_v1

from log_middleware import LogMiddleware
from logger import logger
from service import service


def get_env() -> str:
    if os.environ.get("ENV", None) is None:
        return "local"
    return os.environ["ENV"]


ENV = get_env()
STAGE_SUBSCRIPTION_ID = "zoho_bulk_stage-sub"
PROD_SUBSCRIPTION_ID = "zoho_bulk-sub"


if ENV != "local":
    logging.info("Registering with Consul..")
    if os.environ["CONSUL_HTTP_TOKEN"]:
        data = {
            "Name": os.environ["CONSUL_SERVICE_NAME"],
            "Meta": {
                "pod_name": socket.gethostname(),
            },
            "Address": os.environ["CONSUL_POD_IP"],
            "Port": 8000,
            "Check": {
                "Name": "HTTP API on port 8000",
                "HTTP": f"http://{os.environ['CONSUL_POD_IP']}:8000/healthz",
                "DeregisterCriticalServiceAfter": "1m",
                "Interval": "30s",
                "Timeout": "5s",
            },
        }

        r = requests.put(
            f"http://{os.environ['CONSUL_HTTP_ADDR']}/v1/agent/service/register",
            json=data,
            headers={"X-Consul-Token": os.environ["CONSUL_HTTP_TOKEN"]},
        )
        logging.info("Attempted to register service with Consul")

        if r.status_code != 200:
            logger.error(f"Failed to register service: {r.text}")
            exit(1)
        logging.info("Service registered with Consul")


def callback(message) -> None:
    try:
        logging.info(f"received message: {message}")
        message_str: str = message.data.decode("utf8")
        message.ack()
        message_json = json.loads(message_str)
        job_type: str | None = message.attributes.get("job_type", None)
        email: str = message.attributes.get("email", "data-monitoring@kingbee-vans.com")
        jobs = message_json.get("jobs", [])
        service(jobs, job_type, email)
    except Exception as e:
        logging.error(f"Error processing message: {e}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    project_id: str = "deft-bonsai-304315"
    if ENV == "prod":
        subscription_id: str = PROD_SUBSCRIPTION_ID
    elif ENV == "stage":
        subscription_id: str = STAGE_SUBSCRIPTION_ID
    else:
        subscription_id: str = "placeholder-sub"
    logging.info(f"{ENV=}")

    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, subscription_id)
    try:
        future = subscriber.subscribe(subscription_path, callback=callback)
    except Exception as e:
        logging.error(f"future is closing with error: {e}")
    logging.info(f"Listening for messages on {subscription_path}..")
    yield
    logging.info("Cleaning up subscription..")
    subscriber.close()
    future.cancel()


app = FastAPI(lifespan=lifespan)
app.add_middleware(LogMiddleware)


@app.get("/")
async def root():
    return "OK"


@app.get("/healthz")
async def healthz():
    return {"status": "UP"}


@app.get("/readyz")
async def readyz():
    return {"status": "UP"}


if __name__ == "__main__":
    logging.info("Starting from main")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_config=None)
